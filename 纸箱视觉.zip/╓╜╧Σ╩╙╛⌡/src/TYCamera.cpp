﻿#include "TYCamera.h"
void TYCamera::eventCallback(TY_EVENT_INFO *event_info, void *userdata) {
	if (event_info->eventId == TY_EVENT_DEVICE_OFFLINE) {
		LOGD("=== Event Callback: Device Offline!");
		// Note:Please set TY_BOOL_KEEP_ALIVE_ON OFF feature to false if you need to debug with breakpoint!
	}
	else if (event_info->eventId == TY_EVENT_LICENSE_ERROR) {
		LOGD("=== Event Callback: License Error!");
	}
}

int TYCamera::cvpf2typf(int cvpf) {
	switch (cvpf) {
	case CV_8U: return TY_PIXEL_FORMAT_MONO;
	case CV_8UC3: return TY_PIXEL_FORMAT_RGB;
	case CV_16UC1: return TY_PIXEL_FORMAT_DEPTH16;
	default: return TY_PIXEL_FORMAT_UNDEFINED;
	}
}

void TYCamera::mat2TY_IMAGE_DATA(int comp, const cv::Mat& mat, TY_IMAGE_DATA& data) {
	data.status = 0;
	data.componentID = comp;
	data.size = mat.total() * mat.elemSize();
	data.buffer = mat.data;
	data.width = mat.cols;
	data.height = mat.rows;
	data.pixelFormat = cvpf2typf(mat.type());
}

void TYCamera::doRegister(const TY_CAMERA_CALIB_INFO& depth_calib,
	const TY_CAMERA_CALIB_INFO& color_calib,
	const cv::Mat& depth,
	const float f_scale_unit,
	const cv::Mat& color,
	cv::Mat& undistort_color,
	cv::Mat& out,
	bool map_depth_to_color) {
	// do undistortion
	TY_IMAGE_DATA src;
	src.width = color.cols;
	src.height = color.rows;
	src.size = color.size().area() * 3;
	src.pixelFormat = TY_PIXEL_FORMAT_RGB;
	src.buffer = color.data;

	undistort_color = cv::Mat(color.size(), CV_8UC3);
	TY_IMAGE_DATA dst;
	dst.width = color.cols;
	dst.height = color.rows;
	dst.size = undistort_color.size().area() * 3;
	dst.buffer = undistort_color.data;
	dst.pixelFormat = TY_PIXEL_FORMAT_RGB;
	ASSERT_OK(TYUndistortImage(&color_calib, &src, NULL, &dst));
	// do register
	if (map_depth_to_color) {
		out = cv::Mat::zeros(undistort_color.size(), CV_16U);
		ASSERT_OK(
			TYMapDepthImageToColorCoordinate(
				&depth_calib,
				depth.cols, depth.rows, depth.ptr<uint16_t>(),
				&color_calib,
				out.cols, out.rows, out.ptr<uint16_t>())
		);
	}
	else {
		out = cv::Mat::zeros(depth.size(), CV_8UC3);
		ASSERT_OK(
			TYMapRGBImageToDepthCoordinate(
				&depth_calib,
				depth.cols, depth.rows, depth.ptr<uint16_t>(),
				&color_calib,
				undistort_color.cols, undistort_color.rows, undistort_color.ptr<uint8_t>(),
				out.ptr<uint8_t>())
		);
	}
}

int TYCamera::CamSingleTuyangInit(std::string mac, std::string ip, camsInfo& cams) {
	TY_INTERFACE_HANDLE hIface = NULL;
	TY_DEV_HANDLE hDevice = NULL;
	TY_CAMERA_INTRINSIC intri_depth;
	TY_CAMERA_INTRINSIC intri_color;
	int32_t resend = 1;
	if (display_info) LOGD("=== Init lib");
	ASSERT_OK(TYInitLib());
	TY_VERSION_INFO ver;
	ASSERT_OK(TYLibVersion(&ver));
	if (display_info) LOGD("     - lib version: %d.%d.%d", ver.major, ver.minor, ver.patch);
	std::vector<TY_DEVICE_BASE_INFO> selected;
	ASSERT_OK(selectDevice(TY_INTERFACE_ALL, mac, ip, 1, selected));
	ASSERT(selected.size() > 0);
	TY_DEVICE_BASE_INFO &selectedDev = selected[0];
	ASSERT_OK(TYOpenInterface(selectedDev.iface.id, &hIface));
	ASSERT_OK(TYOpenDevice(hIface, selectedDev.id, &hDevice));
	//try to enable color camera
	if (display_info) LOGD("Has RGB camera, open RGB cam");
	ASSERT_OK(TYEnableComponents(hDevice, TY_COMPONENT_RGB_CAM));
	if (display_info) LOGD("=== Configure feature, set RGB resolution");
	ASSERT_OK(TYSetEnum(hDevice, TY_COMPONENT_RGB_CAM, TY_ENUM_IMAGE_MODE, COLOR_IMAGE_SIZE));
	if (display_info) LOGD("=== Get color intrinsic");
	ASSERT_OK(TYGetStruct(hDevice, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_color, sizeof(intri_color)));
	if (display_info) LOGD("=== Read color calib data");
	ASSERT_OK(TYGetStruct(hDevice, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_CALIB_DATA, &cams.color_calib, sizeof(cams.color_calib)));
	//create a default isp handle for bayer rgb images
	ASSERT_OK(TYISPCreate(&isp_handle));
	cams.IspHandle = isp_handle;
	ASSERT_OK(ColorIspInitSetting(isp_handle, hDevice));
	//You can turn on auto exposure function as follow ,but frame rate may reduce .
	//Device also may be casually stucked  1~2 seconds when software trying to adjust device exposure time value
#if 0 //
	ASSERT_OK(ColorIspInitAutoExposure(isp_handle, hDevice));
#endif
	bool hasAUTOEXPOSURE, hasAUTOGAIN, hasAUTOAWB;
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, &hasAUTOEXPOSURE));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, &hasAUTOGAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, &hasAUTOAWB));
	if (hasAUTOEXPOSURE)
	{
		ASSERT_OK(TYSetBool(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, true));//turn on AEC
	}
	if (hasAUTOGAIN)
	{
		ASSERT_OK(TYSetBool(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, true));//turn on AGC
	}
	if (hasAUTOAWB)
	{
		ASSERT_OK(TYSetBool(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, true));//turn on AWB
	}
	bool hasRGB_ANALOG_GAIN, hasRGB_R_GAIN, hasRGB_G_GAIN, hasRGB_B_GAIN, hasRGB_EXPOSURE_TIME;
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, &hasRGB_ANALOG_GAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, &hasRGB_R_GAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, &hasRGB_G_GAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, &hasRGB_B_GAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, &hasRGB_EXPOSURE_TIME));
	if (hasRGB_ANALOG_GAIN) ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, ANALOG_GAIN));
	if (hasRGB_R_GAIN) ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, R_GAIN));
	if (hasRGB_G_GAIN) ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, G_GAIN));
	if (hasRGB_B_GAIN) ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, B_GAIN));
	if (hasRGB_EXPOSURE_TIME) ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, EXPOSURE_TIME));
	//try to enable depth cam
	if (display_info) LOGD("=== Configure components, open depth cam");
	int32_t componentIDs = TY_COMPONENT_DEPTH_CAM;
	ASSERT_OK(TYEnableComponents(hDevice, componentIDs));
	if (display_info) LOGD("=== Configure feature, set depth resolution");
	ASSERT_OK(TYSetEnum(hDevice, TY_COMPONENT_DEPTH_CAM, TY_ENUM_IMAGE_MODE, DEPTH_IMAGE_SIZE));
	if (display_info) LOGD("=== Get depth intrinsic");
	ASSERT_OK(TYGetStruct(cams.hDevice, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_depth, sizeof(intri_depth)));
	if (display_info) LOGD("=== Read depth calib data");
	ASSERT_OK(TYGetStruct(hDevice, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_CALIB_DATA, &cams.depth_calib, sizeof(cams.depth_calib)));
	//adjust the gain and exposure of Left&Right IR camera
	bool hasIR_ANALOG_GAIN, hasIR_GAIN, hasIR_EXPOSURE_TIME;
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, &hasIR_ANALOG_GAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, &hasIR_GAIN));
	ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, &hasIR_EXPOSURE_TIME));
	if (hasIR_ANALOG_GAIN)
	{
		ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, ANALOG_GAIN));
		ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_ANALOG_GAIN, ANALOG_GAIN));
	}
	//if (hasIR_GAIN)
	//{
	//	ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, LR_GAIN));
	//	ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_GAIN, LR_GAIN));
	//}
	//if (hasIR_EXPOSURE_TIME)
	//{
	//	ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, LR_EXPOSURE_TIME));
	//	ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_EXPOSURE_TIME, LR_EXPOSURE_TIME));
	//}
	//adjust the laser power
	ASSERT_OK(TYSetInt(hDevice, TY_COMPONENT_LASER, TY_INT_LASER_POWER, 100));// range(0,100)
	//Cmos sync switch,Closing the cmos sync can increase fps in 640*480 resolution,but may cause poor depth image.
	TYSetBool(hDevice, TY_COMPONENT_DEVICE, TY_BOOL_CMOS_SYNC, false);
	//stream async switch, see TY_STREAM_ASYNC_MODE
	//TYSetEnum(hDevice, TY_COMPONENT_DEVICE, TY_ENUM_STREAM_ASYNC, TY_STREAM_ASYNC_OFF);

	if (display_info) LOGD("=== Prepare image buffer");
	uint32_t frameSize;
	ASSERT_OK(TYGetFrameBufferSize(hDevice, &frameSize));
	if (display_info) LOGD("     - Get size of framebuffer, %d", frameSize);
	if (display_info) LOGD("     - Allocate & enqueue buffers");
	char* frameBuffer[2];
	frameBuffer[0] = new char[frameSize];
	frameBuffer[1] = new char[frameSize];
	if (display_info) LOGD("     - Enqueue buffer (%p, %d)", frameBuffer[0], frameSize);
	ASSERT_OK(TYEnqueueBuffer(hDevice, frameBuffer[0], frameSize));
	if (display_info) LOGD("     - Enqueue buffer (%p, %d)", frameBuffer[1], frameSize);
	ASSERT_OK(TYEnqueueBuffer(hDevice, frameBuffer[1], frameSize));
	if (display_info) LOGD("Register event callback");
	ASSERT_OK(TYRegisterEventCallback(hDevice, TYCamera::eventCallback, NULL));
	if (display_info) LOGD("=== enable trigger mode");
	TY_TRIGGER_PARAM trigger;
	trigger.mode = TY_TRIGGER_MODE_OFF;
	//trigger.mode = TY_TRIGGER_MODE_SLAVE;
	//Check whether a component has a specific feature
	ASSERT_OK(TYSetStruct(hDevice, TY_COMPONENT_DEVICE, TY_STRUCT_TRIGGER_PARAM, &trigger, sizeof(trigger)));
	//for network only
	if (display_info) LOGD("=== resend: %d", resend);
	if (resend) {
		bool hasResend;
		ASSERT_OK(TYHasFeature(hDevice, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, &hasResend));
		if (hasResend) {
			if (display_info) LOGD("=== Open resend");
			ASSERT_OK(TYSetBool(hDevice, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, true));
		}
		else {
			if (display_info) LOGD("=== Not support feature TY_BOOL_GVSP_RESEND");
		}
	}
	if (display_info) LOGD("=== Start capture");
	ASSERT_OK(TYStartCapture(hDevice));

	//回调数据初始化
	cams.hDevice = hDevice;
	float scale_unit = 1.;
	cams.intri_depth = intri_depth;
	cams.intri_color = intri_color;
	TYGetFloat(hDevice, TY_COMPONENT_DEPTH_CAM, TY_FLOAT_SCALE_UNIT, &scale_unit);
	cams.scale_unit = scale_unit;

	LOGD("=== camera init done ===");
}

int TYCamera::CamMultiTuyangInit(std::vector<char*>& list_ID, std::vector<camsInfo>& cams) {
	int32_t deviceType = TY_INTERFACE_ETHERNET | TY_INTERFACE_USB;
	int32_t cam_size = 0;
	bool trigger_mode = true;

	if (true) LOGD("=== Init lib");
	//cout << "display_info: " << display_info << endl;
	ASSERT_OK(TYInitLib());
	TY_VERSION_INFO ver;
	ASSERT_OK(TYLibVersion(&ver));
	if (true) LOGD("     - lib version: %d.%d.%d", ver.major, ver.minor, ver.patch);
	//获取设备信息
	std::vector<TY_DEVICE_BASE_INFO> selected;
	if (selectDevice(deviceType, "", "", 100, selected) == TY_STATUS_ERROR) { return -1; }
	if (list_ID.size()) {
		cam_size = list_ID.size();
	}
	else {
		if (display_info) LOGD("===no find device in list");
		return -1;
	}
	int32_t count = 0;
	for (uint32_t i = 0; i < list_ID.size(); i++) {
		for (uint32_t j = 0; j < selected.size(); j++) {
			if (display_info) LOGD("=== check device: %s, %s", list_ID[i], selected[j].id);
			if (strcmp(list_ID[i], selected[j].id) == 0) {
				if (display_info) LOGD("=== check device success");
				if (display_info) LOGD("=== Open device: %s", selected[j].id);
				ASSERT_OK(TYOpenInterface(selected[j].iface.id, &cams[count].hIface));
				if (TYOpenDevice(cams[count].hIface, selected[j].id, &cams[count].hDevice) != TY_STATUS_OK) {
					return -1;
				}
				TY_CAMERA_INTRINSIC intri_depth;
				TY_CAMERA_INTRINSIC intri_color;
				if (display_info) LOGD("=== Configure components, open RGB cam");
				TY_COMPONENT_ID allComps;
				ASSERT_OK(TYGetComponentIDs(cams[count].hDevice, &allComps));
				//try to enable color camera
				if (allComps & TY_COMPONENT_RGB_CAM) {
					int32_t image_mode;
					if (display_info) LOGD("Has RGB camera, open RGB cam");
					ASSERT_OK(TYEnableComponents(cams[count].hDevice, TY_COMPONENT_RGB_CAM));
					//ASSERT_OK(get_default_image_mode(cams[count].hDev, TY_COMPONENT_RGB_CAM, image_mode));
					if (display_info) LOGD("=== Configure feature, set RGB resolution");
					ASSERT_OK(TYSetEnum(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_ENUM_IMAGE_MODE, COLOR_IMAGE_SIZE));
					if (display_info) LOGD("=== Get color intrinsic");
					ASSERT_OK(TYGetStruct(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_color, sizeof(intri_color)));
					cout << "color_intr: [";
					for (int n = 0; n < 9; n++) {
						cout << intri_color.data[n];
						if (n < 8) {
							cout << ",";
						}
					}
					cout << "]" << endl;
					if (display_info) LOGD("=== Read color calib data");
					ASSERT_OK(TYGetStruct(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_CALIB_DATA, &cams[count].color_calib, sizeof(cams[count].color_calib)));
					//create a default isp handle for bayer rgb images
					ASSERT_OK(TYISPCreate(&cams[count].IspHandle)); //create a default isp handle for bayer rgb images
					//cams.IspHandle = isp_handle;
					ASSERT_OK(ColorIspInitSetting(cams[count].IspHandle, cams[count].hDevice));
					//You can turn on auto exposure function as follow ,but frame rate may reduce .
					//Device also may be casually stucked  1~2 seconds when software trying to adjust device exposure time value
#if 0
					ASSERT_OK(ColorIspInitAutoExposure(IspHandle, hDevice));
#endif
					bool hasAUTOEXPOSURE, hasAUTOGAIN, hasAUTOAWB;
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, &hasAUTOEXPOSURE));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, &hasAUTOGAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, &hasAUTOAWB));
					if (hasAUTOEXPOSURE) ASSERT_OK(TYSetBool(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, true));//turn on AEC
					if (hasAUTOGAIN) ASSERT_OK(TYSetBool(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, true));//turn on AGC
					if (hasAUTOAWB) ASSERT_OK(TYSetBool(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, true));//turn on AWB
					bool hasRGB_ANALOG_GAIN, hasRGB_R_GAIN, hasRGB_G_GAIN, hasRGB_B_GAIN, hasRGB_EXPOSURE_TIME;
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, &hasRGB_ANALOG_GAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, &hasRGB_R_GAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, &hasRGB_G_GAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, &hasRGB_B_GAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, &hasRGB_EXPOSURE_TIME));
					if (hasRGB_ANALOG_GAIN) ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, ANALOG_GAIN));
					if (hasRGB_R_GAIN) ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, R_GAIN));
					if (hasRGB_G_GAIN) ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, G_GAIN));
					if (hasRGB_B_GAIN) ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, B_GAIN));
					if (hasRGB_EXPOSURE_TIME) ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, EXPOSURE_TIME));
				}
				//try to enable depth cam
				if (allComps & TY_COMPONENT_DEPTH_CAM) {
					if (display_info) LOGD("=== Configure components, open depth cam");
					ASSERT_OK(TYEnableComponents(cams[count].hDevice, TY_COMPONENT_DEPTH_CAM));
					if (display_info) LOGD("=== Configure feature, set depth resolution");
					ASSERT_OK(TYSetEnum(cams[count].hDevice, TY_COMPONENT_DEPTH_CAM, TY_ENUM_IMAGE_MODE, DEPTH_IMAGE_SIZE));
					if (display_info) LOGD("=== Get depth intrinsic");
					ASSERT_OK(TYGetStruct(cams[count].hDevice, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_depth, sizeof(intri_depth)));
					if (display_info) LOGD("=== Read depth calib data");
					ASSERT_OK(TYGetStruct(cams[count].hDevice, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_CALIB_DATA, &cams[count].depth_calib, sizeof(cams[count].depth_calib)));
					//adjust the gain and exposure of Left&Right IR camera
					bool hasIR_ANALOG_GAIN, hasIR_GAIN, hasIR_EXPOSURE_TIME;
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, &hasIR_ANALOG_GAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, &hasIR_GAIN));
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, &hasIR_EXPOSURE_TIME));
					if (hasIR_ANALOG_GAIN)
					{
						ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, LR_ANALOG_GAIN));
						ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_ANALOG_GAIN, LR_ANALOG_GAIN));
					}
					//if (hasIR_GAIN)
					//{
					//	ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, LR_GAIN));
					//	ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_GAIN, LR_GAIN));
					//}
					//if (hasIR_EXPOSURE_TIME)
					//{
					//	ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, LR_EXPOSURE_TIME));
					//	ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_EXPOSURE_TIME, LR_EXPOSURE_TIME));
					//}
					//adjust the laser power
					ASSERT_OK(TYSetInt(cams[count].hDevice, TY_COMPONENT_LASER, TY_INT_LASER_POWER, 100));// range(0,100)
					//Cmos sync switch,Closing the cmos sync can increase fps in 640*480 resolution,but may cause poor depth image.
					TYSetBool(cams[count].hDevice, TY_COMPONENT_DEVICE, TY_BOOL_CMOS_SYNC, false);
					//stream async switch, see TY_STREAM_ASYNC_MODE
					//TYSetEnum(cams[count].hDevice, TY_COMPONENT_DEVICE, TY_ENUM_STREAM_ASYNC, TY_STREAM_ASYNC_OFF);
				}

				if (display_info) LOGD("=== Prepare image buffer");
				uint32_t frameSize;
				ASSERT_OK(TYGetFrameBufferSize(cams[count].hDevice, &frameSize));
				if (display_info) LOGD("     - Get size of framebuffer, %d", frameSize);
				if (display_info) LOGD("     - Allocate & enqueue buffers");
				cams[count].frameBuffer[0] = new char[frameSize];
				cams[count].frameBuffer[1] = new char[frameSize];
				if (display_info) LOGD("     - Enqueue buffer (%p, %d)", cams[count].frameBuffer[0], frameSize);
				ASSERT_OK(TYEnqueueBuffer(cams[count].hDevice, cams[count].frameBuffer[0], frameSize));
				if (display_info) LOGD("     - Enqueue buffer (%p, %d)", cams[count].frameBuffer[1], frameSize);
				ASSERT_OK(TYEnqueueBuffer(cams[count].hDevice, cams[count].frameBuffer[1], frameSize));
				if (display_info) LOGD("=== Register event callback");
				ASSERT_OK(TYRegisterEventCallback(cams[count].hDevice, eventCallback, NULL));
				if (display_info) LOGD("=== Disable trigger mode");
				TY_TRIGGER_PARAM trigger;
				//连续采集模式			 
				trigger.mode = TY_TRIGGER_MODE_OFF;
				//软触发和硬触发模式					  
				//trigger.mode = TY_TRIGGER_MODE_SLAVE;
				ASSERT_OK(TYSetStruct(cams[count].hDevice, TY_COMPONENT_DEVICE, TY_STRUCT_TRIGGER_PARAM, &trigger, sizeof(trigger)));
				if (trigger_mode) {
					bool hasResend;
					ASSERT_OK(TYHasFeature(cams[count].hDevice, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, &hasResend));
					if (hasResend) {
						if (display_info) LOGD("=== Open resend");
						ASSERT_OK(TYSetBool(cams[count].hDevice, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, true));
					}
					else {
						if (display_info) LOGD("=== Not support feature TY_BOOL_GVSP_RESEND");
					}
				}
				cams[count].intri_depth = intri_depth;
				cams[count].intri_color = intri_color;
				if (display_info) LOGD("=== Start capture");
				ASSERT_OK(TYStartCapture(cams[count].hDevice));
				count++;
			}
		}
	}
	if (count != cam_size) {
		if (display_info) LOGD("Invalid ids in input id list");
		return -1;
	}

	LOGD("=== camera init done ===");
}

int TYCamera::getSpecifiedCameraData(camsInfo& cams, cv::Mat& depth, cv::Mat& color) {
	//ASSERT_OK(TYSendSoftTrigger(cams.hDevice));
	int err = TYFetchFrame(cams.hDevice, &cams.frame, 20000);
	if (err != TY_STATUS_OK)
	{
		if (display_info) LOGD("... Drop one frame");
		return -1;
	}
	else
	{
		if (display_info) LOGD("... Got one frame");
		FecthOneFrame(cams, depth, color);
	}
	RefreshFrameBuffer(cams);
	return 1;
}

void TYCamera::CamTuyangClose(const camsInfo& cams) {
	ASSERT_OK(TYStopCapture(cams.hDevice));
	ASSERT_OK(TYCloseDevice(cams.hDevice));
	ASSERT_OK(TYCloseInterface(cams.hIface));
	//ASSERT_OK(TYISPRelease(&cb_data.IspHandle));
	ASSERT_OK(TYDeinitLib());
	if (display_info) LOGD("=== camera closed!===");
}

int TYCamera::FecthOneFrame(camsInfo& cb_data, cv::Mat& depth, cv::Mat& color) {
	parseFrame(cb_data.frame, &depth, 0, 0, &color); //depth:CV_16UC1,color:CV_8UC3
	if (!depth.empty()) {
		if (SpeckleFilter) {
			TY_IMAGE_DATA tyFilteredDepth;
			cv::Mat filteredDepth(depth.size(), depth.type());//
			filteredDepth = depth.clone();
			mat2TY_IMAGE_DATA(TY_COMPONENT_DEPTH_CAM, filteredDepth, tyFilteredDepth);
			struct DepthSpeckleFilterParameters sfparam = DepthSpeckleFilterParameters_Initializer;
			sfparam.max_speckle_size = 300;
			sfparam.max_speckle_diff = 12;
			TYDepthSpeckleFilter(&tyFilteredDepth, &sfparam);
			depth = filteredDepth.clone();
		}
	}
	cv::Mat color_data_mat;
	if (!color.empty()) {
		cv::Mat undistort_color, MappedDepth;
		if (MAP_DEPTH_TO_COLOR)
		{
			doRegister(cb_data.depth_calib, cb_data.color_calib, depth, cb_data.scale_unit, color, undistort_color, MappedDepth, MAP_DEPTH_TO_COLOR);
			//cv::cvtColor(undistort_color, color_data_mat, CV_BGR2RGB);
			color = undistort_color;
			depth = MappedDepth;
		}
		else
		{
			doRegister(cb_data.depth_calib, cb_data.color_calib, depth, cb_data.scale_unit, color, undistort_color, color_data_mat, MAP_DEPTH_TO_COLOR);
			//cv::cvtColor(color_data_mat, color_data_mat, CV_BGR2RGB);
			color = color_data_mat;
		}

	}
	return 1;
}

void TYCamera::RefreshFrameBuffer(camsInfo& cams) {
	//TYISPUpdateDevice(cb_data.IspHandle);
	if (display_info) LOGD("Re-enqueue buffer(%p, %d)\r", cams.frame.userBuffer, cams.frame.bufferSize);
	ASSERT_OK(TYEnqueueBuffer(cams.hDevice, cams.frame.userBuffer, cams.frame.bufferSize));
	TYISPUpdateDevice(cams.IspHandle);
}


//#include "TYCamera.h"
//
//void TYCamera::eventCallback(TY_EVENT_INFO* event_info, void* userdata) {
//	if (event_info->eventId == TY_EVENT_DEVICE_OFFLINE) {
//		LOGD("=== Event Callback: Device Offline!");
//		// Note:Please set TY_BOOL_KEEP_ALIVE_ON OFF feature to false if you need to debug with breakpoint!
//	}
//	else if (event_info->eventId == TY_EVENT_LICENSE_ERROR) {
//		LOGD("=== Event Callback: License Error!");
//	}
//}
//
//int TYCamera::cvpf2typf(int cvpf) {
//	switch (cvpf) {
//	case CV_8U: return TY_PIXEL_FORMAT_MONO;
//	case CV_8UC3: return TY_PIXEL_FORMAT_RGB;
//	case CV_16UC1: return TY_PIXEL_FORMAT_DEPTH16;
//	default: return TY_PIXEL_FORMAT_UNDEFINED;
//	}
//}
//
//void TYCamera::mat2TY_IMAGE_DATA(int comp, const cv::Mat& mat, TY_IMAGE_DATA& data) {
//	data.status = 0;
//	data.componentID = comp;
//	data.size = mat.total() * mat.elemSize();
//	data.buffer = mat.data;
//	data.width = mat.cols;
//	data.height = mat.rows;
//	data.pixelFormat = cvpf2typf(mat.type());
//}
//
//void TYCamera::doRegister(const TY_CAMERA_CALIB_INFO& depth_calib,
//	const TY_CAMERA_CALIB_INFO& color_calib,
//	const cv::Mat& depth,
//	const float f_scale_unit,
//	const cv::Mat& color,
//	cv::Mat& undistort_color,
//	cv::Mat& out,
//	bool map_depth_to_color) {
//	// do undistortion
//	TY_IMAGE_DATA src;
//	src.width = color.cols;
//	src.height = color.rows;
//	src.size = color.size().area() * 3;
//	src.pixelFormat = TY_PIXEL_FORMAT_RGB;
//	src.buffer = color.data;
//
//	undistort_color = cv::Mat(color.size(), CV_8UC3);
//	TY_IMAGE_DATA dst;
//	dst.width = color.cols;
//	dst.height = color.rows;
//	dst.size = undistort_color.size().area() * 3;
//	dst.buffer = undistort_color.data;
//	dst.pixelFormat = TY_PIXEL_FORMAT_RGB;
//	(TYUndistortImage(&color_calib, &src, NULL, &dst));
//	// do register
//	if (map_depth_to_color) {
//		out = cv::Mat::zeros(undistort_color.size(), CV_16U);
//		(
//			TYMapDepthImageToColorCoordinate(
//				&depth_calib,
//				depth.cols, depth.rows, depth.ptr<uint16_t>(),
//				&color_calib,
//				out.cols, out.rows, out.ptr<uint16_t>())
//			);
//	}
//	else {
//		out = cv::Mat::zeros(depth.size(), CV_8UC3);
//		(
//			TYMapRGBImageToDepthCoordinate(
//				&depth_calib,
//				depth.cols, depth.rows, depth.ptr<uint16_t>(),
//				&color_calib,
//				undistort_color.cols, undistort_color.rows, undistort_color.ptr<uint8_t>(),
//				out.ptr<uint8_t>())
//			);
//	}
//}
//
//int TYCamera::CamSingleTuyangInit(const std::string& mac, const std::string& ip, const CamPara& camPara, CamInfo& cam) {
//	TY_INTERFACE_HANDLE hIface = NULL;
//	TY_DEV_HANDLE hDevice = NULL;
//	TY_CAMERA_INTRINSIC intri_depth;
//	TY_CAMERA_INTRINSIC intri_color;
//	int32_t resend = 1;
//	if (display_info) LOGD("=== Init lib");
//	if (TYInitLib() != TY_STATUS_OK) { return false; };
//	TY_VERSION_INFO ver;
//	(TYLibVersion(&ver));
//	if (display_info) LOGD("     - lib version: %d.%d.%d", ver.major, ver.minor, ver.patch);
//	std::vector<TY_DEVICE_BASE_INFO> selected;
//	(selectDevice(TY_INTERFACE_ALL, mac, ip, 1, selected));
//	ASSERT(selected.size() > 0);
//	TY_DEVICE_BASE_INFO& selectedDev = selected[0];
//	(TYOpenInterface(selectedDev.iface.id, &hIface));
//	(TYOpenDevice(hIface, selectedDev.id, &hDevice));
//	//try to enable color camera
//	if (display_info) LOGD("Has RGB camera, open RGB cam");
//	(TYEnableComponents(hDevice, TY_COMPONENT_RGB_CAM));
//	if (display_info) LOGD("=== Configure feature, set RGB resolution");
//	(TYSetEnum(hDevice, TY_COMPONENT_RGB_CAM, TY_ENUM_IMAGE_MODE, camPara.color_image_size));
//	if (display_info) LOGD("=== Get color intrinsic");
//	(TYGetStruct(hDevice, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_color, sizeof(intri_color)));
//	std::cout << "intri_color : [";
//	for (int i = 0; i < 9; i++) {
//		std::cout << intri_color.data[i] << ",";
//	}
//	std::cout << "]\n";
//	if (display_info) LOGD("=== Read color calib data");
//	(TYGetStruct(hDevice, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_CALIB_DATA, &cam.color_calib, sizeof(cam.color_calib)));
//	//create a default isp handle for bayer rgb images
//	(TYISPCreate(&isp_handle));
//	cam.IspHandle = isp_handle;
//	(ColorIspInitSetting(isp_handle, hDevice));
//	//You can turn on auto exposure function as follow ,but frame rate may reduce .
//	//Device also may be casually stucked  1~2 seconds when software trying to adjust device exposure time value
//#if 0 //
//	(ColorIspInitAutoExposure(isp_handle, hDevice));
//#endif
//	bool hasAUTOEXPOSURE, hasAUTOGAIN, hasAUTOAWB;
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, &hasAUTOEXPOSURE));
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, &hasAUTOGAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, &hasAUTOAWB));
//	if (hasAUTOEXPOSURE)
//	{
//		(TYSetBool(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, true));//turn on AEC
//	}
//	if (hasAUTOGAIN)
//	{
//		(TYSetBool(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, true));//turn on AGC
//	}
//	if (hasAUTOAWB)
//	{
//		(TYSetBool(hDevice, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, true));//turn on AWB
//	}
//	bool hasRGB_ANALOG_GAIN, hasRGB_R_GAIN, hasRGB_G_GAIN, hasRGB_B_GAIN, hasRGB_EXPOSURE_TIME;
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, &hasRGB_ANALOG_GAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, &hasRGB_R_GAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, &hasRGB_G_GAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, &hasRGB_B_GAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, &hasRGB_EXPOSURE_TIME));
//	if (hasRGB_ANALOG_GAIN)  (TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, camPara.analog_gain));
//	if (hasRGB_R_GAIN)  (TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, camPara.r_gain));
//	if (hasRGB_G_GAIN)  (TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, camPara.g_gain));
//	if (hasRGB_B_GAIN)  (TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, camPara.b_gain));
//	if (hasRGB_EXPOSURE_TIME)  (TYSetInt(hDevice, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, camPara.exposure_time));
//	//try to enable depth cam
//	if (display_info) LOGD("=== Configure components, open depth cam");
//	int32_t componentIDs = TY_COMPONENT_DEPTH_CAM;
//	(TYEnableComponents(hDevice, componentIDs));
//	if (display_info) LOGD("=== Configure feature, set depth resolution");
//	(TYSetEnum(hDevice, TY_COMPONENT_DEPTH_CAM, TY_ENUM_IMAGE_MODE, camPara.depth_image_size));
//	if (display_info) LOGD("=== Get depth intrinsic");
//	(TYGetStruct(hDevice, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_depth, sizeof(intri_depth)));
//	std::cout << "intri_depth : [";
//	for (int i = 0; i < 9; i++) {
//		std::cout << intri_depth.data[i] << ",";
//	}
//	std::cout << "]\n";
//	if (display_info) LOGD("=== Read depth calib data");
//	(TYGetStruct(hDevice, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_CALIB_DATA, &cam.depth_calib, sizeof(cam.depth_calib)));
//	//adjust the gain and exposure of Left&Right IR camera
//	bool hasIR_ANALOG_GAIN, hasIR_GAIN, hasIR_EXPOSURE_TIME;
//	(TYHasFeature(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, &hasIR_ANALOG_GAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, &hasIR_GAIN));
//	(TYHasFeature(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, &hasIR_EXPOSURE_TIME));
//	if (hasIR_ANALOG_GAIN)
//	{
//		(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, camPara.analog_gain));
//		(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_ANALOG_GAIN, camPara.analog_gain));
//	}
//	if (hasIR_GAIN)
//	{
//		(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, camPara.lr_gain));
//		(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_GAIN, camPara.lr_gain));
//	}
//	if (hasIR_EXPOSURE_TIME)
//	{
//		(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, camPara.lr_exposure_time));
//		(TYSetInt(hDevice, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_EXPOSURE_TIME, camPara.lr_exposure_time));
//	}
//	//adjust the laser power
//	(TYSetInt(hDevice, TY_COMPONENT_LASER, TY_INT_LASER_POWER, 100));// range(0,100)
//   //Cmos sync switch,Closing the cmos sync can increase fps in 640*480 resolution,but may cause poor depth image.
//	TYSetBool(hDevice, TY_COMPONENT_DEVICE, TY_BOOL_CMOS_SYNC, false);
//	//stream async switch, see TY_STREAM_ASYNC_MODE
//	//TYSetEnum(hDevice, TY_COMPONENT_DEVICE, TY_ENUM_STREAM_ASYNC, TY_STREAM_ASYNC_OFF);
//
//	if (display_info) LOGD("=== Prepare image buffer");
//	uint32_t frameSize;
//	(TYGetFrameBufferSize(hDevice, &frameSize));
//	if (display_info) LOGD("     - Get size of framebuffer, %d", frameSize);
//	if (display_info) LOGD("     - Allocate & enqueue buffers");
//	char* frameBuffer[2];
//	frameBuffer[0] = new char[frameSize];
//	frameBuffer[1] = new char[frameSize];
//	if (display_info) LOGD("     - Enqueue buffer (%p, %d)", frameBuffer[0], frameSize);
//	(TYEnqueueBuffer(hDevice, frameBuffer[0], frameSize));
//	if (display_info) LOGD("     - Enqueue buffer (%p, %d)", frameBuffer[1], frameSize);
//	(TYEnqueueBuffer(hDevice, frameBuffer[1], frameSize));
//	if (display_info) LOGD("Register event callback");
//	(TYRegisterEventCallback(hDevice, TYCamera::eventCallback, NULL));
//	if (display_info) LOGD("=== enable trigger mode");
//	TY_TRIGGER_PARAM trigger;
//	trigger.mode = TY_TRIGGER_MODE_OFF;
//	//trigger.mode = TY_TRIGGER_MODE_SLAVE;
//	//Check whether a component has a specific feature
//	(TYSetStruct(hDevice, TY_COMPONENT_DEVICE, TY_STRUCT_TRIGGER_PARAM, &trigger, sizeof(trigger)));
//	//for network only
//	if (display_info) LOGD("=== resend: %d", resend);
//	if (resend) {
//		bool hasResend;
//		(TYHasFeature(hDevice, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, &hasResend));
//		if (hasResend) {
//			if (display_info) LOGD("=== Open resend");
//			(TYSetBool(hDevice, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, true));
//		}
//		else {
//			if (display_info) LOGD("=== Not support feature TY_BOOL_GVSP_RESEND");
//		}
//	}
//	if (display_info) LOGD("=== Start capture");
//	(TYStartCapture(hDevice));
//
//	//回调数据初始化
//	cam.hDev = hDevice;
//	float scale_unit = 1.;
//	cam.intri_depth = intri_depth;
//	cam.intri_color = intri_color;
//	TYGetFloat(hDevice, TY_COMPONENT_DEPTH_CAM, TY_FLOAT_SCALE_UNIT, &scale_unit);
//	cam.scale_unit = scale_unit;
//
//	LOGD("=== camera init done ===");
//}
//
//int TYCamera::CamMultiTuyangInit(const std::vector<CamPara>& paras, std::vector<char*>& list_ID, std::vector<CamInfo>& cams) {
//	int32_t deviceType = TY_INTERFACE_ETHERNET | TY_INTERFACE_USB;
//	int32_t cam_size = 0;
//	bool trigger_mode = true;
//
//	if (true) LOGD("=== Init lib");
//	//cout << "display_info: " << display_info << endl;
//	if (TYInitLib() != TY_STATUS_OK) { LOGD("初始化链接库失败"); TYDeinitLib(); return -1; };
//	TY_VERSION_INFO ver;
//	(TYLibVersion(&ver));
//	if (true) LOGD("     - lib version: %d.%d.%d", ver.major, ver.minor, ver.patch);
//	//获取设备信息
//	std::vector<TY_DEVICE_BASE_INFO> selected;
//	if (selectDevice(deviceType, "", "", 100, selected) == TY_STATUS_ERROR) { TYDeinitLib(); return -1; }
//	if (selected.size() >= list_ID.size()) {
//		cam_size = list_ID.size();
//	}
//	else {
//		if (display_info) { LOGD("===no find device in list"); };
//		TYDeinitLib();
//		std::cout << "not found camera..." << std::endl;
//		return -1;
//	}
//	int32_t count = 0;
//	for (uint32_t i = 0; i < list_ID.size(); i++) {
//		for (uint32_t j = 0; j < selected.size(); j++) {
//			if (display_info) LOGD("=== check device: %s, %s", list_ID[i], selected[j].id);
//			if (strcmp(list_ID[i], selected[j].id) == 0) {
//				if (display_info) LOGD("=== check device success");
//				if (display_info) LOGD("=== Open device: %s", selected[j].id);
//				(TYOpenInterface(selected[j].iface.id, &cams[count].hIface));
//				if (TYOpenDevice(cams[count].hIface, selected[j].id, &cams[count].hDev) != TY_STATUS_OK) { LOGD("camera is being opened"); TYDeinitLib(); return -1; }
//				TY_CAMERA_INTRINSIC intri_depth;
//				TY_CAMERA_INTRINSIC intri_color;
//				if (display_info) LOGD("=== Configure components, open RGB cam");
//				TY_COMPONENT_ID allComps;
//				(TYGetComponentIDs(cams[count].hDev, &allComps));
//				//try to enable color camera
//				if (allComps & TY_COMPONENT_RGB_CAM) {
//					int32_t image_mode;
//					if (display_info) LOGD("Has RGB camera, open RGB cam");
//					(TYEnableComponents(cams[count].hDev, TY_COMPONENT_RGB_CAM));
//					// (get_default_image_mode(cams[count].hDev, TY_COMPONENT_RGB_CAM, image_mode));
//					if (display_info) LOGD("=== Configure feature, set RGB resolution");
//					(TYSetEnum(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_ENUM_IMAGE_MODE, paras[count].color_image_size));
//					if (display_info) LOGD("=== Get color intrinsic");
//					(TYGetStruct(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_color, sizeof(intri_color)));
//					std::cout << "intri_color : [";
//					for (int i = 0; i < 9; i++) {
//						std::cout << intri_color.data[i] << ",";
//					}
//					std::cout << "]\n";
//					if (display_info) LOGD("=== Read color calib data");
//					(TYGetStruct(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_STRUCT_CAM_CALIB_DATA, &cams[count].color_calib, sizeof(cams[count].color_calib)));
//					//create a default isp handle for bayer rgb images
//					(TYISPCreate(&cams[count].IspHandle)); //create a default isp handle for bayer rgb images
//				   //cams.IspHandle = isp_handle;
//					(ColorIspInitSetting(cams[count].IspHandle, cams[count].hDev));
//					//You can turn on auto exposure function as follow ,but frame rate may reduce .
//					//Device also may be casually stucked  1~2 seconds when software trying to adjust device exposure time value
//#if 0
//					(ColorIspInitAutoExposure(IspHandle, hDevice));
//#endif
//					bool hasAUTOEXPOSURE, hasAUTOGAIN, hasAUTOAWB;
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, &hasAUTOEXPOSURE));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, &hasAUTOGAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, &hasAUTOAWB));
//					if (hasAUTOEXPOSURE)  (TYSetBool(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_EXPOSURE, true));//turn on AEC
//					if (hasAUTOGAIN)  (TYSetBool(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_GAIN, true));//turn on AGC
//					if (hasAUTOAWB)  (TYSetBool(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_BOOL_AUTO_AWB, true));//turn on AWB
//					bool hasRGB_ANALOG_GAIN, hasRGB_R_GAIN, hasRGB_G_GAIN, hasRGB_B_GAIN, hasRGB_EXPOSURE_TIME;
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, &hasRGB_ANALOG_GAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, &hasRGB_R_GAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, &hasRGB_G_GAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, &hasRGB_B_GAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, &hasRGB_EXPOSURE_TIME));
//					if (hasRGB_ANALOG_GAIN)  (TYSetInt(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_ANALOG_GAIN, paras[count].analog_gain));
//					if (hasRGB_R_GAIN)  (TYSetInt(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_R_GAIN, paras[count].r_gain));
//					if (hasRGB_G_GAIN)  (TYSetInt(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_G_GAIN, paras[count].g_gain));
//					if (hasRGB_B_GAIN)  (TYSetInt(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_B_GAIN, paras[count].b_gain));
//					if (hasRGB_EXPOSURE_TIME)  (TYSetInt(cams[count].hDev, TY_COMPONENT_RGB_CAM, TY_INT_EXPOSURE_TIME, paras[count].exposure_time));
//				}
//				//try to enable depth cam
//				if (allComps & TY_COMPONENT_DEPTH_CAM) {
//					if (display_info) LOGD("=== Configure components, open depth cam");
//					(TYEnableComponents(cams[count].hDev, TY_COMPONENT_DEPTH_CAM));
//					if (display_info) LOGD("=== Configure feature, set depth resolution");
//					(TYSetEnum(cams[count].hDev, TY_COMPONENT_DEPTH_CAM, TY_ENUM_IMAGE_MODE, paras[count].depth_image_size));
//					if (display_info) LOGD("=== Get depth intrinsic");
//					(TYGetStruct(cams[count].hDev, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_INTRINSIC, &intri_depth, sizeof(intri_depth)));
//					std::cout << "intri_depth : [";
//					for (int i = 0; i < 9; i++) {
//						std::cout << intri_depth.data[i] << ",";
//					}
//					std::cout << "]\n";
//					if (display_info) LOGD("=== Read depth calib data");
//					(TYGetStruct(cams[count].hDev, TY_COMPONENT_DEPTH_CAM, TY_STRUCT_CAM_CALIB_DATA, &cams[count].depth_calib, sizeof(cams[count].depth_calib)));
//					//adjust the gain and exposure of Left&Right IR camera
//					bool hasIR_ANALOG_GAIN, hasIR_GAIN, hasIR_EXPOSURE_TIME, hasSgbm;
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, &hasIR_ANALOG_GAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, &hasIR_GAIN));
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, &hasIR_EXPOSURE_TIME));
//
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_DEPTH_CAM, TY_INT_SGBM_SEMI_PARAM_P1_SCALE, &hasSgbm));
//					if (hasSgbm)
//					{
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_DEPTH_CAM, TY_INT_SGBM_SEMI_PARAM_P1_SCALE, 0));
//					}
//					if (hasIR_ANALOG_GAIN)
//					{
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_IR_CAM_LEFT, TY_INT_ANALOG_GAIN, paras[count].lr_analog_gain));
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_ANALOG_GAIN, paras[count].lr_analog_gain));
//					}
//					if (hasIR_GAIN)
//					{
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_IR_CAM_LEFT, TY_INT_GAIN, paras[count].lr_gain));
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_GAIN, paras[count].lr_gain));
//					}
//					if (hasIR_EXPOSURE_TIME)
//					{
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_IR_CAM_LEFT, TY_INT_EXPOSURE_TIME, paras[count].lr_exposure_time));
//						(TYSetInt(cams[count].hDev, TY_COMPONENT_IR_CAM_RIGHT, TY_INT_EXPOSURE_TIME, paras[count].lr_exposure_time));
//					}
//					//adjust the laser power
//					(TYSetInt(cams[count].hDev, TY_COMPONENT_LASER, TY_INT_LASER_POWER, 100));// range(0,100)
//				   //Cmos sync switch,Closing the cmos sync can increase fps in 640*480 resolution,but may cause poor depth image.
//				   //TYSetBool(cams[count].hDev, TY_COMPONENT_DEVICE, TY_BOOL_CMOS_SYNC, false);
//				   //stream async switch, see TY_STREAM_ASYNC_MODE
//				   //TYSetEnum(cams[count].hDevice, TY_COMPONENT_DEVICE, TY_ENUM_STREAM_ASYNC, TY_STREAM_ASYNC_OFF);
//				}
//
//				if (display_info) LOGD("=== Prepare image buffer");
//				uint32_t frameSize;
//				(TYGetFrameBufferSize(cams[count].hDev, &frameSize));
//				if (display_info) LOGD("     - Get size of framebuffer, %d", frameSize);
//				if (display_info) LOGD("     - Allocate & enqueue buffers");
//				cams[count].fb[0].resize(frameSize);
//				cams[count].fb[1].resize(frameSize);
//				if (display_info) LOGD("     - Enqueue buffer (%p, %d)", cams[count].fb[0].data(), frameSize);
//				(TYEnqueueBuffer(cams[count].hDev, cams[count].fb[0].data(), frameSize));
//				if (display_info) LOGD("     - Enqueue buffer (%p, %d)", cams[count].fb[1].data(), frameSize);
//				(TYEnqueueBuffer(cams[count].hDev, cams[count].fb[1].data(), frameSize));
//				if (display_info) LOGD("=== Register event callback");
//				(TYRegisterEventCallback(cams[count].hDev, eventCallback, NULL));
//				if (display_info) LOGD("=== Disable trigger mode");
//				TY_TRIGGER_PARAM trigger;
//				//连续采集模式			 
//				trigger.mode = TY_TRIGGER_MODE_OFF;
//				//软触发和硬触发模式					  
//				//trigger.mode = TY_TRIGGER_MODE_SLAVE;
//				(TYSetStruct(cams[count].hDev, TY_COMPONENT_DEVICE, TY_STRUCT_TRIGGER_PARAM, &trigger, sizeof(trigger)));
//				if (trigger_mode) {
//					bool hasResend;
//					(TYHasFeature(cams[count].hDev, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, &hasResend));
//					if (hasResend) {
//						if (display_info) LOGD("=== Open resend");
//						(TYSetBool(cams[count].hDev, TY_COMPONENT_DEVICE, TY_BOOL_GVSP_RESEND, true));
//					}
//					else {
//						if (display_info) LOGD("=== Not support feature TY_BOOL_GVSP_RESEND");
//					}
//				}
//				cams[count].intri_depth = intri_depth;
//				cams[count].intri_color = intri_color;
//				if (display_info) LOGD("=== Start capture");
//				(TYStartCapture(cams[count].hDev));
//				count++;
//			}
//		}
//	}
//	if (count != cam_size) {
//		if (display_info) LOGD("Invalid ids in input id list");
//		TYDeinitLib();
//		return -1;
//	}
//
//	LOGD("=== camera init done ===");
//	return 1;
//}
//
//int TYCamera::getCameraData(const CamPara& para, CamInfo& cam, cv::Mat& depth, cv::Mat& color, int32_t timeout) {
//	// 软触发模式
//	if (TYSendSoftTrigger(cam.hDev) != TY_STATUS_OK) {
//		return -1;
//	}
//	int err = TYFetchFrame(cam.hDev, &cam.frame, timeout);
//	if (err != TY_STATUS_OK)
//	{
//		if (display_info) LOGD("... Drop one frame");
//		return -1;
//	}
//	else
//	{
//		if (display_info) LOGD("... Got one frame");
//		FecthOneFrame(para, cam, depth, color);
//	}
//	RefreshFrameBuffer(cam);
//	return 1;
//}
//
//void TYCamera::TYCamClose(const CamInfo& cam) {
//	if (TYStopCapture(cam.hDev) != TY_STATUS_OK) { LOGD("TYStopCapture error..."); };
//	if (TYCloseDevice(cam.hDev) != TY_STATUS_OK) { LOGD("TYCloseDevice error..."); };
//	if ((TYCloseInterface(cam.hIface)) != TY_STATUS_OK) { LOGD("TYCloseInterface error..."); };
//	// (TYISPRelease(&cb_data.IspHandle));
//	if (TYDeinitLib() != TY_STATUS_OK) { LOGD("TYDeinitLib error..."); };
//	if (display_info) LOGD("=== camera closed!===");
//}
//
//void TYCamera::MultiTYCamsClose(const std::vector<CamInfo>& cams) {
//	LOGD("=== close cams device");
//	for (int i = 0; i < cams.size(); i++) {
//		if (TYStopCapture(cams[i].hDev) != TY_STATUS_OK) { LOGD("=== camera:%d closed failed!===", i); continue; };
//		(TYCloseDevice(cams[i].hDev));
//		(TYCloseInterface(cams[i].hIface));
//		//         (TYISPRelease(&cams[i].IspHandle));
//		//         (TYClearBufferQueue(cams[i].hDevice));
//				// (TYDisableComponents(cams[i].hDevice,componentIDs));
//	}
//	(TYDeinitLib());
//	LOGD("=== cameras closed!===");
//}
//
//int TYCamera::FecthOneFrame(const CamPara& camPara, CamInfo& camInfo, cv::Mat& depth, cv::Mat& color) {
//	parseFrame(camInfo.frame, &depth, 0, 0, &color); //depth:CV_16UC1,color:CV_8UC3
//	if (!depth.empty()) {
//		if (camPara.speckle_filter) {
//			TY_IMAGE_DATA tyFilteredDepth;
//			cv::Mat filteredDepth(depth.size(), depth.type());//
//			filteredDepth = depth.clone();
//			mat2TY_IMAGE_DATA(TY_COMPONENT_DEPTH_CAM, filteredDepth, tyFilteredDepth);
//			struct DepthSpeckleFilterParameters sfparam = DepthSpeckleFilterParameters_Initializer;
//			sfparam.max_speckle_size = 300;
//			sfparam.max_speckle_diff = 12;
//			TYDepthSpeckleFilter(&tyFilteredDepth, &sfparam);
//			depth = filteredDepth.clone();
//		}
//	}
//	cv::Mat color_data_mat;
//	if (!color.empty()) {
//		cv::Mat undistort_color, MappedDepth;
//		if (camPara.map_depth_to_color)
//		{
//			doRegister(camInfo.depth_calib, camInfo.color_calib, depth, camInfo.scale_unit, color, undistort_color, MappedDepth, camPara.map_depth_to_color);
//			//cv::cvtColor(undistort_color, color_data_mat, CV_BGR2RGB);
//			color = undistort_color;
//			depth = MappedDepth;
//		}
//		else
//		{
//			doRegister(camInfo.depth_calib, camInfo.color_calib, depth, camInfo.scale_unit, color, undistort_color, color_data_mat, camPara.map_depth_to_color);
//			//cv::cvtColor(color_data_mat, color_data_mat, CV_BGR2RGB);
//			color = color_data_mat;
//		}
//
//	}
//	return 1;
//}
//
//void TYCamera::RefreshFrameBuffer(const CamInfo& cam) {
//	//TYISPUpdateDevice(cb_data.IspHandle);
//	if (display_info) LOGD("Re-enqueue buffer(%p, %d)\r", cam.frame.userBuffer, cam.frame.bufferSize);
//	(TYEnqueueBuffer(cam.hDev, cam.frame.userBuffer, cam.frame.bufferSize));
//	TYISPUpdateDevice(cam.IspHandle);
//}