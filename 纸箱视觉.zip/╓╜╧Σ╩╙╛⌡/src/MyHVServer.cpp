#include "MyHVServer.h"

bool MyHvServer::iniServer(int port, const char* addr, int connect_num) {
	int listenfd = createsocket(port, addr);
	if (listenfd < 0) {
		return (false);
	}

	onConnection = [this](const SocketChannelPtr& channel) {

		if (channel->isConnected()) {
			std::string peeraddr = channel->peeraddr();
			printf("%s connected! connfd=%d\n", peeraddr.c_str(), channel->fd());
		}
		else {
			std::string peeraddr = channel->peeraddr();
			printf("%s disconnected! connfd=%d\n", peeraddr.c_str(), channel->fd());
		}
	};

	onMessage = [this](const SocketChannelPtr& channel, Buffer* buf) {
		//��ȡ
		SrvMessage_t _srv_msg;
		if (!buf->isNull()) {
			calls_mutex.lock();
			_srv_msg.data = buf->data();
			_srv_msg.size = buf->size();
			_srv_msg.isReadEnd = true;
			calls_mutex.unlock();
		}
		srv_msg = _srv_msg;
		//
	};

	setThreadNum(4);
	setMaxConnectionNum(connect_num);
	start();
	Sleep(1000);
	return (true);
}

int MyHvServer::RecvChar(char* msg) {
	int _flag = 0;
	for (;;) {
		if (isConnected() <= 0) return -1;
		_flag = readChar(msg);
		if (_flag == 0) {
			if (_block)
				continue;
			else
				return _flag;
		}
		else
		{
			return _flag;
		}
	}
}

int MyHvServer::RecvStr(std::string& msg) {
	int _flag = 0;
	for (;;) {
		if (isConnected() <= 0) return -1;
		_flag = readStr(msg);
		if (_flag == 0) {
			if (_block)
				continue;
			else
				return _flag;
		}
		else
		{
			return _flag;
		}
	}
}

int MyHvServer::readChar(char* msg) {
	if (srv_msg.isReadEnd == false) return 0;
	try {
		memcpy(msg, (char*)srv_msg.data, srv_msg.size);
	}
	catch (const exception& e) {
		//LOG_ERROR(e.what());
		cout << e.what() << endl;
		return -1;
	}
	calls_mutex.lock();
	srv_msg.isReadEnd = false;
	calls_mutex.unlock();
	return srv_msg.size;
}

int MyHvServer::readStr(std::string& str) {
	if (srv_msg.isReadEnd == false) return 0;
	try {
		if (srv_msg.size < 0 || srv_msg.size > 10000) {
			return 0;
		}
		str.assign((char*)srv_msg.data, 0, srv_msg.size);
	}
	catch (const exception& e) {
		//LOG_ERROR(e.what());
		cout << e.what() << endl;
		return -1;
	}
	calls_mutex.lock();
	srv_msg.isReadEnd = false;
	calls_mutex.unlock();
	return srv_msg.size;
}

int MyHvServer::SendStr(const string& str) {
	return (broadcast(str));
}

int MyHvServer::SendChar(const char* val, int size) {
	return(broadcast(val, size));
}

void MyHvServer::SetBlockMode(const bool block) {
	_block = block;
}

int MyHvServer::isConnected() {
	return connectionNum();
}

void MyHvServer::printHex(char* buff, int buff_len)
{
	std::cout << "hex : ";
	for (int i = 0; i < buff_len; i++) {
		std::cout << std::hex << (unsigned int)(unsigned char)buff[i] << " ";
	}
	std::cout << std::endl;
}