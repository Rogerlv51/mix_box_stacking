#include "MyHVClient.h"


bool MyHVClient::IniSocket(const int &port,
	const char*addr,
	int reconn_min_delay,
	int reconn_max_delay,
	int read_delay,
	int write_delay)
{
	int connfd = createsocket(port, addr);
	if (connfd < 0) {
		return (false);
	}
	reconn_setting_t reconn;
	reconn_setting_init(&reconn);
	reconn.min_delay = reconn_min_delay;
	reconn.max_delay = reconn_max_delay;
	reconn.delay_policy = 2;
	setReconnect(&reconn);
	//
	if (heartbeat_setting.size != 0) {
		setHeartBeat(&heartbeat_setting);
	}
	//
	setWriteTimeout(write_delay);
	//
	setReadTimeout(read_delay);
	//
	setReadCallback();
	//
	start();
	msleep(100);
	if (isConnected()) {
		Sleep(100);
		return true;
	}

	else {
		return false;
	}
		
}

void MyHVClient::setHeartBeatData( char *heartBeatData,int size,int heart_delay_ms) {
	heartbeat_setting.heart_delay_ms = heart_delay_ms;
	heartbeat_setting.heartBeatData = heartBeatData;
	heartbeat_setting.size = size;
}

int MyHVClient::SendChar(char* msg, size_t size) {
	if (!isConnected()) return -1;
	std::cout << "aaaa " << std::endl;
	buf.copy(msg, size);
	std::cout << "bbbb " << std::endl;
	//test
	//printHex(msg, size);
	return(send(&buf));
}

int MyHVClient::SendStr(const std::string &msg) {
	if (!isConnected()) return -1;
	return(send(msg));
}

int MyHVClient::setDataUnpack(void *) {


}

void MyHVClient::setReadCallback() {
	recv_msg.isReadEnd = false;
	onMessage = [this](const SocketChannelPtr& channel,Buffer* buf) {
		recvMessage_t _recv_msg;
		memset(&_recv_msg, 0, sizeof(_recv_msg));
		if (!buf->isNull()) {
			calls_mutex.lock();
			_recv_msg.data = buf->data();
			_recv_msg.size = buf->size();
			_recv_msg.isReadEnd = true;
			calls_mutex.unlock();			
		}
		recv_msg = _recv_msg;
	};
}

int MyHVClient::readChar(char *msg) {

	if (recv_msg.isReadEnd == false) return 0;
	memcpy(msg, (char*)recv_msg.data, recv_msg.size);
	recv_msg.isReadEnd = false;
	return recv_msg.size;
}

int MyHVClient::readStr(std::string& str) {

	if (recv_msg.isReadEnd == false) return 0;
	str.assign((char*)recv_msg.data,0, recv_msg.size);
	recv_msg.isReadEnd = false;
	return recv_msg.size;

}

int MyHVClient::RecvChar(char* msg) {
	int _flag = 0; 
	for (;;) {
		if (!isConnected()) return -1;
		_flag = readChar(msg);
		if (_flag <= 0) {
			if (_block)
				continue;
			else
				return _flag;
		}
		else
		{
			return _flag;
		}
	}
}

int MyHVClient::RecvStr(std::string& msg,INT32 timeout) {
	int _flag = 0;
	INT32 count = 0;
	for (;;) {
		if (timeout > 0) {
			if (count > timeout) {
				std::cout << "timeout count : " << count << std::endl;
				return 0;
			}
			count++;
		}
		if (!isConnected()) return -1;
		_flag = readStr(msg);
		if (_flag <= 0) {
			if (_block)
				continue;
			else
				return _flag;
		}
		else
		{
			return _flag;
		}
		Sleep(5);
	}
}

void MyHVClient::SetBlockMode(const bool block) {
	_block = block;
}

int MyHVClient::CloseSocket() {
	if (isConnected()) return -1;
	closesocket();
	return 1;
}

MyHVClient::~MyHVClient()
{

}

void MyHVClient::printHex(char* buff, int buff_len)
{
	std::cout << "hex : ";
	for (int i = 0; i < buff_len;i++) {
		std::cout << std::hex << (unsigned int)(unsigned char)buff[i] << " ";
	}
	std::cout << std::endl;
}

void MyHVClient::msleep(int time) {
#if defined(__linux__)
	// Linuxϵͳ
	usleep(time * 1000);
#elif defined(_WIN32)
	// Windowsϵͳ
	Sleep(time);
#endif
}

void MyHVClient::psleep(int time) {
#if defined(__linux__)
	// Linuxϵͳ
	sleep(time);
#elif defined(_WIN32)
	// Windowsϵͳ
	Sleep((time * 1000));
#endif
}
