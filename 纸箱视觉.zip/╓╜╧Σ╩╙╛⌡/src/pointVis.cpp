#include "pointVis.h"


PointVis::PointVis()
{
	for (int i = 0; i < isStop.size(); i++) {
		isStop[i] = false;
		isUpdate[i] = false;
		std::cout << "isStop is set false" << std::endl;
		pointcloud_ptr[i].reset(new pcl::PointCloud<pcl::PointXYZRGB>());
		pcl::PointXYZRGB p;
		p.x = 0.0;
		p.y = 0.0;
		p.z = 0.0;
		p.r = 255;
		p.g = 255;
		p.b = 255;
		pointcloud_ptr[i]->push_back(p);
	}

	//pointcloud_ptr->width = 1;
	//pointcloud_ptr->height = 1;
	std::cout << "pointcloud_ptr init" << std::endl;
}

PointVis::~PointVis()
{
}

/* ������ʾģ��ֹͣ */
/* �������ݸ��� */
void PointVis::iniWindows() {
		isStop.push_back(false);
		isUpdate.push_back(false);
		update_flag.push_back(false);
		window_lock.push_back(0);
		waitkey.push_back(10);
		pointcloud_ptr.resize(pointcloud_ptr.size()+1);
}

void PointVis::UpdatePoints(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,const int &ID,const int&wait_time)
{
	try {
		if (wait_time < 0) {
			std::cout << "wait_time error" << wait_time << endl;
			return;
		}
	}
	catch (const std::exception & e) {
		cout << e.what() << endl;
		return;
	}
	while (isUpdate[ID]) {
		if (!update_flag[ID]) { 
			//std::cout << "��⵽����" << ID << "δ������һ�ο��ӻ�,ǿ���˳�" << endl;
			break; 
		}
		Sleep(50);
	}
	std::unique_lock<std::mutex> lock(mutexUpdate, std::defer_lock);
	lock.lock();
	pointcloud_ptr[ID] = cloud;
	update_flag[ID] = false;
	window_lock[ID] = true;
	isUpdate[ID] = true;
	waitkey[ID] = wait_time;
	lock.unlock();
	if (wait_time == 0) {
		while (window_lock[ID])
		{
			Sleep(50);
		}
	}
}

/* ������ʾ */
void PointVis::Vis(const int &ID, const std::string &window_name)
{
	
	while (true) {
		//std::cout << "�����"<< ID+1 <<"���̵߳ļ���" << std::endl;
		if (isUpdate[ID]) {
			std::cout << "thread begin!" << std::endl;
			// viewerʵ����
			//	pcl::visualization::PCLVisualizer viewer("viewer");
			boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer(new pcl::visualization::PCLVisualizer(window_name));
			viewer->setBackgroundColor(0.8, 0.8, 0.65);
			viewer->addCoordinateSystem(1.0f);
			viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, window_name);
			viewer->initCameraParameters();
			std::cout << "viewer init!" << std::endl;
			while (true)
			{
				//cout << window_name<<"------ " << isUpdate[ID] << " -----" << endl;
				if (isStop[ID])
				{
					//std::cout << "viewer break!" << std::endl;
					break;
				}
				if (viewer->wasStopped()) {
					std::cout << "viewer window is closed..." << std::endl;
					viewer->removeAllCoordinateSystems();
					viewer->removeAllPointClouds();
					viewer->removeAllShapes();
					viewer->removeCorrespondences();
					viewer->removeOrientationMarkerWidgetAxes();
					viewer->removePolygonMesh();
					viewer->removeText3D();
					viewer->close();
					pointcloud_ptr[ID]->points.resize(0);
					pointcloud_ptr[ID]->points.reserve(0);
					break;
				}
				if (isUpdate[ID])
				{
					// ����ˢ��
					//std::cout << "�������"<< window_name << std::endl;
					std::unique_lock<std::mutex> lck(mutexUpdate, std::defer_lock);
					lck.lock();
					update_flag[ID] = true;
					viewer->removePointCloud(window_name);
					pcl::visualization::PointCloudColorHandlerRGBField<pcl::PointXYZRGB> rgb(pointcloud_ptr[ID]);
					viewer->addPointCloud<pcl::PointXYZRGB>(pointcloud_ptr[ID], rgb, window_name);
					//viewer->updatePointCloud<pcl::PointXYZRGB>(pointcloud_ptr, rgb, "jk cloud");
					isUpdate[ID] = false;
					lck.unlock();
				}
				//std::cout << "spinOnce" << window_name << std::endl;

				if (waitkey[ID]) {
					std::unique_lock<std::mutex> lock(mutexSpine, std::defer_lock);
					lock.lock();
					viewer->spinOnce(waitkey[ID]);
					lock.unlock();
				}
				else
				{
					std::unique_lock<std::mutex> lock(mutexSpine, std::defer_lock);
					lock.lock();
					viewer->spin();
					viewer->removeAllCoordinateSystems();
					viewer->removeAllPointClouds();
					viewer->removeAllShapes();
					viewer->removeCorrespondences();
					viewer->removeOrientationMarkerWidgetAxes();
					viewer->removePolygonMesh();
					viewer->removeText3D();
					viewer->close();
					pointcloud_ptr[ID]->clear();
					lock.unlock();
					window_lock[ID] = false;
					break;
				}
				
				std::this_thread::sleep_for(std::chrono::milliseconds(50));
			}
		}
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
	}
}


void PointVis::showPointCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud,const std::string &window_name,const int&wait_time) {
	try {
		if (wait_time < 0) {
			std::cout << "wait_time error" << wait_time << endl;
			return;
		}
	}
	catch (const std::exception & e) {
		cout << e.what() << endl;
		return;
	}
	if (windows_name.size()) {
		int flag = 0;
		for (int i = 0; i < windows_name.size(); i++) {
			if (windows_name[i] == window_name) {
				UpdatePoints(cloud,i, wait_time);
				flag = 1;
				return;
			}
		}
		int ID = visualizerThreads.size();
		iniWindows();
		windows_name.push_back(window_name);
		visualizerThreads.push_back(std::thread(&PointVis::Vis, this, ID, window_name));
		UpdatePoints(cloud, ID, wait_time);
		if (!visualizerThreads[ID].joinable()) {
			cout << "Thread creation failed." << endl;
			visualizerThreads[ID].join();
		}
	}
	else {
		iniWindows();
		windows_name.push_back(window_name);
		visualizerThreads.push_back(std::thread(&PointVis::Vis, this, 0, window_name));
		UpdatePoints(cloud, 0, wait_time);
		if (!visualizerThreads[0].joinable()) {
			throw std::invalid_argument("Thread creation failed.");
			visualizerThreads[0].join();
		}
	}
}