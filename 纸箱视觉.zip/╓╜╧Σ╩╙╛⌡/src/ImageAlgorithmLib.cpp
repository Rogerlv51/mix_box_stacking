#include "ImageAlgorithmLib.h"
using namespace imgLib;
/**
 * .
 * \brief ��������ת������
 * \param pixPos
 * \param camIntr
 * \param pos
 * \param rot
 * \return
 */
Eigen::Vector3d ImageAlgorithmlib::pix2BasePos(const Eigen::Vector3d pixPos, const Matrix3d camIntr, const Eigen::Vector3d pos, const Eigen::Vector3d rot) {
	//https://www.jianshu.com/p/4566a1281066
	Eigen::Matrix4d RT_mat = TransForms::ComposeEuler(pos[0], pos[1], pos[2], rot[0], rot[1], rot[2]);
	//cout << "RT_mat:\n" << RT_mat << endl;
	Eigen::Matrix3d R_mat = RT_mat.block<3, 3>(0, 0);
	Eigen::Matrix3d R_mat_inv = R_mat.inverse();
	Vector3d T_mat = RT_mat.block<3, 1>(0, 3);
	Eigen::Vector3d ImgPos(pixPos[0], pixPos[1], 1);
	Eigen::Vector3d CamPos;
	Eigen::Vector3d basePos;
	Eigen::Vector3d turnPos;
	CamPos = pixPos[2] * (camIntr.inverse() * ImgPos);
	//cout << "CamPos: " <<CamPos << endl;
	//basePos = R_mat_inv.transpose() * CamPos - R_mat_inv.transpose() * T_mat;

	
	basePos = R_mat_inv * CamPos - R_mat_inv * T_mat;
	turnPos = R_mat * (basePos + R_mat_inv * T_mat);
	//cout << "T_mat: " << T_mat << endl;
	//cout << "T*R_MAT: " << R_mat_inv * T_mat << endl;
	//cout << "ԭ��: " << CamPos << endl;
	//cout << "������: " << basePos << endl;
	//cout << "��ת: " << turnPos << endl;
	return basePos;
}

/**
 * .
 * \brief ��������ת������
 * \param pixPos
 * \param camIntr
 * \param pos
 * \param rot
 * \return
 */
Eigen::Vector3d ImageAlgorithmlib::cam2BasePos(const Eigen::Vector3d CamPos,const Eigen::Vector3d pos, const Eigen::Vector3d rot) {
	//https://www.jianshu.com/p/4566a1281066
	Eigen::Matrix4d RT_mat = TransForms::ComposeEuler(pos[0], pos[1], pos[2], rot[0], rot[1], rot[2]);
	Eigen::Matrix3d R_mat = RT_mat.block<3, 3>(0, 0);
	Eigen::Matrix3d R_mat_inv = R_mat.inverse();
	Vector3d T_mat = RT_mat.block<3, 1>(0, 3);
	
	Eigen::Vector3d basePos;
	Eigen::Vector3d turnPos;
	//cout << "CamPos: " <<CamPos << endl;
	//basePos = R_mat_inv.transpose() * CamPos - R_mat_inv.transpose() * T_mat;
	basePos = R_mat_inv * CamPos - R_mat_inv * T_mat;
	turnPos = R_mat * (basePos + R_mat_inv * T_mat);
	//cout << "T_mat: " << T_mat << endl;
	//cout << "T*R_MAT: " << R_mat_inv * T_mat << endl;
	//cout << "ԭ��: " << CamPos << endl;
	//cout << "������: " << basePos << endl;
	//cout << "��ת: " << turnPos << endl;
	return basePos;
}


Eigen::Vector3d ImageAlgorithmlib::base2CamPos(const Eigen::Vector3d basePos, const Eigen::Vector3d pos, Eigen::Vector3d rot) {
	Eigen::Matrix4d RT_mat = TransForms::ComposeEuler(pos[0], pos[1], pos[2], rot[0], rot[1], rot[2]);
	Eigen::Matrix3d R_mat = RT_mat.block<3, 3>(0, 0);
	Eigen::Matrix3d R_mat_inv = R_mat.inverse();
	Vector3d T_mat = RT_mat.block<3, 1>(0, 3);
	Eigen::Vector3d CamPos;
	CamPos = R_mat * (basePos + R_mat_inv * T_mat);
	return CamPos;
}

//cv::Point2f ImageAlgorithmlib::worldPoint2Image(const cv::Point3f& world, const float* intr) {
//	float x = world.x / world.z;
//	float y = world.y / world.z;
//	x = x * intr[0] + intr[2];
//	y = y * intr[4] + intr[5];
//	return Point2f(x, y);
//}


int ImageAlgorithmlib::getBoundingBox(RPointCloud::Ptr cloud_cluster, Eigen::Vector3f& box_size3D, Eigen::Vector3f& box_center3D, Eigen::Vector3f& angle3D) {
	//
	if (cloud_cluster->points.size() <= 0) {
		return 0;
	}
	RPointCloud::Ptr cloud_projected(new RPointCloud);
	cloud_projected = cloud_cluster;
	std::vector<int> mapping;
	pcl::removeNaNFromPointCloud(*cloud_projected, *cloud_projected, mapping);
	std::vector<cv::Point2f> pts_xy;

	/*cloudVisualizerRBG(cloud_cluster);*/
	float min_z = std::numeric_limits<float>::max();
	float max_z = -std::numeric_limits<float>::max();
	for (int i = 0; i < cloud_projected->size(); i++) {
		pts_xy.push_back(cv::Point2f(cloud_projected->points[i].x, cloud_projected->points[i].y));
		min_z = std::min(min_z, cloud_projected->points[i].z);
		max_z = std::max(max_z, cloud_projected->points[i].z);

	}
	//cv::blur(pts_xy, pts_xy, cv::Size(3, 3));
	cv::RotatedRect rect_xy = cv::minAreaRect(pts_xy);
	if (rect_xy.size.width < rect_xy.size.height) {
		rect_xy.angle -= 90;
		cv::swap(rect_xy.size.height, rect_xy.size.width);
	}
	box_size3D[0] = rect_xy.size.width;
	box_size3D[1] = rect_xy.size.height;
	box_size3D[2] = max_z - min_z;
	box_center3D[0] = rect_xy.center.x;
	box_center3D[1] = rect_xy.center.y;
	box_center3D[2] = (max_z + min_z) / 2.0;
	angle3D[0] = rect_xy.angle;
	angle3D[1] = 0;
	angle3D[2] = 0;
	return 1;
}


Eigen::Vector3d ImageAlgorithmlib::getRobotBasePos(const float* intr, const Eigen::Vector3d pixPos, const Eigen::Vector3d pos, Eigen::Vector3d rot) {
	Eigen::Matrix3d camIntr(3, 3);
	camIntr << intr[0], 0.0, intr[2], 0.0, intr[4], intr[5], 0.0, 0.0, 1.0;
	return pix2BasePos(pixPos, camIntr, pos, rot);
}
int ImageAlgorithmlib::depth2PointCloud(const float* intr, const cv::Mat& depth, const cv::Mat& color, RPointCloudPtr& cloud) {
	RPointCloud::Ptr m_cloud(new RPointCloud);
	m_cloud->resize(depth.size().area());  //������С
	m_cloud->points.resize(depth.rows * depth.cols);
	/// | fx|  0| cx|
	/// |  0| fy| cy|
	/// |  0|  0|  1|
	float cx = intr[2];
	float cy = intr[5];
	float inv_fx = intr[0];
	float inv_fy = intr[4];
	//cout << cx << " " << cy << " " << inv_fx << " " << inv_fy << endl;
	for (int r = 0; r < depth.rows; r++) {
		uint16_t* pSrc = (uint16_t*)depth.data + r * depth.cols;
		PointR p;
		for (int c = 0; c < depth.cols; c++)
		{
			uint16_t z = pSrc[c];
			//if (z == 0) continue;
			p.x = (c - cx) * z / inv_fx / 1000;
			p.y = (r - cy) * z / inv_fy / 1000;
			p.z = z * 1.0 / 1000;
			p.r = color.ptr<uchar>(r)[c * 3 + 2];
			p.g = color.ptr<uchar>(r)[c * 3 + 1];
			p.b = color.ptr<uchar>(r)[c * 3];
			//m_cloud->points.push_back(p);
			m_cloud->points[r * depth.cols + c] = p;
		}
	}
	m_cloud->height = 1;
	m_cloud->is_dense = false;
	cloud = m_cloud;
	return 1;
}

cv::Point2f ImageAlgorithmlib::worldPoint2Image(const cv::Point3f& world, const float* intr) {
	float x = world.x / world.z;
	float y = world.y / world.z;
	x = x * intr[0] + intr[2];
	y = y * intr[4] + intr[5];
	return Point2f(x, y);
}

int ImageAlgorithmlib::getBoxEuclideanClusterExtraction(RPointCloud::Ptr cloud_xyz, int euclid_min, int euclid_max, double euclid_radius, std::vector<pcl::PointIndices>& cluster_indices) {
	//ŷʽ����
	if (cloud_xyz->points.size() <= 0) {
		return 0;
	}
	pcl::search::KdTree<PointR>::Ptr tree(new pcl::search::KdTree<PointR>);
	tree->setInputCloud(cloud_xyz);
	std::vector<pcl::PointIndices> cluster_indice;
	pcl::EuclideanClusterExtraction<PointR> euclid;
	float in_max_cluster_distance = euclid_radius;
	int MIN_CLUSTER_SIZE = euclid_min;
	int MAX_CLUSTER_SIZE = euclid_max;
	euclid.setClusterTolerance(in_max_cluster_distance);
	euclid.setMinClusterSize(MIN_CLUSTER_SIZE);
	euclid.setMaxClusterSize(MAX_CLUSTER_SIZE);
	euclid.setSearchMethod(tree);
	euclid.setInputCloud(cloud_xyz);
	euclid.extract(cluster_indice);
	cluster_indices = cluster_indice;
	//cout << "��������� " << cluster_indice.size() << endl;
	return 1;
}


void ImageAlgorithmlib::rectLines(const vector<Point2f> vertexs, vector<Line>& lines) {
	lines.resize(4);
	float order[2] = { 0,0 };
	double max_distance = -0x3f3f3f3f;
	double min_distance = 0x3f3f3f3f;
	for (int i = 0; i < 2; i++) {
		float distance = sqrt(pow(vertexs[i].x - vertexs[i + 1].x, 2) + pow(vertexs[i].y - vertexs[i + 1].y, 2));
		if (max_distance < distance) { max_distance = distance; order[0] = i; }
		if (min_distance > distance) { min_distance = distance; order[1] = i; }
	}
	if (abs(min_distance - max_distance) < 0.001) { order[0] = 0; order[1] = 1; }
	for (int i = 0; i < 2; i++) {
		if (vertexs[order[i]].x - vertexs[order[i] + 1].x == 0) {
			double k = 0x3f3f3f3f;
			double b = vertexs[order[i]].x;
			lines[i * 2].K = k;
			lines[i * 2].B = b;
			k = 0x3f3f3f3f;
			b = vertexs[order[i] + 2].x;
			lines[i * 2 + 1].K = k;
			lines[i * 2 + 1].B = b;
		}
		else {
			double k = (vertexs[order[i]].y - vertexs[order[i] + 1].y) / (vertexs[order[i]].x - vertexs[order[i] + 1].x);
			double b = vertexs[order[i]].y - k * vertexs[order[i]].x;
			lines[i * 2].K = k;
			lines[i * 2].B = b;
			k = (vertexs[order[i] + 2].y - vertexs[order[i] + 1 + 2].y) / (vertexs[order[i] + 2].x - vertexs[order[i] + 1 + 2].x);
			b = vertexs[order[i] + 2].y - k * vertexs[order[i] + 2].x;
			lines[i * 2 + 1].K = k;
			lines[i * 2 + 1].B = b;
		}
	}

}


//0 ok��1�������϶Ѷ��ҵ�ǰ��λ������� 2ԭ��ƽ̨�³����������·ţ�������ǰ״̬ 3����������⣬������ǰ��λ��ȥ��һ������λ 4������ǰ��λ
int ImageAlgorithmlib::pointCheck(RPointCloudPtr& cloud, Point3f& box_center, double& transition_z, const double* size, const double& angle, double* offset, double max_height) {
	double box_z = box_center.z;
	int flag = 0;
	return 0;
	//for (int n = 0; n < 11; n++) {
	//	transition_z = 0.0;
	//	cout << "1111" << endl;
	//	RPointCloud::Ptr temp_paltform(new RPointCloud);
	//	RPointCloud::Ptr temp_obstacle(new RPointCloud);
	//	RPointCloud::Ptr mycloud(new RPointCloud);
	//	pcl::copyPointCloud(*cloud, *mycloud);


	//	vector<Point2f>vertex_box;
	//	//(n % 2)*((n + 1) / 2)
	//	//((n + 1) % 2)*((n + 1) / 2)
	//	//vertex_box.push_back(Point2f(box_center.x - stackSafeParam.size_accy[0] - size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - stackSafeParam.size_accy[1] - size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));
	//	//vertex_box.push_back(Point2f(box_center.x + stackSafeParam.size_accy[0] + size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - stackSafeParam.size_accy[1] - size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));
	//	//vertex_box.push_back(Point2f(box_center.x + stackSafeParam.size_accy[0] + size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + stackSafeParam.size_accy[1] + size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));
	//	//vertex_box.push_back(Point2f(box_center.x - stackSafeParam.size_accy[0] - size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + stackSafeParam.size_accy[1] + size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));

	//	// �����������λ�õ�ƽ̨����
	//	vertex_box.push_back(Point2f(box_center.x - size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));
	//	vertex_box.push_back(Point2f(box_center.x + size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));
	//	vertex_box.push_back(Point2f(box_center.x + size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));
	//	vertex_box.push_back(Point2f(box_center.x - size[0] * 0.5 + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * ((n + 1) / 2) * offset[1]));

	//	// �����������λ���Ƿ���ײ
	//	vector<Point2f>vertex_working;
	//	if (angle == 0) {
	//		vertex_working.push_back(Point2f(box_center.x - stackSafeParam.size_accy[0] - (size[0] * 0.5) + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - rbtHand.widthBias - stackSafeParam.size_accy[1] - size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//		vertex_working.push_back(Point2f(box_center.x - stackSafeParam.size_accy[0] - (size[0] * 0.5) + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + rbtHand.widthBias + stackSafeParam.size_accy[1] + size[1] * 0.5 + stackSafeParam.rbt_move_dis + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//		vertex_working.push_back(Point2f(box_center.x + stackSafeParam.size_accy[0] + (size[0] * 0.5) + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + rbtHand.widthBias + stackSafeParam.size_accy[1] + size[1] * 0.5 + stackSafeParam.rbt_move_dis + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//		vertex_working.push_back(Point2f(box_center.x + stackSafeParam.size_accy[0] + (size[0] * 0.5) + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - rbtHand.widthBias - stackSafeParam.size_accy[1] - size[1] * 0.5 + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//	}
	//	else {
	//		vertex_working.push_back(Point2f(box_center.x - stackSafeParam.size_accy[0] - size[0] * 0.5 - rbtHand.widthBias + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - stackSafeParam.size_accy[1] - (size[1] * 0.5) + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//		vertex_working.push_back(Point2f(box_center.x - stackSafeParam.size_accy[0] - size[0] * 0.5 - rbtHand.widthBias + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + stackSafeParam.size_accy[1] + (size[1] * 0.5) + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//		vertex_working.push_back(Point2f(box_center.x + stackSafeParam.size_accy[0] + size[0] * 0.5 + rbtHand.widthBias + stackSafeParam.rbt_move_dis + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y + stackSafeParam.size_accy[1] + (size[1] * 0.5) + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//		vertex_working.push_back(Point2f(box_center.x + stackSafeParam.size_accy[0] + size[0] * 0.5 + rbtHand.widthBias + stackSafeParam.rbt_move_dis + (n % 2) * ((n + 1) / 2) * offset[0], box_center.y - stackSafeParam.size_accy[1] - (size[1] * 0.5) + ((n + 1) % 2) * ((n + 1) / 2) * offset[1]));
	//	}
	//	double box_area = abs((vertex_box[0].x - vertex_box[1].x) * (vertex_box[1].y - vertex_box[2].y));
	//	double working_area = (vertex_working[0].x - vertex_working[3].x) * (vertex_working[0].y - vertex_working[1].y);

	//	//for (int i = 0; i < 4; i++) {
	//	//	cout <<"vertex_working: " << vertex_working[i] << endl;
	//	//}
	//	RPointCloud::Ptr cloud_working(new RPointCloud);
	//	//change������Ԥ��Ͷ��λ��һƬ���ƣ������˼�����
	//	double myPassthroughValue[6] = { -5.0,5.0,vertex_working[0].x,vertex_working[2].x, vertex_working[0].y,vertex_working[2].y };
	//	//passThroughFilter(mycloud, myPassthroughValue, cloud_working);

	//	//ptvisual.showPointCloud(cloud_working, "cloud_workingtest", 30);
	//	//system("pause");

	//	//TODO:�뾶�˲�
	//	RPointCloud::Ptr myObstacle(new RPointCloud);
	//	RPointCloud::Ptr myPlatform(new RPointCloud);

	//	//getBoxRadiusOutlierRemoval(cloud_working, 0.05, 20, cloud_working);
	//	//ptvisual.showPointCloud(cloud_working, "RadiusOutlierRemoval", 30);
	//	for (int i = 0; i < cloud_working->points.size(); i++) {
	//		//double pt2box_area = m_cal.getPoint2PolygonAcreage(Point2f(cloud_working->points[i].x, cloud_working->points[i].y), vertex_box);
	//		double pt2working_area = m_cal.getPoint2PolygonAcreage(Point2f(cloud_working->points[i].x, cloud_working->points[i].y), vertex_working);
	//		if (abs(pt2box_area - box_area) < 0.001) {
	//			myPlatform->points.push_back(cloud_working->points[i]);
	//			if (cloud_working->points[i].z - box_z < 0.03 && cloud_working->points[i].z - box_z>-0.06) {
	//				temp_paltform->points.push_back(cloud_working->points[i]);
	//				cloud_working->points[i].g = 0;
	//				cloud_working->points[i].b = 255;
	//			}
	//			else {
	//				cloud_working->points[i].r = 255;
	//				cloud_working->points[i].g = 241;
	//				cloud_working->points[i].b = 0;
	//			}
	//		}
	//		if (abs(pt2working_area - working_area) < 0.001) {
	//			if (cloud_working->points[i].z - box_z > 0.01) {
	//				myObstacle->points.push_back(cloud_working->points[i]);
	//				cloud_working->points[i].r = 125;
	//				cloud_working->points[i].g = 0;
	//				cloud_working->points[i].b = 0;
	//				if (abs(pt2box_area - box_area) < 0.001) {
	//					temp_obstacle->points.push_back(cloud_working->points[i]);
	//					cloud_working->points[i].r = 255;
	//					cloud_working->points[i].g = 0;
	//					cloud_working->points[i].b = 0;
	//				}
	//			}
	//		}
	//	}
	//	vertex_box.push_back(vertex_box[0]);
	//	vertex_working.push_back(vertex_working[0]);
	//	//int color[3] = { 0,0,255 };
	//	//drawBox(mycloud, vertex_working, 0.298, box_z + 0.298, color);
	//	Eigen::Vector3f box_size1, box_center1, angle1;

	//	//getBoundingBox(temp_paltform, box_size1, box_center1, angle1);
	//	/*if (getBoundingBox(temp_paltform, box_size1, box_center1, angle1) == RTN_ERROR) {
	//		box_size1[0] = 0.001;
	//		box_size1[1] = 0.001;
	//		box_size1[2] = 0.001;
	//	}*/
	//	PointR max_pt_obstacle;
	//	PointR min_pt_obstacle;
	//	//ptvisual.showPointCloud(mycloud, "mycloud", 30);
	//	//system("pause");
	//	bool ret = myObstacle->points.size() > 10;
	//	if (ret) {
	//		pcl::getMinMax3D(*myObstacle, min_pt_obstacle, max_pt_obstacle);
	//		transition_z = max_pt_obstacle.z;
	//		cout << "��⵽������Χ�����ϰ���߶�Ϊ: " << transition_z << endl;
	//	}
	//	int rgb[3] = { 255,255,255 };
	//	vertex_box.push_back(vertex_box[0]);
	//	//drawBox(cloud_working, vertex_box, 0, 0.298, box_z + 0.298, rgb);
	//	//drawLins(cloud_working, vertex_box, box_z, rgb);
	//	cout << "11111111" << endl;

	//	ptvisual.showPointCloud(cloud_working, "working", 30);
	//	system("pause");
	//	if (temp_obstacle->points.size() > 10) {
	//		Eigen::Vector3f box_size3D, box_center3D, angle3D;
	//		getBoundingBox(temp_obstacle, box_size3D, box_center3D, angle3D);
	//		PointR max_pt;
	//		PointR min_pt;
	//		pcl::getMinMax3D(*temp_obstacle, min_pt, max_pt);
	//		cout << "��⵽�ϰ���,�ߴ�Ϊ: " << box_size3D[0] << "," << box_size3D[1] << "," << box_size3D[2] << "," << max_pt.z << "," << box_center.z << "," << temp_obstacle->points.size() << endl;

	//		//int rgb[3] = { 255,255,255 };
	//		//vertex_box.push_back(vertex_box[0]);
	//		//drawBox(mycloud, vertex_box, 0.298, box_z + 0.298, rgb);
	//		//cout << "11111111" << endl;
	//		//ptvisual.showPointCloud(mycloud, "error", 30);

	//		//mycloud->width = mycloud->points.size();
	//		//mycloud->height = 1;
	//		//mycloud->is_dense = false;
	//		//string fliename = to_string(pic_num) + ".pcd";
	//		//pic_num++;
	//		//pcl::io::savePCDFile(fliename, *mycloud);
	//		//Sleep(1000);
	//		if (max_pt.z - box_center.z < 0.06) {
	//			cout << "��⵽�ϰ���߶�����ֵ��" << box_center.z << "," << max_pt.z << endl;
	//			box_z = max_pt.z;
	//			n -= 1;
	//			continue;
	//		}
	//		if (((box_size3D[0] * box_size3D[1]) / box_area > 0.6) && ((temp_obstacle->points.size() > (((box_size3D[0] * box_size3D[1]) / 0.0001) * 0.6)))) {
	//			PointR max_pt;
	//			PointR min_pt;
	//			pcl::getMinMax3D(*myObstacle, min_pt, max_pt);
	//			box_center.x = (vertex_box[0].x + vertex_box[2].x) / 2;
	//			box_center.y = (vertex_box[0].y + vertex_box[2].y) / 2;
	//			box_center.z = max_pt.z;// - size[2]
	//			cout << "���Լ������,����Ҫ������ǰ��λ,���º�zֵΪ��" << max_pt.z << endl;
	//			//LOG_ERROR("���Լ������,����Ҫ������ǰ��λ,���º�zֵΪ��" + to_string(max_pt.z));

	//			return 3;
	//		}
	//		continue;
	//	}
	//	cout << "ƽ̨���ռ��: " << (box_size1[0] * box_size1[1]) / box_area << endl;
	//	if (((box_size1[0] * box_size1[1]) / box_area < 0.6)) {
	//		//|| (temp_paltform->points.size() < (((box_size1[0] * box_size1[1]) / 0.01) *0.6))
	//		PointR max_pt;
	//		PointR min_pt;
	//		pcl::getMinMax3D(*myPlatform, min_pt, max_pt);
	//		max_pt.z = max_pt.z - 0.005;
	//		RPointCloud::Ptr temp_cloud(new RPointCloud);
	//		for (int i = 0; i < myPlatform->points.size(); i++) {
	//			if (myPlatform->points[i].z - max_pt.z < 0.03 && myPlatform->points[i].z - max_pt.z>-0.05) {
	//				temp_cloud->points.push_back(myPlatform->points[i]);
	//			}
	//		}
	//		Eigen::Vector3f box_size3D, box_center3D, angle3D;

	//		//int rgb[3] = { 255,255,255 };
	//		//vertex_box.push_back(vertex_box[0]);
	//		//drawBox(mycloud, vertex_box, 0.298, box_z + 0.298, rgb);
	//		//ptvisual.showPointCloud(mycloud, "error", 30);
	//		// 
	//		//cout << "33333333" << endl;
	//		//mycloud->width = mycloud->points.size();
	//		//mycloud->height = 1;
	//		//mycloud->is_dense = false;
	//		//string fliename = to_string(pic_num) + ".pcd";
	//		//pic_num++;
	//		//pcl::io::savePCDFile(fliename, *mycloud);
	//		//Sleep(500);
	//		if (getBoundingBox(temp_cloud, box_size3D, box_center3D, angle3D) == RTN_OK) {
	//			cout << "��⵽����ƽ̨�仯" << endl;
	//			//LOG_ERROR("��⵽����ƽ̨�仯");
	//			cout << "box_z: " << box_z << "," << max_pt << "\t" << min_pt << endl;
	//			cout << "size: " << box_size3D[0] * box_size3D[1] << "," << ((box_size3D[0] * box_size3D[1]) / 0.0001) * 0.6 << "," << temp_cloud->points.size() << endl;
	//			if (((box_size3D[0] * box_size3D[1]) / box_area > 0.6) && ((temp_cloud->points.size() > (((box_size3D[0] * box_size3D[1]) / 0.0001) * 0.6)))) {
	//				box_z = max_pt.z;
	//				cout << "��ƽ̨�������" << endl;
	//				if (flag == 0) {
	//					n -= 1;
	//					flag = 1;
	//				}
	//				continue;
	//			}
	//			else {
	//				cout << "��ƽ̨���������" << endl;
	//				//LOG_ERROR("��ƽ̨���������_box_area : " + to_string(box_area));
	//				LOG_ERROR("(box_size3D[0] * box_size3D[1]) / box_area :" + to_string((box_size3D[0] * box_size3D[1]) / box_area));

	//				//double percent = ((box_size3D[0] * box_size3D[1]) / box_area);
	//				//int time_now = NowTimeToInt();
	//				//string plyname = "pic/lap_change/" + to_string(time_now) + "_" + to_string(percent) + ".ply";
	//				//pcl::PCLPointCloud2 tmp;
	//				//
	//				//pcl::PLYWriter(plyname, *temp_cloud);

	//				continue;
	//			}
	//		}
	//		else {
	//			cout << "δ��⵽����ƽ̨" << endl;
	//			continue;
	//		}
	//	}
	//	else {

	//		box_center.x = (vertex_box[0].x + vertex_box[2].x) / 2;
	//		box_center.y = (vertex_box[0].y + vertex_box[2].y) / 2;
	//		if ((box_center.y + size[1] * 0.5 + 0.08) > 1.8) {
	//			cout << "��λy������ȫ��Χ : " << box_center.y + size[1] * 0.5 + 0.08 << "," << box_center.y << "," << size[1] * 0.5 << endl;
	//			//LOG_ERROR("��λy������ȫ��Χ");
	//			//return 4;
	//		}
	//		// �ϳ�ƽ��Ϊ0��
	//		if (box_center.z > max_height) {
	//			cout << "��λz������ȫ��Χ : " << box_center.z << endl;
	//			//LOG_ERROR("��λz������ȫ��Χ");
	//			return 4;
	//		}
	//		if (abs(box_center.z - box_z) > 0.25) {
	//			box_center.z = box_z;
	//			if (transition_z <= box_center.z) {
	//				transition_z = box_center.z + 0.02;
	//				cout << "���ɵ��������ͣ������������" << endl;
	//			}
	//			else {
	//				transition_z = transition_z + 0.02;
	//				cout << "���ɵ��������ߣ����ù��ɵ����" << endl;
	//			}
	//			cout << "���ɵ�Ϊ: " << transition_z << endl;
	//			return 2;
	//		}
	//		box_center.z = box_z;
	//		if (transition_z <= box_center.z) {
	//			transition_z = box_center.z + 0.02;
	//			cout << "���ɵ��������ͣ������������" << endl;
	//		}
	//		else {
	//			transition_z = transition_z + 0.02;
	//			cout << "���ɵ��������ߣ����ù��ɵ����" << endl;
	//		}
	//		cout << "���ɵ�Ϊ: " << transition_z << endl;
	//		cout << "�õ���ŵ�λ: " << box_center << endl;
	//		return 0;
	//	}
	//}
	//cout << "��λ�������,������ǰ��λ" << endl;
	//LOG_ERROR("��λ�������,������ǰ��λ");
	return 4;
}

void ImageAlgorithmlib::drawLins(RPointCloud::Ptr& cloud, vector<Point2f>vertex, double height, int* rgb) {

	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 2; j++) {
			for (int t = 0; t < 2; t++) {
				if (vertex[i].x - vertex[i + 1].x == 0) {
					if (vertex[i].y < vertex[i + 1].y) {
						//cout << "ѭ����ʼֵa: " << i << " " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i].y * 1000; n < vertex[i + 1].y * 1000; n += 5) {
							PointR p;
							PointT p1;
							p.x = vertex[i].x + (j - 1) * 0.002;
							p.y = n * 0.001 + (t - 1) * 0.002;
							p.z = height;
							p.r = rgb[0];
							p.g = rgb[1];
							p.b = rgb[2];
							cloud->points.push_back(p);
						}
					}
					else if (vertex[i].y > vertex[i + 1].y) {
						//cout << "ѭ����ʼֵb: " << i << " " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i + 1].y * 1000; n < vertex[i].y * 1000; n += 5) {
							PointR p;
							p.x = vertex[i + 1].x + (j - 1) * 0.002;
							p.y = n * 0.001 + (t - 1) * 0.002;
							p.z = height;
							p.z = height;
							p.r = rgb[0];
							p.g = rgb[1];
							p.b = rgb[2];
							cloud->points.push_back(p);
						}
					}
					continue;
				}
				float k = (vertex[i].y - vertex[i + 1].y) / (vertex[i].x - vertex[i + 1].x);
				float b = vertex[i].y - k * vertex[i].x;
				if (abs(k) < 1) {
					if (vertex[i].x <= vertex[i + 1].x) {
						//cout << "ѭ����ʼֵ1: " << k << " " << b << " " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i].x * 1000; n < vertex[i + 1].x * 1000; n += 2) {
							PointR p;
							p.x = n * 0.001 + (j - 1) * 0.002;
							p.y = (n * k * 0.001 + b) + (t - 1) * 0.002;
							p.z = height;
							p.z = height;
							p.r = rgb[0];
							p.g = rgb[1];
							p.b = rgb[2];
							cloud->points.push_back(p);
							//cout << n << " " << p << endl;
						}
					}
					else if (vertex[i].x > vertex[i + 1].x) {
						//cout << "ѭ����ʼֵ2: " << k << " " << b << " " << (int)(vertex[i+1].x * 1000) << " " << (int)(vertex[i].x * 1000) << endl;
						for (int n = vertex[i + 1].x * 1000; n < vertex[i].x * 1000; n += 2) {
							PointR p;
							p.x = n * 0.001 + (j - 1) * 0.002;
							p.y = (n * k * 0.001 + b) + (t - 1) * 0.002;
							p.z = height;
							p.z = height;
							p.r = rgb[0];
							p.g = rgb[1];
							p.b = rgb[2];
							cloud->points.push_back(p);
							//cout << n << " " << p << endl;
						}
					}
				}
				else {
					if (vertex[i].y <= vertex[i + 1].y) {
						//cout << "ѭ����ʼֵ3: " << k << " " << b <<  " " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i].y * 1000; n < vertex[i + 1].y * 1000; n += 2) {
							PointR p;
							p.x = (n * 0.001 - b) / k + (j - 1) * 0.002;
							p.y = n * 0.001 + (t - 1) * 0.002;
							p.z = height;
							p.z = height;
							p.r = rgb[0];
							p.g = rgb[1];
							p.b = rgb[2];
							cloud->points.push_back(p);
							//cout << n << " " << p << endl;
						}
					}
					else if (vertex[i].y > vertex[i + 1].y) {
						//cout << "ѭ����ʼֵ4: " << k << " " << b <<" "  << (int)(vertex[i + 1].x * 1000) << " " << (int)(vertex[i].x * 1000) << endl;
						for (int n = vertex[i + 1].y * 1000; n < vertex[i].y * 1000; n += 2) {
							PointR p;
							p.x = (n * 0.001 - b) / k + (j - 1) * 0.002;
							p.y = n * 0.001 + (t - 1) * 0.002;
							p.z = height;
							p.z = height;
							p.r = rgb[0];
							p.g = rgb[1];
							p.b = rgb[2];
							cloud->points.push_back(p);
							//cout << n << " " << p << endl;
						}
					}
				}


			}
		}
	}
	//cout << "������..." << endl;
}


void ImageAlgorithmlib::rectVertex(const double width, const double length, const double biasAngle, const Point2f rect_center, vector<Point2f>& rect) {
	Point2f vertex;
	double rect_angle = atan(width / length);
	double Diagonal = sqrt(pow(width, 2) + pow(length, 2));
	vertex.x = rect_center.x + Diagonal * cos(rect_angle + biasAngle);
	vertex.y = rect_center.y - Diagonal * sin(rect_angle + biasAngle);
	rect.push_back(vertex);
	vertex.x = rect_center.x + Diagonal * cos(rect_angle - biasAngle);
	vertex.y = rect_center.y + Diagonal * sin(rect_angle - biasAngle);
	rect.push_back(vertex);
	vertex.x = rect_center.x - Diagonal * cos(rect_angle + biasAngle);
	vertex.y = rect_center.y + Diagonal * sin(rect_angle + biasAngle);
	rect.push_back(vertex);
	vertex.x = rect_center.x - Diagonal * cos(rect_angle - biasAngle);
	vertex.y = rect_center.y - Diagonal * sin(rect_angle - biasAngle);
	rect.push_back(vertex);
	return;
}



void ImageAlgorithmlib::drawBox(RPointCloud::Ptr& cloud, vector<Point2f>vertex, double angle, double box_height, double height, int* rgb) {
	double box_angle = angle * M_PI / 180;
	cout << "box_angle:" << angle << endl;
	double box_length = sqrt(pow(vertex[1].x - vertex[0].x, 2) + pow(vertex[1].y - vertex[0].y, 2));
	double box_width = sqrt(pow(vertex[2].x - vertex[1].x, 2) + pow(vertex[2].y - vertex[1].y, 2));
	//for (int i = 0; i < box_length * 1000; i += 5) {
	//	for (int j = 0; j < box_width * 1000; j += 5) {
	//		PointR p;
	//		p.x = vertex[0].x + i / 1000.0/* * cos(box_angle)*/;
	//		p.y = vertex[0].y - i / 1000.0 /** sin(box_angle)*/;
	//		p.y = p.y + j / 1000.0 /** cos(box_angle)*/;
	//		p.x = p.x + j / 1000.0 /** sin(box_angle)*/;
	//		p.z = height - box_height;
	//		p.r = rgb[0];
	//		p.g = rgb[1];
	//		p.b = rgb[2];
	//		cloud->points.push_back(p);
	//		//p.x = vertex[0].x + i / 1000.0*cos(box_angle);
	//		//p.y = vertex[0].y - i / 1000.0*sin(box_angle);
	//		//p.y = p.y + j / 1000.0*cos(box_angle);
	//		//p.x = p.x + j / 1000.0*sin(box_angle);
	//		//p.z = height;
	//		//p.r = rgb[0];
	//		//p.g = rgb[1];
	//		//p.b = rgb[2];
	//		//cloud->points.push_back(p);
	//	}
	//}
	for (int i = 0; i < 4; i++) {
		for (int j = 0; j < 1; j++) {
			for (int t = 0; t < 1; t++) {
				if (vertex[i].x - vertex[i + 1].x == 0) {
					if (vertex[i].y < vertex[i + 1].y) {
						for (int n = vertex[i].y * 1000; n < vertex[i + 1].y * 1000; n += 5) {
							for (int m = 0; m < box_height * 1000; m += 5) {
								PointR p;
								p.x = vertex[i].x + (j - 1) * 0.002;
								p.y = n * 0.001 + (t - 1) * 0.002;
								p.z = height - m / 1000.0;
								p.r = rgb[0];
								p.g = rgb[1];
								p.b = rgb[2];
								cloud->points.push_back(p);

							}

						}
					}
					else if (vertex[i].y > vertex[i + 1].y) {
						for (int n = vertex[i + 1].y * 1000; n < vertex[i].y * 1000; n += 5) {
							for (int m = 0; m < box_height * 1000; m += 5) {
								PointR p;
								p.x = vertex[i + 1].x + (j - 1) * 0.002;
								p.y = n * 0.001 + (t - 1) * 0.002;
								p.z = height - m / 1000.0;
								p.r = rgb[0];
								p.g = rgb[1];
								p.b = rgb[2];
								cloud->points.push_back(p);
							}

						}
					}
					continue;
				}
				float k = (vertex[i].y - vertex[i + 1].y) / (vertex[i].x - vertex[i + 1].x);
				float b = vertex[i].y - k * vertex[i].x;
				if (abs(k) < 1) {
					if (vertex[i].x <= vertex[i + 1].x) {
						//cout << "ѭ����ʼֵ: " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i].x * 1000; n < vertex[i + 1].x * 1000; n += 5) {
							for (int m = 0; m < box_height * 1000; m += 5) {
								PointR p;
								p.x = n * 0.001 + (j - 1) * 0.002;
								p.y = (n * k * 0.001 + b) + (t - 1) * 0.002;
								p.z = height - m / 1000.0;
								p.r = rgb[0];
								p.g = rgb[1];
								p.b = rgb[2];
								cloud->points.push_back(p);
							}

						}
					}
					else if (vertex[i].x > vertex[i + 1].x) {
						//cout << "ѭ����ʼֵ: " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i + 1].x * 1000; n < vertex[i].x * 1000; n += 5) {
							for (int m = 0; m < box_height * 1000; m += 5) {
								PointR p;
								p.x = n * 0.001 + (j - 1) * 0.002;
								p.y = (n * k * 0.001 + b) + (t - 1) * 0.002;
								p.z = height - m / 1000.0;
								p.r = rgb[0];
								p.g = rgb[1];
								p.b = rgb[2];
								cloud->points.push_back(p);
							}

						}
					}
				}
				else {
					if (vertex[i].y <= vertex[i + 1].y) {
						//cout << "ѭ����ʼֵ: " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i].y * 1000; n < vertex[i + 1].y * 1000; n += 4) {
							for (int m = 0; m < box_height * 1000; m += 4) {
								PointR p;
								p.x = (n * 0.001 - b) / k + (j - 1) * 0.002;
								p.y = n * 0.001 + (t - 1) * 0.002;
								p.z = height - m / 1000.0;
								p.r = rgb[0];
								p.g = rgb[1];
								p.b = rgb[2];
								cloud->points.push_back(p);

							}
						}
					}
					else if (vertex[i].x > vertex[i + 1].x) {
						//cout << "ѭ����ʼֵ: " << (int)(vertex[i].x * 1000) << " " << (int)(vertex[i + 1].x * 1000) << endl;
						for (int n = vertex[i + 1].y * 1000; n < vertex[i].y * 1000; n += 4) {
							for (int m = 0; m < box_height * 1000; m += 4) {
								PointR p;
								p.x = (n * 0.001 - b) / k + (j - 1) * 0.002;
								p.y = n * 0.001 + (t - 1) * 0.002;
								p.z = height - m / 1000.0;
								p.r = rgb[0];
								p.g = rgb[1];
								p.b = rgb[2];
								cloud->points.push_back(p);
							}
						}
					}
				}
			}
		}
	}
}


int ImageAlgorithmlib::trailerPointsDesign(const RPointCloudPtr& cloud, int trailer_state[], vector<vector<vector<cv::Point3f>>>& saved_points, vector<vector<vector<cv::Point3f>>>& box_size,
	const int* boxsum, PackageInfo& package, int& boxnumthreshold,Point3f& box_center, float& angle, std::vector<cv::Point3f> bufferplane_vertex) {
	//cout << "ƫת����: " << sin(trailer.angle) << " " << cos(trailer.angle) << " " << tan(cos(trailer.angle)) << endl;
	Point3f temp_point;
	virtual_box temp_virtual_box;
	int wherestack = 0;
	//stackSafeParam.rbt_move_dis = 0.15;

	//���������ֵ
	Eigen::Vector3d robothand_start;
	robothand_start[0] = 246.60;//�����˵����굥λ
	robothand_start[1] = -2030;//�����˵����굥λ
	robothand_start[2] = -300;//�����˵����굥λ-211.68 -11

	trailer.normalBagRoi.resize(4);
	trailer.normalBagRoi[0].x = robothand_start[0] + stackSafeParam.large_roi[0];
	trailer.normalBagRoi[0].y = robothand_start[1] - stackSafeParam.large_roi[1];
	/*trailer.normalBagRoi[1].x = bufferplane_vertex[1].x;
	trailer.normalBagRoi[1].y = bufferplane_vertex[1].y;
	trailer.normalBagRoi[2].x = bufferplane_vertex[2].x;
	trailer.normalBagRoi[2].y = bufferplane_vertex[2].y;
	trailer.normalBagRoi[3].x = bufferplane_vertex[3].x;
	trailer.normalBagRoi[3].y = bufferplane_vertex[3].y;*/

	//������
	double stack_length = 1.30;
	double stack_width = 1.30;
	double stack_height = 1.00;


	//����������������óߴ�ֽ��������
	double nx = (stack_height / (package.size[2]*0.001));//��
	double mx = (stack_length / (package.size[0]*0.001));//��
	double kx = (stack_width / (package.size[1]*0.001));//��

	cout << "double ����ֵ��" << nx << " " << mx << " " << kx << endl;
	int n = 0;//��
	int m = 0;//��
	int k = 0;//��

	if (abs(nx - int(nx)) < 0.8) {
		n = int(nx);
	}
	else {
		n = int(nx) + 1;
	}
	if (abs(mx - int(mx)) < 0.8) {
		m = int(mx);
	}
	else {
		m = int(mx) + 1;
	}
	if (abs(kx - int(kx)) < 0.8) {
		k = int(kx);
	}
	else {
		k = int(kx) + 1;
	}

	boxnumthreshold = n * m * k;
	stackSafeParam.bias_bag[0] = package.size[0];
	stackSafeParam.bias_bag[1] = package.size[1];



	/*cout << "������" << bufferplane_vertex[0].x << " " << bufferplane_vertex[0].y << endl;*/
	cout << "������" << trailer.normalBagRoi[0].x << " " << trailer.normalBagRoi[0].y<<" "<< robothand_start[2] << endl;
	cout << "�ߴ�" << package.size[0] << " " << package.size[1] << " " << package.size[2] << endl;
	cout<<  "����" << boxsum[0] << " " << boxsum[1] << " " << boxsum[2] << endl;
	cout << "��ƫ��" << stackSafeParam.bias_bag[0] << " " << stackSafeParam.bias_bag[1] << endl;
	//����ֽ��ߴ綯̬��ʼ����λ
	//����һ��n*n*n������������ƥ���λ
	int floor =trailer_state[0];// �ڼ���
	int row = trailer_state[1];// �ڼ���
	int col = trailer_state[2];// �ڼ���

	cout << "��ǰ״̬Ϊ: " << floor << " " << row << " " << col << endl;
	n = n - 1;
	m = m - 1;
	k = k - 1;
	//��ת����
	RPointCloud::Ptr temp_cloud(new RPointCloud);
	*temp_cloud=*cloud;

	/*Eigen::Matrix3d R_mat = trailer.RT_mat.block<3, 3>(0, 0);
	Eigen::Matrix3d R_mat_inv = R_mat.inverse();
	Vector3d T_mat = trailer.RT_mat.block<3, 1>(0, 3);
	temp_cloud->points.resize(cloud->points.size());*/
	/*for (int i = 0; i < cloud->points.size(); i++) {
		Eigen::Vector3d pixPos;
		pixPos(0) = cloud->points[i].x;
		pixPos(1) = cloud->points[i].y;
		pixPos(2) = cloud->points[i].z;
		Eigen::Vector3d basePos = R_mat * pixPos + T_mat;
		temp_cloud->points[i].x = basePos(0);
		temp_cloud->points[i].y = basePos(1);
		temp_cloud->points[i].z = basePos(2);
		temp_cloud->points[i].r = cloud->points[i].r;
		temp_cloud->points[i].g = cloud->points[i].g;
		temp_cloud->points[i].b = cloud->points[i].b;
	}*/
	double pi = atan(1.0) * 4;
	angle = 0.0;
	if (floor == 0) {
		//��һ�е�һ��
		if (floor + row + col == 0) {
			if (package.size[0] < 1200 && package.size[1] < 1200 && package.size[2] < 1000) {
				box_center.x = trailer.normalBagRoi[0].x/* - stackSafeParam.bias_bag[1] * 0.5 * cos(5 * pi / 180)*/;
				box_center.y = trailer.normalBagRoi[0].y/* + stackSafeParam.bias_bag[0] * 0.5*/;
				box_center.z = robothand_start[2]+package.size[2];//�����˵�z
			}
			else {
				return 0;
			}
			//λ��
			trailer_state[0] = floor;
			trailer_state[1] = 0;
			trailer_state[2] = 1;
			//�洢��
			saved_points[floor][row][col] = box_center;
			box_size[floor][row][col] = Point3f(package.size[0], package.size[1], package.size[2]);
			return 1;
		}
		//��һ���һ�е�һ�м��������
		if (row == 0 && col >= 1 && col <= k) {
			if (package.size[0] < 1200 && package.size[1] < 1200 && package.size[2] < 1000) {
				box_center.x = saved_points[floor][row][col - 1].x - stackSafeParam.bias_bag[1] * 0.5/* * cos(5 * pi / 180)*/ - stackSafeParam.bias_bag[1] * 0.5/* * cos(5 * pi / 180)*/ - stackSafeParam.palletize_interval_X;
				box_center.y = saved_points[floor][row][col - 1].y/* + stackSafeParam.bias_bag[1] * 0.5 + stackSafeParam.bias_bag[1] * 0.5 + stackSafeParam.palletize_interval_Y*/;
				box_center.z = robothand_start[2] +package.size[2];//�����˵�z
			}
			else {
				return 0;
			}
			if (col < k) {
				trailer_state[0] = floor;
				trailer_state[1] = 0;
				trailer_state[2] += 1;
			}
			else {
				trailer_state[0] = floor;
				trailer_state[1] = 1;
				trailer_state[2] = 0;
			}
			saved_points[floor][row][col] = box_center;
			box_size[floor][row][col] = Point3f(package.size[0], package.size[1], package.size[2]);
			return 1;
		}
		//��һ���2�м����� ��2��������
		if (row >= 1 && row <= m && col >= 0 && col <= k) {
			if (package.size[0] < 1200 && package.size[1] < 1200 && package.size[2] < 1000) {
				box_center.x = saved_points[floor][row - 1][col].x;
				box_center.y = saved_points[floor][row - 1][col].y + stackSafeParam.bias_bag[0] * 0.5 * cos(5 * pi / 180) + stackSafeParam.bias_bag[0] * 0.5 * cos(5 * pi / 180) + stackSafeParam.palletize_interval_Y;
				box_center.z = robothand_start[2] + package.size[2];//�����˵�z
				cout << "box_center.x " << box_center.x << " box_center.y " << box_center.y << endl;
			}
			else {
				return 0;
			}
			if (col <k && row < m) {
				trailer_state[0] = floor;
				trailer_state[1] = row;
				trailer_state[2] += 1;
			}
			else if(col==k && row <m){
				trailer_state[0] = floor;
				trailer_state[1] += 1;
				trailer_state[2] = 0;
			}else if(col==k && row==m){
				trailer_state[0] = floor+1;
				trailer_state[1] = 0;
				trailer_state[2] = 0;
			}
			else if (col<k&& row==m) {
				trailer_state[0] = floor;
				trailer_state[1] = row;
				trailer_state[2] +=1;
			}

			saved_points[floor][row][col] = box_center;
			box_size[floor][row][col] = Point3f(package.size[0], package.size[1], package.size[2]);
			return 1;
		}
	}
	if (floor >= 1&&floor<=n) {
		//��һ�е�һ��
		if (row + col == 0) {
			if (package.size[0] < 1200 && package.size[1] < 1200 && package.size[2] < 1000) {
				box_center.x = saved_points[floor-1][row][col].x;
				box_center.y = saved_points[floor-1][row][col].y;
				box_center.z = saved_points[floor - 1][row][col].z+ package.size[2]+ 20;
			}
			else {
				return 0;
			}
			//λ��
			trailer_state[0] = floor;
			trailer_state[1] = 0;
			trailer_state[2] = 1;
			//�洢��
			saved_points[floor][row][col] = box_center;
			box_size[floor][row][col] = Point3f(package.size[0], package.size[1], package.size[2]);
			return 1;
		}
		
		if (row == 0 && col >= 1 && col <= k) {
			if (package.size[0] < 1200 && package.size[1] < 1200 && package.size[2] < 1000) {
				box_center.x = saved_points[floor][row][col - 1].x - stackSafeParam.bias_bag[1] * 0.5/* * cos(5 * pi / 180)*/ - stackSafeParam.bias_bag[1] * 0.5/* * cos(5 * pi / 180)*/ - stackSafeParam.palletize_interval_X;
				box_center.y = saved_points[floor][row][col - 1].y /*+ stackSafeParam.bias_bag[1] * 0.5 + stackSafeParam.bias_bag[1] * 0.5 + stackSafeParam.palletize_interval_Y*/;
				box_center.z = saved_points[floor - 1][row][col].z + package.size[2] + 20;
			}
			else {
				return 0;
			}
			if (col < k) {
				trailer_state[0] = floor;
				trailer_state[1] = 0;
				trailer_state[2] += 1;
			}
			else {
				trailer_state[0] = floor;
				trailer_state[1] = 1;
				trailer_state[2] = 0;
			}
			saved_points[floor][row][col] = box_center;
			box_size[floor][row][col] = Point3f(package.size[0], package.size[1], package.size[2]);
			return 1;
		}

		//��һ���2�м����� ��2��������
		if (row >= 1 && row <= m && col >= 0 && col <= k) {
			if (package.size[0] < 1200 && package.size[1] < 1200 && package.size[2] < 1000) {
				box_center.x = saved_points[floor][row - 1][col].x;
				box_center.y = saved_points[floor][row - 1][col].y + stackSafeParam.bias_bag[0] * 0.5 * cos(5 * pi / 180) + stackSafeParam.bias_bag[0] * 0.5 * cos(5 * pi / 180) + stackSafeParam.palletize_interval_Y;
				box_center.z = saved_points[floor - 1][row][col].z + package.size[2] + 20;
			}
			else {
				return 0;
			}
			if (col < k && row < m) {
				trailer_state[0] = floor;
				trailer_state[1] = row;
				trailer_state[2] += 1;
			}
			else if (col == k && row < m) {
				trailer_state[0] = floor;
				trailer_state[1] += 1;
				trailer_state[2] = 0;
			}
			else if (col == k && row == m) {
				trailer_state[0] = floor + 1;
				trailer_state[1] = 0;
				trailer_state[2] = 0;
			}
			else if (col < k && row == m) {
				trailer_state[0] = floor;
				trailer_state[1] = row;
				trailer_state[2] += 1;
			}

			saved_points[floor][row][col] = box_center;
			box_size[floor][row][col] = Point3f(package.size[0], package.size[1], package.size[2]);
			return 1;
		}
	}

	

}