#include "serversocket.h"
#include <iostream>


CServerSocket::CServerSocket()
{
	clientSocket = INVALID_SOCKET;
}

CServerSocket::~CServerSocket()
{
}

int CServerSocket::Initial()
{
	// 1 ����socket�⣬�汾Ϊ2.0
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	wVersionRequested = MAKEWORD(2, 0);
	err = WSAStartup(wVersionRequested, &wsaData);
	if (err != 0)
	{
		std::cout << "Socket2.0��ʼ��ʧ�ܣ�Exit!"<<std::endl;
		return 0;
	}

	if (LOBYTE(wsaData.wVersion) != 2 || HIBYTE(wsaData.wVersion) != 0)
	{
		WSACleanup();
		return 0;
	}
	return 1;
}

int CServerSocket::GetLastError()
{
	// WSAEWOULDBLOCK;
	// WSAETIMEDOUT;
	// WSAENETDOWN;
	return WSAGetLastError();
}

int CServerSocket::IsSocketClosed()
{
	int ret = 0;
	if (clientSocket == INVALID_SOCKET) {
		std::cout << "no Client socket\n";
		return 1;
	}

	HANDLE closeEvent = WSACreateEvent();
	WSAEventSelect(clientSocket, closeEvent, FD_CLOSE);

	DWORD dwRet = WaitForSingleObject(closeEvent, 0);

	if (dwRet == WSA_WAIT_EVENT_0)
		ret = 1;
	else if (dwRet == WSA_WAIT_TIMEOUT)
		ret = 0;

	WSACloseEvent(closeEvent);
	return ret;
}

int CServerSocket::SetBlockMode(int mode)
{
	unsigned long ul;
	ul = mode ? 1 : 0;  // 0--block,1--no block
	if (server == INVALID_SOCKET) return 1;
	ioctlsocket(server, FIONBIO, &ul);
	return 1;
}


int CServerSocket::StartServer(u_short port)
{
	// 1 ����socket�⣬�汾Ϊ2.0
	Initial();

	//2.�����׽���,���ڼ���
	server = socket(AF_INET, SOCK_STREAM, 0);
	if (server == INVALID_SOCKET)
	{
		//		cout << "Socket ����ʧ�ܣ�Exit!";
		return 0;
	}

	//3.��
	SOCKADDR_IN serverAddr; //sockaddr_in�൱��sockaddr�ṹ
	memset(&serverAddr, 0, sizeof(serverAddr));//��ʼ��  ���� 
	serverAddr.sin_family = AF_INET;//ֻ��Ϊ���ֵ
	serverAddr.sin_addr.S_un.S_addr = htonl(INADDR_ANY);//��u_long��ת��Ϊ�����ֽ�����
	serverAddr.sin_port = htons(port);// ��u_short��ת��Ϊ�����ֽ�����

	int rtn = bind(server, (SOCKADDR*)&serverAddr, sizeof(serverAddr));//���׽���
	if (rtn != 0) return 0;
	//4.���ü���
	listen(server, 5);
	return 1;
}

int CServerSocket::WaitForClientConnection()
{
	int len = sizeof(SOCKADDR);
	clientSocket = accept(server, (SOCKADDR*)&addrClient, &len);
	if (clientSocket == INVALID_SOCKET) {
		return 0;
	}
	return 1;
}

int CServerSocket::Send(const char* pdat, int len)
{
	if (clientSocket == INVALID_SOCKET) {
		std::cout << "no Client socket\n";
		return -1;
	}
	if (send(clientSocket, pdat, len, 0) == SOCKET_ERROR) return 0;
	return 1;
}

int CServerSocket::Receive(char* pdat, int max_len)
{
	//TCP CLIENT�˹رպ󣬷������˵�recv��һֱ����-1����ʱ������˳��������recv��һֱ����
	return recv(clientSocket, pdat, max_len, 0);
}

int CServerSocket::SendStr(const std::string str)
{
	if (clientSocket == 0) {
		std::cout << "no Client socket\n";
		return -1;
	}
	int len = (int)str.size() + 1;
	if (send(clientSocket, str.c_str(), len, 0) == SOCKET_ERROR) return 0;
	return 1;
}

int CServerSocket::RecvStr(std::string& str)
{
	int n;
	char pdat[4096];
	//TCP CLIENT�˹رպ󣬷������˵�recv��һֱ����-1����ʱ������˳��������recv��һֱ����
	n = recv(clientSocket, pdat, 4095, 0);
	if (n <= 0) return n;
	pdat[n] = 0;
	str = pdat;
	return n;
}


int CServerSocket::CloseClientConnection()
{
	int rtn = closesocket(clientSocket);
	clientSocket = INVALID_SOCKET;
	return rtn;
}


int CServerSocket::CloseServer()
{
	if (!closesocket(server))
	{
		WSAGetLastError();
		return 0;
	}
	if (!WSACleanup())
	{
		WSAGetLastError();
		return 0;
	}
	clientSocket = INVALID_SOCKET;
	return 1;
}