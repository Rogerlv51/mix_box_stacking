#include"ShareMemory.h"
// ������ Python һ�µĽṹ��

void sendMyData(const std::wstring& shm_name, MyData& data) {
    // �������ڷ������ݵĹ����ڴ�
    HANDLE hSendMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(MyData), shm_name.c_str());
    if (!hSendMapFile) {
        std::cerr << "Could not create file mapping objects." << std::endl;
        return;
    }
    MyData* sendData = (MyData*)MapViewOfFile(hSendMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(MyData));
    if (!sendData) {
        std::cerr << "Could not map view of file." << std::endl;
        CloseHandle(hSendMapFile);
        return;
    }
    // д������
    sendData = &data;
    std::cout << "�������ݣ�" << sendData->length << " " << sendData->width << " " << sendData->height << std::endl;
    //std::cout << "Data written to shared memory: " << sendData->length << ", " << sendData->width << ", " << sendData->height << ", " << sendData->whereStack << std::endl;

    // ������Դ
    UnmapViewOfFile(sendData);
    CloseHandle(hSendMapFile);
}

MyData readMyData(const std::wstring& shm_name) {
    HANDLE hReceiveMapFile = CreateFileMapping(INVALID_HANDLE_VALUE, nullptr, PAGE_READWRITE, 0, sizeof(MyData), shm_name.c_str());
    if (!hReceiveMapFile) {
        std::cerr << "Could not create file mapping objects." << std::endl;
        return MyData();
    }
    MyData* receiveData = (MyData*)MapViewOfFile(hReceiveMapFile, FILE_MAP_ALL_ACCESS, 0, 0, sizeof(MyData));
    if (!receiveData) {
        std::cerr << "Could not map view of file." << std::endl;
        CloseHandle(hReceiveMapFile);
        return MyData();
    }
    // ��ȡ����
    MyData data = *receiveData;
    // ������Դ
    UnmapViewOfFile(receiveData);
    CloseHandle(hReceiveMapFile);
    return data;
}