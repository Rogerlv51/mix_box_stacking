#define TY_LIB_VERSION_MAJOR       3
#define TY_LIB_VERSION_MINOR       6
#define TY_LIB_VERSION_PATCH       51
