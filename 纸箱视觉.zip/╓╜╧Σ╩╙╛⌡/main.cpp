#include<opencv2/opencv.hpp>
#include<pcl/io/ply_io.h>
#include<pcl/visualization/pcl_visualizer.h>
#include <pcl/point_types.h>
#include <pcl/filters/passthrough.h>
#include <pcl/ModelCoefficients.h>
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/filters/statistical_outlier_removal.h>
#include <pcl/common/common.h>
#include <pcl/filters/radius_outlier_removal.h>
#include <math.h>
#include"ShareMemory.h"
#include"ImageAlgorithmLib.h"
#include"TYCamera.h"
#include <winsock2.h>
#include <MyHVServer.h>
#include "pointVis.h"
#include "thread"
#include "MyHVClient.h"
int boxnum[3] = {0,0,0};
int trailer_state[3] = { 0,0,0 };
vector<vector<vector<cv::Point3f>>> box_size;//box_size[n][m][k] n��������;m��������;k��������������ֵΪ�ߴ�
vector<vector<vector<cv::Point3f>>> saved_points;//saved_points[n][m][k] n��������;m��������;k��������������ֵΪ��λ
imgLib::ImageAlgorithmlib img;
TYCamera tycam;
typedef enum RTN_IMG {
	RTN_OK,
	RTN_ERROR,
	RTN_NULL
}RTN_IMG;

typedef struct BoxInfo {
	Eigen::Vector3f box_size3D;
	Eigen::Vector3f box_center3D;
	Eigen::Vector3f angle3D;
	int wherestack;
}BoxInfo;

typedef pcl::PointXYZRGB PointR;
typedef pcl::PointCloud<PointR> RPointCloud;
typedef pcl::PointCloud<PointR>::Ptr RPointCloudPtr;
typedef pcl::PointXYZ PointT;
typedef pcl::PointCloud<PointT> TPointCloud;

//�����ַ���
void stringSplit(string str, const const char split, vector<string>& res) {
	istringstream iss(str);	// ������
	string token;			// ���ջ�����
	while (getline(iss, token, split))	// ��splitΪ�ָ���
	{
		res.push_back(token);
	}
}

//ģ����ʾ���̺ͺ��ӵ����λ��
void ShowGraspplaneandBox(RPointCloudPtr& ptcloud, RPointCloudPtr& ptcloud2, RPointCloudPtr cloud_Line) {
	pcl::visualization::PCLVisualizer viewer;

	viewer.addLine(cloud_Line->points[0], cloud_Line->points[1], 0, 255, 0, "line1");//��ֱ�߼ӵ����ӻ�������
	viewer.addLine(cloud_Line->points[1], cloud_Line->points[2], 0, 255, 0, "line2");//��ֱ�߼ӵ����ӻ�������
	viewer.addLine(cloud_Line->points[2], cloud_Line->points[3], 0, 255, 0, "line3");//��ֱ�߼ӵ����ӻ�������
	viewer.addLine(cloud_Line->points[3], cloud_Line->points[0], 0, 255, 0, "line4");//��ֱ�߼ӵ����ӻ�������

	viewer.addPointCloud(ptcloud, "cloud_ori");
	viewer.addPointCloud(ptcloud2, "cloud_box");
	viewer.addCoordinateSystem();
	viewer.spin();
}

//ģ����ʾ���̺ͺ��ӵ����λ��
void ShowStackplaneandBox(RPointCloudPtr& ptcloud, RPointCloudPtr& ptcloud2, RPointCloudPtr center, std::vector<RPointCloudPtr>& box_rect_line) {
	pcl::visualization::PCLVisualizer viewer;
	int j = 0;
	for (int i = 0; i < box_rect_line.size(); i++) {
			cout << box_rect_line[i]->points[0].x << " " << box_rect_line[i]->points[0].y << endl;
			viewer.addLine(box_rect_line[i]->points[0], box_rect_line[i]->points[1], 0, 255, 0, "linex" + to_string(i)+ to_string(j+1));//��ֱ�߼ӵ����ӻ�������
			viewer.addLine(box_rect_line[i]->points[1], box_rect_line[i]->points[2], 0, 255, 0, "liney" + to_string(i)+ to_string(j+2));//��ֱ�߼ӵ����ӻ�������
			viewer.addLine(box_rect_line[i]->points[2], box_rect_line[i]->points[3], 0, 255, 0, "linez" + to_string(i)+ to_string(j+3));//��ֱ�߼ӵ����ӻ�������
			viewer.addLine(box_rect_line[i]->points[3], box_rect_line[i]->points[0], 0, 255, 0, "lineb" + to_string(i)+ to_string(j+4));//��ֱ�߼ӵ����ӻ�������
			j++;
	}
	
	viewer.addPointCloud(ptcloud, "cloud_ori");
	viewer.addPointCloud(center, "center");
	viewer.addPointCloud(ptcloud2, "cloud_box");
	viewer.setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 8, "center");
	viewer.addCoordinateSystem();
	viewer.spin();
}


//��ʾֽ��
void eazyShow(RPointCloudPtr& ptcloud) {
	pcl::visualization::PCLVisualizer viewer;
	viewer.addPointCloud(ptcloud);
	viewer.spin();
}

// �뾶�˲�
void pcdROR(RPointCloudPtr& Cloud)
{
	pcl::RadiusOutlierRemoval<PointR> ror;	//����ͳ���˲�������
	ror.setInputCloud(Cloud);		//���ô��˲�����
	ror.setRadiusSearch(0.05);	// ���ò�ѯ��İ뾶��Χ
	ror.setMinNeighborsInRadius(30);// �����ж��Ƿ�Ϊ��Ⱥ�����ֵ�����뾶�����ٰ����ĵ���
	ror.setNegative(false);//Ĭ��false�������ڵ㣻true�������˵�����Ⱥ��
	ror.filter(*Cloud);			//ִ���˲�

}
// ֱͨ�˲�ɸѡ��ʶ������
RTN_IMG passThrough(RPointCloudPtr& cloud, float x_min, float x_max, float y_min, float y_max, float z_min, float z_max) {
	pcl::PassThrough<PointR> pass;
	pass.setInputCloud(cloud);

	// ����X����Ĺ���
	pass.setFilterFieldName("x");
	pass.setFilterLimits(x_min, x_max);
	pass.filter(*cloud);
	//cout << "cloudx== " << cloud->size() << endl;

	// ����Y����Ĺ���
	pass.setInputCloud(cloud);
	pass.setFilterFieldName("y");
	pass.setFilterLimits(y_min, y_max);
	pass.filter(*cloud);
	//cout << "cloudy== " << cloud->size() << endl;
	//eazyShow(cloud);

	// ����Z����Ĺ���
	pass.setInputCloud(cloud);
	pass.setFilterFieldName("z");
	pass.setFilterLimits(z_min, z_max);
	pass.filter(*cloud);

	pcl::VoxelGrid<PointR> vg;
	vg.setInputCloud(cloud);
	vg.setDownsampleAllData(1);
	vg.setLeafSize(0.01f, 0.01f, 0.01f);//���ش�С����z
	vg.filter(*cloud);

	// �˲�
	pcdROR(cloud);
	pcl::StatisticalOutlierRemoval<PointR> sor;//����ͳ���˲�������
	sor.setInputCloud(cloud);
	sor.setMeanK(10);//���ÿ��ǲ�ѯ���ٽ�����
	sor.setStddevMulThresh(0.01);//�����ж��Ƿ�Ϊ��Ⱥ�����ֵ
	sor.filter(*cloud);

	//cout << "cloud1== " << cloud->size() << endl;

}

RTN_IMG passThrough_stackTake(RPointCloudPtr& cloud, float x_min, float x_max, float y_min, float y_max, float z_min, float z_max) {
	pcl::PassThrough<PointR> pass;
	pass.setInputCloud(cloud);

	// ����X����Ĺ���
	pass.setFilterFieldName("x");
	pass.setFilterLimits(x_min, x_max);
	pass.filter(*cloud);
	//cout << "cloudx== " << cloud->size() << endl;

	// ����Y����Ĺ���
	pass.setInputCloud(cloud);
	pass.setFilterFieldName("y");
	pass.setFilterLimits(y_min, y_max);
	pass.filter(*cloud);
	//cout << "cloudy== " << cloud->size() << endl;
	//eazyShow(cloud);

	// ����Z����Ĺ���
	pass.setInputCloud(cloud);
	pass.setFilterFieldName("z");
	pass.setFilterLimits(z_min, z_max);
	pass.filter(*cloud);

	pcl::VoxelGrid<PointR> vg;
	vg.setInputCloud(cloud);
	vg.setDownsampleAllData(1);
	vg.setLeafSize(0.01f, 0.01f, 0.01f);//���ش�С����z
	vg.filter(*cloud);

	// �˲�
	//pcdROR(cloud);
	//pcl::StatisticalOutlierRemoval<PointR> sor;//����ͳ���˲�������
	//sor.setInputCloud(cloud);
	//sor.setMeanK(10);//���ÿ��ǲ�ѯ���ٽ�����
	//sor.setStddevMulThresh(0.01);//�����ж��Ƿ�Ϊ��Ⱥ�����ֵ
	//sor.filter(*cloud);

	//cout << "cloud1== " << cloud->size() << endl;

}

RTN_IMG passThrough_pure(RPointCloudPtr& cloud, float x_min, float x_max, float y_min, float y_max, float z_min, float z_max) {
	pcl::PassThrough<PointR> pass;
	pass.setInputCloud(cloud);

	// ����X����Ĺ���
	pass.setFilterFieldName("x");
	pass.setFilterLimits(x_min, x_max);
	pass.filter(*cloud);
	//cout << "cloudx== " << cloud->size() << endl;

	// ����Y����Ĺ���
	pass.setInputCloud(cloud);
	pass.setFilterFieldName("y");
	pass.setFilterLimits(y_min, y_max);
	pass.filter(*cloud);
	//cout << "cloudy== " << cloud->size() << endl;
	//eazyShow(cloud);

	// ����Z����Ĺ���
	pass.setInputCloud(cloud);
	pass.setFilterFieldName("z");
	pass.setFilterLimits(z_min, z_max);
	pass.filter(*cloud);

	pcl::VoxelGrid<PointR> vg;
	vg.setInputCloud(cloud);
	vg.setDownsampleAllData(1);
	vg.setLeafSize(0.01f, 0.01f, 0.01f);//���ش�С����z
	vg.filter(*cloud);

}

// ���ƽ�棬�ҷ����ӵ�ƽ��
float projectPointCloudToPlane(float distanceThreshold, RPointCloudPtr& inputCloud, RPointCloudPtr& boxCloud, RPointCloudPtr& planeCloud)
{
	// ƽ�����
	pcl::SACSegmentation<PointR> seg;
	seg.setOptimizeCoefficients(true);
	seg.setModelType(pcl::SACMODEL_PLANE);
	seg.setMethodType(pcl::SAC_RANSAC);
	seg.setDistanceThreshold(distanceThreshold);

	pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
	pcl::PointIndices::Ptr inliers(new pcl::PointIndices);

	seg.setInputCloud(inputCloud);
	seg.segment(*inliers, *coefficients);
	pcl::PointXYZRGB projectedPoint;
	// ͶӰ��ƽ��
	for (const auto& index : inliers->indices) {
		const auto& point = inputCloud->points[index];
		// ����㵽ƽ��ľ���
		float distance = coefficients->values[0] * point.x +
			coefficients->values[1] * point.y +
			coefficients->values[2] * point.z +
			coefficients->values[3];

		// ͶӰ��ƽ��

		projectedPoint.x = point.x - distance * coefficients->values[0];
		projectedPoint.y = point.y - distance * coefficients->values[1];
		projectedPoint.z = point.z - distance * coefficients->values[2];
		projectedPoint.r = 255;
		projectedPoint.g = 0;
		projectedPoint.b = 0;
		boxCloud->points.push_back(projectedPoint);
	}

	boxCloud->width = boxCloud->points.size();
	boxCloud->height = 1;
	boxCloud->is_dense = true;

	PointR minP, maxP;
	pcl::getMinMax3D(*boxCloud, minP, maxP);
	float temp_depth1;
	temp_depth1 = (minP.z + maxP.z) / 2;

	// ��ȡ�ڶ���ƽ�����
	pcl::ExtractIndices<PointR> extract;
	extract.setInputCloud(inputCloud);
	extract.setIndices(inliers);
	extract.setNegative(true);
	extract.filter(*inputCloud);
	seg.setInputCloud(inputCloud);
	seg.segment(*inliers, *coefficients);
	for (const auto& index : inliers->indices) {
		const auto& point = inputCloud->points[index];
		// ����㵽ƽ��ľ���
		float distance = coefficients->values[0] * point.x +
			coefficients->values[1] * point.y +
			coefficients->values[2] * point.z +
			coefficients->values[3];

		// ͶӰ��ƽ��

		projectedPoint.x = point.x - distance * coefficients->values[0];
		projectedPoint.y = point.y - distance * coefficients->values[1];
		projectedPoint.z = point.z - distance * coefficients->values[2];
		projectedPoint.r = 255;
		projectedPoint.g = 0;
		projectedPoint.b = 0;
		planeCloud->points.push_back(projectedPoint);
	}

	planeCloud->width = planeCloud->points.size();
	planeCloud->height = 1;
	planeCloud->is_dense = true;

	pcl::getMinMax3D(*planeCloud, minP, maxP);
	float temp_depth2;
	temp_depth2 = (minP.z + maxP.z) / 2;
	float plane_depth = 0.0;
	if (temp_depth1 < temp_depth2) {
		plane_depth = temp_depth2;
	}
	else
	{
		planeCloud->swap(*boxCloud);
		plane_depth = temp_depth1;
	}
	return plane_depth;
}

// ʶ�����̶���������Ƕȣ�������Ҫֱͨ��������
// ����λ�á�����ʶ��
RTN_IMG getBoxVertex(const RPointCloudPtr& cloud, Eigen::Vector3f& box_size3D, Eigen::Vector3f& box_center3D, Eigen::Vector3f& angle3D, std::vector<cv::Point3f>& box_vertex) {
	RPointCloudPtr cloud_pass(new RPointCloud);
	*cloud_pass = *cloud;
	passThrough(cloud_pass, -0.57, 0.63, -0.59, 0.62, 3.12, 3.21);
	RPointCloudPtr cloud_projected(new RPointCloud);
	if (cloud->points.size() <= 0) {
		cout << "cloud num error!!!" << endl;
		return RTN_ERROR;
	}
	// �������ƽ�棬���Ӻ�ֽ��
	pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
	RPointCloudPtr getstack_cloud(new RPointCloud);
	RPointCloudPtr plane_cloud(new RPointCloud);

	if (cloud->points.size() == 0) {
		cout << "cloud num error!!!" << endl;
		return RTN_ERROR;
	}
	/*float plane_depth = projectPointCloudToPlane(thresh, cloud_getstack, getstack_cloud, plane_cloud);
	eazyShow(cloud_getstack);*/
	//std::cout << "������ȣ�" << plane_depth << std::endl;
	pcl::copyPointCloud(*cloud_pass, *cloud_projected);
	std::vector<cv::Point2f> pts{ cloud_projected->size() };
	float min_z = std::numeric_limits<float>::max();
	float max_z = -std::numeric_limits<float>::max();
	for (int i = 0; i < cloud_projected->size(); i++) {
		pts[i] = cv::Point2f(cloud_projected->points[i].x, cloud_projected->points[i].y);
		min_z = std::min(min_z, cloud_projected->points[i].z);
		max_z = std::max(max_z, cloud_projected->points[i].z);
	}
	cv::Point2f points[4];
	cv::RotatedRect rect = cv::minAreaRect(pts);
	rect.points(points);//����ζ���
	cv::Point2f box_vertex_2d[4];
	//Ѱ��������С��׼��
	double min_x = points[0].x;
	double min_y = points[0].y;
	for (int i = 0; i < 4; i++) {
		if (min_x > points[i].x) {
			min_x = points[i].x;
		}
		if (min_y > points[i].y) {
			min_y = points[i].y;
		}
	}
	//Ѱ�����ϽǶ���
	float min_distance = sqrt(pow(points[0].x - min_x, 2) + pow(points[0].y - min_y, 2));
	for (int i = 0; i < 4; i++) {
		float distance = sqrt(pow(points[i].x - min_x, 2) + pow(points[i].y - min_y, 2));
		if (min_distance >= distance) {
			min_distance = distance;
			box_vertex_2d[0] = points[i];
		}
	}
	//Ѱ�����½Ƕ���
	float max_distance = sqrt(pow(points[0].x - box_vertex_2d[0].x, 2) + pow(points[0].y - box_vertex_2d[0].y, 2));
	for (int i = 0; i < 4; i++) {
		float distance = sqrt(pow(points[i].x - box_vertex_2d[0].x, 2) + pow(points[i].y - box_vertex_2d[0].y, 2));
		if (max_distance < distance) {
			max_distance = distance;
			box_vertex_2d[2] = points[i];
		}
	}
	//Ѱ��ʣ��������
	for (int i = 0; i < 4; i++) {
		if ((abs(points[i].x - box_vertex_2d[0].x) < 0.01 && abs(points[i].y - box_vertex_2d[0].y) < 0.01) || (abs(points[i].x - box_vertex_2d[2].x) < 0.01 && abs(points[i].y - box_vertex_2d[2].y) < 0.01)) { continue; }
		else {
			if (points[i].x > box_vertex_2d[0].x && points[i].y < box_vertex_2d[2].y) {
				box_vertex_2d[1] = points[i];
			}
			else if (points[i].x < box_vertex_2d[2].x && points[i].y > box_vertex_2d[0].y) {
				box_vertex_2d[3] = points[i];
			}
		}
	}
	double box_length = sqrt(pow(box_vertex_2d[1].x - box_vertex_2d[0].x, 2) + pow(box_vertex_2d[1].y - box_vertex_2d[0].y, 2));
	double box_width = sqrt(pow(box_vertex_2d[1].x - box_vertex_2d[2].x, 2) + pow(box_vertex_2d[1].y - box_vertex_2d[2].y, 2));
	double box_angle = atan((box_vertex_2d[1].y - box_vertex_2d[0].y) / (box_vertex_2d[1].x - box_vertex_2d[0].x)) * 180 / M_PI;
	if (box_length < box_width) {
		box_angle += 90;
		std::swap(box_length, box_width);
	}
	box_size3D[0] = box_length;
	box_size3D[1] = box_width;
	box_size3D[2] = max_z - min_z;
	box_center3D[0] = rect.center.x;
	box_center3D[1] = rect.center.y;
	box_center3D[2] = (max_z + min_z) / 2.0;
	angle3D[0] = box_angle;
	angle3D[1] = 0;
	angle3D[2] = 0;

	cv::Point3f tmp;
	for (int i = 0; i < 4; i++) {
		tmp.x = box_vertex_2d[i].x;
		tmp.y = box_vertex_2d[i].y;
		tmp.z = box_center3D[2];
		box_vertex.push_back(tmp);
	}
	return RTN_OK;
}

float fitPlane(float threshold, const RPointCloudPtr& cloud, pcl::ModelCoefficients::Ptr& coefficients, RPointCloudPtr& box_cloud, RPointCloudPtr& plane_cloud) {
	// �����ָ����
	pcl::SACSegmentation<PointR> seg;
	seg.setOptimizeCoefficients(true);
	seg.setModelType(pcl::SACMODEL_PLANE);
	seg.setMethodType(pcl::SAC_RANSAC);
	seg.setDistanceThreshold(threshold); // ����ʵ��������þ�����ֵ

	// ִ�зָ��ȡƽ��
	pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
	seg.setInputCloud(cloud);
	seg.segment(*inliers, *coefficients);

	if (inliers->indices.empty()) {
		std::cerr << "�޷��ҵ�ƽ��" << std::endl;
		return -1;
	}

	PointR minP, maxP;
	// ��ȡƽ���ڵ���
	pcl::ExtractIndices<PointR> extract;
	extract.setInputCloud(cloud);
	extract.setIndices(inliers);
	extract.setNegative(false); // ��ȡƽ���ϵĵ�
	extract.filter(*plane_cloud);
	pcl::getMinMax3D(*plane_cloud, minP, maxP);
	float temp_depth1;
	temp_depth1 = (minP.z + maxP.z) / 2;

	pcl::ExtractIndices<PointR> extract2;
	extract2.setInputCloud(cloud);
	extract2.setIndices(inliers);
	extract2.setNegative(true); // ȥ����һ��ƽ��ĵ�
	extract2.filter(*box_cloud);
	pcl::getMinMax3D(*box_cloud, minP, maxP);
	float temp_depth2;
	temp_depth2 = (minP.z + maxP.z) / 2;
	float plane_depth = 0.0;
	if (temp_depth1 < temp_depth2) {
		plane_cloud->swap(*box_cloud);
		plane_depth = temp_depth2;
	}
	else
	{
		plane_depth = temp_depth1;
	}
	return plane_depth;
}

// ֽ��ߴ�ʶ�� 0ʶ��ɹ��� 1û�����ϣ�2ʶ��ʧ��
int getBoxSize(RPointCloudPtr& cloud, Eigen::Vector3i& box_size3D, Eigen::Vector3f& box_center3D, Eigen::Vector3f& angle3D) {
	
	clock_t start1, start2, start3, end1, end2, end3, end4, end5;
	//ֱͨ�˲�
	RPointCloudPtr temp_cloud(new RPointCloud);
	RPointCloudPtr ogi_cloud(new RPointCloud);
	*ogi_cloud = *cloud;
	*temp_cloud = *cloud;

	start2= clock();
	passThrough(temp_cloud, -0.43, 0.56, -0.50, 0.37, 1.4, 2.20);  // ����������ƽ������Զ��������
	start3 = clock();
	cout << "ֱͨ�˲�ʱ�� " << (double)(start3 - start2) / CLOCKS_PER_SEC << endl;
	
	// �������ƽ�棬���Ӻ�ֽ��
	pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
	RPointCloudPtr box_cloud(new RPointCloud);
	RPointCloudPtr plane_cloud(new RPointCloud);
	RPointCloudPtr cloud_vg(new RPointCloud);


	float thresh = 0.05;
	if (temp_cloud->points.size()== 0) {
		cout << "cloud num error!!!" << endl;
		return 2;
	}
	
	start1 = clock();
	
	end1 = clock();
	cout << "����ʱ�䣺"<<(double)(end1- start1)/CLOCKS_PER_SEC << endl;
	float plane_depth = projectPointCloudToPlane(thresh, temp_cloud, box_cloud, plane_cloud);
	end2 = clock();
	cout << "Ѱ��ƽ��ʱ�䣺" << (double)(end2 - end1) / CLOCKS_PER_SEC << endl;
	std::cout << "������ȣ�" << plane_depth << std::endl;

	//�������
	//std::vector<pcl::PointIndices> cluster_indices;
	//int result=img.getBoxEuclideanClusterExtraction(box_cloud, 100, 1000000, 0.02, cluster_indices);
	//if (result == 0) {
	//	cout << "����Ϊ��" << endl;
	//	return 2;
	//}
	//else {
	//	cout <<"�������Ϊ��" << cluster_indices.size() << endl;
	//}

	//if (box_cloud->points.size() <= 0) {
	//	cout << "cloud num error!!!" << endl;
	//	return 2;
	//}

	//std::vector<cv::Point3f> box_cluster_size;
	//std::vector<cv::Point3f> box_cluster_center;
	//cout << "���Ӿ������� "<<box_cluster_center.size()<< endl;
	//RPointCloudPtr box_cluster(new RPointCloud);
	//for (std::vector<pcl::PointIndices>::const_iterator it=cluster_indices.begin(); it!=cluster_indices.end(); ++it) {
	//	
	//	for (const auto& idx : it->indices) {
	//		box_cluster->push_back((*box_cloud)[idx]);
	//	}
	//	cout <<"�������������" << box_cluster->size() << endl;

	//	float depth_cluster;
	//	float min_z = std::numeric_limits<float>::max();
	//	float max_z = -std::numeric_limits<float>::max();
	//	std::vector<cv::Point2f> points_2d_cluster;

	//	for (const auto& point : box_cluster->points) {
	//		points_2d_cluster.emplace_back(point.x, point.y);  // ת��Ϊ��ά��
	//		min_z = std::min(min_z, point.z);
	//		max_z = std::max(max_z, point.z);
	//	}

	//	// ��С��Ӿ���
	//	cv::RotatedRect box_clu = cv::minAreaRect(points_2d_cluster);
	//	if (box_clu.size.width < box_clu.size.height) {
	//		box_clu.angle -= 90;
	//		std::swap(box_clu.size.height, box_clu.size.width);
	//	}
	//	float clu_length = box_clu.size.width;
	//	float  clu_width = box_clu.size.height;
	//	cout <<" clu_length:" << clu_length << endl;
	//	// ץȡ���ĵ�
	//	cv::Point2f box_center = box_clu.center;
	//	float box_height = abs(plane_depth - depth_cluster - 0.005);  // ����һ��

	//	box_cluster_center.push_back(cv::Point3f(box_center.x, box_center.y, box_height));
	//	box_cluster_size.push_back(cv::Point3f(clu_length, clu_width, box_height));
	//	box_cluster->clear();
	//}


	//double handgrasp_length = 0.650;
	//double handgrasp_width = 0.850;
	//Eigen::Vector3d rot_grab, pos_grab;
	//rot_grab << 180, 0, 90.5;//0.9128215
	//pos_grab << -0.954388, -1.68656, 2.282;
	//for (int iter = 0; iter < box_cluster_center.size(); iter++) {
	//	cout<<"�������ģ�" << box_cluster_center[iter].x << " " << box_cluster_center[iter].y << " " << box_cluster_center[iter].z << endl;
	//	Eigen::Vector3d camPos;
	//	camPos[0] = box_cluster_center[iter].x;
	//	//double box_centery = box_cluster_center[iter].y - (handgrasp_width * 0.5 - box_cluster_size[iter].x);
	//	camPos[1] = box_cluster_center[iter].y;
	//	camPos[2] = box_cluster_center[iter].z;
	//	//cout << "ֽ��ԭʼ������������" << box_center.x << " " << box_center.y << " " << endl;
	//	//box_center.x =box_center.x - (handgrasp_width * 0.5 - width);
	//	Eigen::Vector3d grasp = img.cam2BasePos(camPos, pos_grab, rot_grab);
	//	grasp[1] = grasp[1] - (handgrasp_width * 0.5 - box_cluster_size[iter].x);
	//	cout << "ץȡ���ģ�" << grasp[0]*1000 << " " << grasp[1]*1000 << " " << grasp[2]*1000 << endl;
	//}


	//��������
	std::vector<cv::Point2f> points_2d;
	float depth;
	float min_z = std::numeric_limits<float>::max();
	float max_z = -std::numeric_limits<float>::max();

	for (const auto& point : box_cloud->points) {
		points_2d.emplace_back(point.x, point.y);  // ת��Ϊ��ά��
		min_z = std::min(min_z, point.z);
		max_z = std::max(max_z, point.z);
	}
	end4 = clock();
	cout << "ת����ά��ʱ�䣺" << (double)(end4 - end2) / CLOCKS_PER_SEC << endl;
	// ����ƽ��߶ȣ������ж����������ϰ�
	depth = (min_z + max_z) / 2;
	if (depth > 2&& points_2d.size()==0) {    // ����ʵ���������
		cout << "û�����ϣ������" << endl;
		return 1;
	}

	// ��С��Ӿ���
	cv::RotatedRect box = cv::minAreaRect(points_2d);
	if (box.size.width < box.size.height) {
		box.angle -= 90;
		std::swap(box.size.height, box.size.width);
	}
	cv::Point2f rect_points[4];

	// ���� points ��Ա���������������õ�����
	box.points(rect_points);

	
	cout << "������С��Ӿ���ʱ�䣺" << (double)(end5 - end4) / CLOCKS_PER_SEC << endl;
	float length = box.size.width;
	float width = box.size.height;
	// ץȡ���ĵ�
	cv::Point2f box_center = box.center;
	float box_height = abs(plane_depth - depth - 0.005);  // ����һ��
	//ץȡ���ĸ߶�
	float graspheight = (plane_depth - box_height);

	

	cout <<"ֽ����������" << box_center.x << " " << box_center.y << " ץȡ���ĸ߶� " << (plane_depth - box_height) << endl << endl;
	std::cout << "ԭʼ����" << length << "ԭʼ����" << width << "ԭʼ�ߣ�" << box_height << std::endl;

	length *= 1000;
	width *= 1000;
	box_height *= 1000;

	if (length < 250) {
		length = 200;
	}
	else if (length < 350)
	{
		length = 300;
	}
	else if (length < 450) {
		length = 400;
	}
	else {
		length = 700;
	}

	if (width < 190) {
		width = 150;
	}
	else if (width < 240)
	{
		width = 200;
	}
	else if (width < 270) {
		width = 250;
	}
	else if (width < 350) {
		width = 300;
	}
	else {
		width = 400;
	}

	if (box_height < 140) {
		box_height = 100;
	}
	else if (box_height < 190)
	{
		box_height = 150;
	}
	else if (box_height < 250) {
		box_height = 200;
	}
	else if (box_height < 320) {
		box_height = 300;
	}
	else {
		box_height = 320;
	}

	//ת��������
	//Eigen::Vector3d rot_grab, pos_grab;
	//rot_grab << 180, 0, 90.5;//0.9128215
	//pos_grab << -0.954388, -1.68656, 2.282;
	//RPointCloudPtr cloud_trans(new RPointCloud);
	//pcl::transformPointCloud(*box_cloud, *cloud_trans, rt_mat_above);


	Eigen::Vector3d rot_grab, pos_grab;
	rot_grab << 180, 0, 90.5;//0.9128215
	pos_grab << -0.954388, -1.68656, (2.282);
	Eigen::Vector3d camPos;
	camPos[0] = box_center.x;
	camPos[1] = box_center.y;
	camPos[2] = graspheight;
	Eigen::Vector3d grasp = img.cam2BasePos(camPos, pos_grab, rot_grab);
	angle3D[0] = box.angle;
	std::cout << "ԭʼangle3D: " << box.angle << std::endl;
	float graspAngle = 0.0;
	if (angle3D[0] > 0) {
		graspAngle = 94.05 - angle3D[0] + 91.7;
	}
	if (angle3D[0] < 0) {
		graspAngle = abs(angle3D[0]) + 5.2;
	}

	//ƫ�����ĵ�צ�����ĵ�
	double handgrasp_length = 0.650;
	double handgrasp_width = 0.280;

	if (graspAngle <= 90) {
		double radians = graspAngle * M_PI / 180.0;
		grasp[0] = grasp[0] - (handgrasp_length - length * 0.001) * 0.5 * sin(radians) - (handgrasp_width - width * 0.001) * 0.5 * cos(radians) + 0.01;
		grasp[1] = grasp[1] + (handgrasp_length - length * 0.001) * 0.5 * cos(radians) - (handgrasp_width - width * 0.001) * 0.5 * sin(radians) + 0.01;
	}
	if (graspAngle > 90) {
		double radians2 = (180.0-graspAngle) * M_PI / 180.0;
		grasp[0] = grasp[0] - (handgrasp_length - length * 0.001) * 0.5 * sin(radians2) + (handgrasp_width - width * 0.001) * 0.5 * cos(radians2) - 0.01;
		grasp[1] = grasp[1] - (handgrasp_length - length * 0.001) * 0.5 * cos(radians2) - (handgrasp_width - width * 0.001) * 0.5 * sin(radians2) + 0.01;
	}

	/*double baisY = (handgrasp_width * 0.5 - width * 0.001 * 0.5);
	double baisX = (handgrasp_length * 0.5 - length * 0.001 * 0.5);
	grasp[0] = grasp[0] - baisX;
	grasp[1] = grasp[1] - baisY;
	grasp[2] =0.6182 +(box_height*0.001-0.200);*/
	grasp[2] = 0.6182 + (box_height * 0.001 - 0.200);
	cout << "ץȡ���ģ�" << grasp[0]<< " " << grasp[1]<< " " << grasp[2]<< endl;


	/*RPointCloudPtr cloud_Box_line(new RPointCloud);
	cloud_Box_line->push_back(pcl::PointXYZRGB(rect_points[0].x, rect_points[0].y, graspheight));
	cloud_Box_line->push_back(pcl::PointXYZRGB(rect_points[1].x, rect_points[1].y, graspheight));
	cloud_Box_line->push_back(pcl::PointXYZRGB(rect_points[2].x, rect_points[2].y, graspheight));
	cloud_Box_line->push_back(pcl::PointXYZRGB(rect_points[3].x, rect_points[3].y, graspheight));

	Eigen::Matrix4d rt_mat_above = TransForms::ComposeEuler(pos_grab[0], pos_grab[1], pos_grab[2], rot_grab[0], rot_grab[1], rot_grab[2]);
	Eigen::Matrix3d r_mat_above = rt_mat_above.block<3, 3>(0, 0);
	RPointCloudPtr cloud_trans(new RPointCloud);
	RPointCloudPtr box_cloud_trans(new RPointCloud);
	pcl::transformPointCloud(*ogi_cloud, *cloud_trans, rt_mat_above);
	pcl::transformPointCloud(*box_cloud, *box_cloud_trans, rt_mat_above);
	pcl::transformPointCloud(*cloud_Box_line, *cloud_Box_line, rt_mat_above);*/

	//ShowGraspplaneandBox(cloud_trans, box_cloud_trans, cloud_Box_line);

	box_size3D[0] = length;
	box_size3D[1] = width;
	box_size3D[2] = box_height;
	box_center3D[0] = grasp[0];
	box_center3D[1] = grasp[1];
	box_center3D[2] = grasp[2];
	angle3D[0] = graspAngle;
	angle3D[1] = 0;
	angle3D[2] = 0;
	return 0;
}


// TODO: ���������궨
void calibMaduo(){
	Eigen::Vector3d rot_stack, pos_stack;
	rot_stack << 180, 0, 1;
	pos_stack << (0.33), (-1.68), (3.2);
}

//��ʼ������Լ���ȡ����λ�óߴ���Ϣ�Լ������������̵Ľǵ���Ϣ
int getBoxPos(std::vector<camsInfo> m_Cams,BoxInfo& boxinfo,int& floor,int& row,int& col,int& wherestack) {
	// ��ʼ����� grab=0 stack=1
	string id_grab, id_stack,id_buffer;
	cv::Mat depth_grab, color_grab, depth_stack, color_stack;
	float* intr_grab = m_Cams[2].intri_color.data;

	//����������
	RPointCloudPtr cloud_trans(new RPointCloud);
	clock_t start, end;
	start = clock();
	tycam.getSpecifiedCameraData(m_Cams[2], depth_grab, color_grab);
	end = clock();
	cout << "ͼ���ɼ�ʱ��"<<(double)(end- start)/CLOCKS_PER_SEC<<"s" << endl;
	img.depth2PointCloud(intr_grab, depth_grab, color_grab, cloud_trans);
	cout << "cloud_trans== "<< cloud_trans->size() << endl;

	Eigen::Vector3i box_size3D;
	Eigen::Vector3f box_center3D;
	Eigen::Vector3f angle3D;


	// �������ƽ�棬���Ӻ�ֽ��
	pcl::ModelCoefficients::Ptr coefficients(new pcl::ModelCoefficients);
	RPointCloudPtr box_cloud(new RPointCloud);
	box_cloud = cloud_trans;

	if (getBoxSize(box_cloud, box_size3D, box_center3D, angle3D) == RTN_OK) {
		std::cout << "�ߴ�ʶ��ɹ���" << std::endl;
		std::cout << "����" << box_size3D[0] << "," << "����" << box_size3D[1] << "," << "�ߣ�" << box_size3D[2] << std::endl;
		
		std::cout << "ץȡ���ĵ����꣺" << box_center3D[0] << "," << box_center3D[1] << "," << box_center3D[2] << std::endl;
	}
	else
	{
		std::cout << "�ߴ�ʶ��ʧ�ܣ�����" << std::endl;
		return 2;
	}

	//boxinfo.box_center3D[0] = box_center3D[0] * 1000;
	boxinfo.box_center3D[0] = (box_center3D[0]-0.01)*1000;  // ץ���ĵ����
	boxinfo.box_center3D[1] = box_center3D[1]*1000;
	boxinfo.box_center3D[2] = box_center3D[2]*1000;
	boxinfo.box_size3D[0] = box_size3D[0];
	boxinfo.box_size3D[1] = box_size3D[1];
	boxinfo.box_size3D[2] = box_size3D[2];
	//boxinfo.angle3D[2] = 95.59; // �̶���
	boxinfo.angle3D[2] = angle3D[0]; // �Ӿ�����
	

	//������
	double stack_length = 1.30;
	double stack_width = 1.30;
	double stack_height = 1.00;


	cout << "boxinfo.box_size3D[2]" << boxinfo.box_size3D[2] << " " << boxinfo.box_size3D[1] << " " << boxinfo.box_size3D[0] << endl;
	//����������������óߴ�ֽ��������
	//boxinfo.box_size3D[0] = 400;
	//boxinfo.box_size3D[1] = 300;
	//boxinfo.box_size3D[2] = 300;

	double nx = (stack_height / (boxinfo.box_size3D[2]* 0.001));//��
	double mx = (stack_length / (boxinfo.box_size3D[0]* 0.001));//��
	double kx = (stack_width / (boxinfo.box_size3D[1]*0.001));//��

	cout << "double ����ֵ��" << nx << " " << mx << " " << kx << endl;
	int n = 0;//��
	int m = 0;//��
	int k = 0;//��

	if (abs(nx - int(nx)) < 0.8) {
		n = int(nx);
	}
	else {
		n = int(nx) + 1;
	}
	if (abs(mx - int(mx)) < 0.8) {
		m = int(mx);
	}
	else {
		m = int(mx) + 1;
	}
	if (abs(kx - int(kx)) < 0.8) {
		k = int(kx);
	}
	else {
		k = int(kx) + 1;
	}

	floor = n;
	row = m;
	col = k;

	if (saved_points.size() == 0) {
		cout << "��ʼ������" << endl;
		saved_points.resize(n+1);
		box_size.resize(n+1);
		for (int i = 0; i < saved_points.size(); ++i) {
			saved_points[i].resize(m+1);
			box_size[i].resize(m+1);
			for (int j = 0; j < saved_points[i].size(); ++j) {
				box_size[i][j].resize(k+1);
				saved_points[i][j].resize(k+1);
				for (int k2 = 0; k2 < k+1; ++k2) {
					box_size[i][j][k2] = { 0,0,0 };
					saved_points[i][j][k2] = { 0,0,0 };
				}
			}
		}
	}


	wherestack = 0;
	return 0;

}

// TODO: ���������
double getBoxPos2(std::vector<camsInfo> m_Cams, BoxInfo& boxinfo, std::vector<cv::Point3f> bufferplane_vertex) {
	cv::Mat depth_grab, color_grab, depth_stack, color_stack;
	float* intr_grab = m_Cams[0].intri_color.data;
	//����������
	RPointCloudPtr cloud_trans(new RPointCloud);
	tycam.getSpecifiedCameraData(m_Cams[0], depth_grab, color_grab);
	img.depth2PointCloud(intr_grab, depth_grab, color_grab, cloud_trans);
	pcl::VoxelGrid<PointR> vg;
	vg.setInputCloud(cloud_trans);
	vg.setDownsampleAllData(1);
	vg.setLeafSize(0.01f, 0.01f, 0.01f);
	vg.filter(*cloud_trans);

	// ��������
	const float margin = 0.05f; // ��ȫ����
	const float delta = 0.05f;  // ǰ������Ŀ���

	// ���λ�ú�ֽ��ߴ�
	float length = static_cast<float>(boxinfo.box_size3D[0] / 1000);
	float width = static_cast<float>(boxinfo.box_size3D[1] / 1000);
	float centerX = static_cast<float>(bufferplane_vertex[2].x - boxinfo.box_center3D[1]/1000 - width/2-0.01);
	float centerY = static_cast<float>(bufferplane_vertex[2].y - boxinfo.box_center3D[0]/1000 - length/2);
	float centerZ = static_cast<float>(bufferplane_vertex[2].z - boxinfo.box_center3D[2]/1000); 
	

	// ����ǰ������ͺ������������λ��
	float frontCenterY = centerY;
	//float frontCenterY = centerY + length / 2 + 0.05 / 2;
	float backCenterY = centerY - length / 2 - margin - 0.3 / 2;
	double theta = 90.3;
	// ����ǰ����������߶�
	float frontMaxHeight = 10000.0f;
	for (const auto& point : *cloud_trans) {
		// ����ת����ǰ�����������ϵ
		float dx = point.x - centerX;
		float dy = point.y - frontCenterY;
		float cosTheta = std::cos(-theta);
		float sinTheta = std::sin(-theta);
		float rotatedX = dx * cosTheta - dy * sinTheta;
		float rotatedY = dx * sinTheta + dy * cosTheta;

		// �����Ƿ���ǰ��������
		if (std::abs(rotatedX) <= (width - 0.14) / 2 && std::abs(rotatedY) <= (delta / 2+0.05)) {
			if (point.z < frontMaxHeight) {
				frontMaxHeight = point.z;
			}
		}
	}

	// ���������������߶�
	float backMaxHeight = 10000.0f;
	for (const auto& point : *cloud_trans) {
		// ����ת�����������������ϵ
		float dx = point.x - centerX;
		float dy = point.y - backCenterY;
		float cosTheta = std::cos(-theta);
		float sinTheta = std::sin(-theta);
		float rotatedX = dx * cosTheta - dy * sinTheta;
		float rotatedY = dx * sinTheta + dy * cosTheta;

		// �����Ƿ��ں���������
		if (std::abs(rotatedX) <= (width-0.15) / 2 && std::abs(rotatedY) <= delta / 2) {
			if (point.z < backMaxHeight) {
				backMaxHeight = point.z;
			}
		}
	}
	//pcl::visualization::PCLVisualizer viewer;
	//viewer.addPointCloud<pcl::PointXYZRGB>(cloud_trans, "colored_cloud");
	// //���ӻ�ǰ�����򣨺�ɫ��������������ɫ��
	//pcl::PointCloud<pcl::PointXYZ>::Ptr frontCorners(new pcl::PointCloud<pcl::PointXYZ>);
	//frontCorners->points.push_back(pcl::PointXYZ(centerX - (width - 0.14) / 2, frontCenterY - (delta / 2 + 0.05), centerZ)); // ʹ�� centerZ
	//frontCorners->points.push_back(pcl::PointXYZ(centerX + (width - 0.14) / 2, frontCenterY - (delta / 2 + 0.05), centerZ));
	//frontCorners->points.push_back(pcl::PointXYZ(centerX + (width - 0.14) / 2, frontCenterY + (delta / 2 + 0.05), centerZ));
	//frontCorners->points.push_back(pcl::PointXYZ(centerX - (width - 0.14) / 2, frontCenterY + (delta / 2 + 0.05), centerZ));
	//viewer.addPolygon<pcl::PointXYZ>(frontCorners, 1.0, 0.0, 0.0, "front_region"); // ��ɫ

	//pcl::PointCloud<pcl::PointXYZ>::Ptr backCorners(new pcl::PointCloud<pcl::PointXYZ>);
	//backCorners->points.push_back(pcl::PointXYZ(centerX - (width - 0.15) / 2, backCenterY - delta / 2, centerZ)); // ʹ�� centerZ
	//backCorners->points.push_back(pcl::PointXYZ(centerX + (width - 0.15) / 2, backCenterY - delta / 2, centerZ));
	//backCorners->points.push_back(pcl::PointXYZ(centerX + (width - 0.15) / 2, backCenterY + delta / 2, centerZ));
	//backCorners->points.push_back(pcl::PointXYZ(centerX - (width - 0.15) / 2, backCenterY + delta / 2, centerZ));
	//viewer.addPolygon<pcl::PointXYZ>(backCorners, 0.0, 1.0, 0.0, "back_region"); // ��ɫ

	//while (!viewer.wasStopped()) {
	//	viewer.spinOnce();
	//}


	// ���ǰ����������߶ȴ��ں�����������߶ȣ�����Ҫ�����������������������ϵ
	if (frontMaxHeight > backMaxHeight) {
		double tmp_z = boxinfo.box_size3D[2] / 1000 + 0.02;
		double high_abstract = frontMaxHeight - backMaxHeight;
		if (high_abstract > tmp_z) {
			return bufferplane_vertex[2].z - backMaxHeight;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		return 0;
	}
}

//������
int getMixStackPos(std::string filename,int mixstacknum, BoxInfo& boxinfo) {
	ifstream infile(filename.c_str()); // ���ļ�
	if (!infile.is_open()) { // ����ļ��Ƿ�ɹ���
		cout << "��ȡ�ļ�ʧ��" << endl;
		return 1;
	}
	string line;
	vector<string> lines;
	vector<vector<double>> strArray;

	while (getline(infile, line)) { // ���ж�ȡ�ļ�����
		// ��ɶ�ά���ṹ  
		stringstream ss(line);
		string str;
		vector<double> lineArray;
		// ���ն��ŷָ�  
		while (getline(ss, str, ',')) {
			lineArray.push_back(stod(str));
		}
		strArray.push_back(lineArray);
	}
	infile.close(); // �ر��ļ�
	//���������ֵ
	Eigen::Vector3d robothand_start;
	robothand_start[0] = 196.60;//�����˵����굥λ
	robothand_start[1] = -2000;//�����˵����굥λ
	robothand_start[2] = -10;//�����˵����굥λ-211.68 -11

	cout <<"jsssssss=" << strArray[mixstacknum][0] << " " << strArray[mixstacknum][1] << " " << strArray[mixstacknum][2] << " " << strArray[mixstacknum][3] <<" "<<
		strArray[mixstacknum][4] << " " << strArray[mixstacknum][5] << " " << strArray[mixstacknum][6] << endl;
	cout <<"�߶�" << (strArray[mixstacknum][3] / strArray[mixstacknum][6]) * 5 + strArray[mixstacknum][3] << endl;
	boxinfo.box_center3D[0]= robothand_start[0]-strArray[mixstacknum][1]*1.01;
	boxinfo.box_center3D[1] = robothand_start[1]+strArray[mixstacknum][2]*1.01;
	boxinfo.box_center3D[2] = robothand_start[2]+ strArray[mixstacknum][3]+(strArray[mixstacknum][3]/ strArray[mixstacknum][6])*5+strArray[mixstacknum][6];

	//�ߴ���Ϣ
	boxinfo.box_size3D[0] = strArray[mixstacknum][4];
	boxinfo.box_size3D[1] = strArray[mixstacknum][5];
	boxinfo.box_size3D[2] = strArray[mixstacknum][6];


	return 0;
}
int getMixStackPos_extrn(std::string filename,int mixstacknum, BoxInfo& boxinfo) {
	ifstream infile(filename.c_str()); // ���ļ�
	if (!infile.is_open()) { // ����ļ��Ƿ�ɹ���
		cout << "��ȡ�ļ�ʧ��" << endl;
		return 1;
	}
	string line;
	vector<string> lines;
	vector<vector<double>> strArray;

	while (getline(infile, line)) { // ���ж�ȡ�ļ�����
		// ��ɶ�ά���ṹ  
		stringstream ss(line);
		string str;
		vector<double> lineArray;
		// ���ն��ŷָ�  
		while (getline(ss, str, ',')) {
			lineArray.push_back(stod(str));
		}
		strArray.push_back(lineArray);
	}
	infile.close(); // �ر��ļ�
	//���������ֵ
	Eigen::Vector3d robothand_start;
	robothand_start[0] = 196.60;//�����˵����굥λ
	robothand_start[1] = -2000;//�����˵����굥λ
	robothand_start[2] = -10;//�����˵����굥λ-211.68 -11

	/*int flag = 1;
	fstream f;
	f.open("stack_robotpoint.txt", ios::out);
	for (int i = 0; i < strArray.size(); i++) {
		f <<i+1<<","<< strArray[i][1] << "," << strArray[i][2] << "," << strArray[i][3] << "," << strArray[i][4] << "," << strArray[i][5] << "," << strArray[i][6] << endl;
	}
	f.close();*/

	cout <<"jsssssss  " << strArray[mixstacknum][0] << " " << strArray[mixstacknum][1] << " " << strArray[mixstacknum][2] << " " << strArray[mixstacknum][3] <<" "<<
		strArray[mixstacknum][4] << " " << strArray[mixstacknum][5] << " " << strArray[mixstacknum][6] << endl;
	cout <<"�߶�" << (strArray[mixstacknum][3] / strArray[mixstacknum][6]) * 5 + strArray[mixstacknum][3] << endl;
	boxinfo.box_center3D[0]= robothand_start[0]-strArray[mixstacknum][1]*1.01;
	boxinfo.box_center3D[1] = robothand_start[1]+strArray[mixstacknum][2]*1.01;
	boxinfo.box_center3D[2] = robothand_start[2]+ strArray[mixstacknum][3]+(strArray[mixstacknum][3]/ strArray[mixstacknum][6])*5+strArray[mixstacknum][6];

	//�ߴ���Ϣ
	boxinfo.box_size3D[0] = strArray[mixstacknum][4];
	boxinfo.box_size3D[1] = strArray[mixstacknum][5];
	boxinfo.box_size3D[2] = strArray[mixstacknum][6];


	return 0;
}

// TODO: �������λ����
//������
int getMixStackPosTest(std::vector<camsInfo> m_Cams, BoxInfo& boxinfo, std::vector<cv::Point3f> bufferplane_vertex) {
	Eigen::Vector3f tmp_box_size3D;
	tmp_box_size3D = boxinfo.box_size3D;

	//���������ֵ
	Eigen::Vector3d robothand_start;
	robothand_start[0] = 196.60;//�����˵����굥λ
	robothand_start[1] = -2000;//�����˵����굥λ
	robothand_start[2] = -10;//�����˵����굥λ-211.68 -11

	cout << "jsssssss=" << boxinfo.box_center3D[0] << " " << boxinfo.box_center3D[1] << " " << boxinfo.box_center3D[2] << " " <<
		boxinfo.box_size3D[0] << " " << boxinfo.box_size3D[1] << " " << boxinfo.box_size3D[2] << endl;
	//cout << "�߶�" << (boxinfo.box_center3D[2] / boxinfo.box_size3D[2]) * 5 + boxinfo.box_center3D[2] << endl;
	double res_z = getBoxPos2(m_Cams, boxinfo, bufferplane_vertex);

	float tmp_x = boxinfo.box_center3D[1];
	float tmp_y = boxinfo.box_center3D[0];
	boxinfo.box_center3D[0] = robothand_start[0] - tmp_x * 1.1;
	boxinfo.box_center3D[1] = robothand_start[1] + tmp_y * 1.1;
	cout << "res_z: " << res_z << endl;

	if (res_z > 0) {
		boxinfo.box_center3D[2] = robothand_start[2] + res_z * 1000;
	}
	else
	{
		boxinfo.box_center3D[2] = robothand_start[2] + boxinfo.box_center3D[2];
	}
	
	cout << "�������=" << boxinfo.box_center3D[0] << " " << boxinfo.box_center3D[1] << " " << boxinfo.box_center3D[2] << endl;


	//�ߴ���Ϣ
	boxinfo.box_size3D[0] = tmp_box_size3D[0];
	boxinfo.box_size3D[1] = tmp_box_size3D[1];
	boxinfo.box_size3D[2] = tmp_box_size3D[2];

	return 0;
}

// ���ֽ����
int getMixTakePos_extrn(std::string filename, int mixstacknum, BoxInfo& boxinfo) {
	ifstream infile(filename.c_str()); // ���ļ�
	if (!infile.is_open()) { // ����ļ��Ƿ�ɹ���
		cout << "��ȡ�ļ�ʧ��" << endl;
		return 1;
	}
	string line;
	vector<string> lines;
	vector<vector<double>> strArray;

	while (getline(infile, line)) { // ���ж�ȡ�ļ�����
		// ��ɶ�ά���ṹ  
		stringstream ss(line);
		string str;
		vector<double> lineArray;
		// ���ն��ŷָ�  
		while (getline(ss, str, ',')) {
			lineArray.push_back(stod(str));
		}
		strArray.push_back(lineArray);
	}
	infile.close(); // �ر��ļ�

	sort(strArray.begin(), strArray.end(), [](const vector<double>& a, const vector<double>& b) {
		if (a[2] != b[2]) {
			return a[2] > b[2];
		}
		if (a[1] != b[1]) {
			return a[1] > b[1];
		}
		return a[0] < b[0];
		});

	/*for (const auto& row : strArray) {
		for (double num : row) {
			cout << num << " ";
		}
		cout << endl;
	}*/

	cout << "��ǰ���������Ϣ:  " << strArray[mixstacknum][0] << " " << strArray[mixstacknum][1] << " " << strArray[mixstacknum][2] << " " << strArray[mixstacknum][3] << " " <<
		strArray[mixstacknum][4] << " " << strArray[mixstacknum][5] << " " << strArray[mixstacknum][6] << endl;
	boxinfo.box_center3D[0] = strArray[mixstacknum][0];
	boxinfo.box_center3D[1] = strArray[mixstacknum][1];
	boxinfo.box_center3D[2] = strArray[mixstacknum][2];

	//�ߴ���Ϣ
	boxinfo.box_size3D[0] = strArray[mixstacknum][4];
	boxinfo.box_size3D[1] = strArray[mixstacknum][5];
	boxinfo.box_size3D[2] = strArray[mixstacknum][6];
	return 0;
}

//��һ����ȡ�������λ����Ϣ
int getStackPos(const RPointCloudPtr& cloud_buffer,const RPointCloudPtr& cloud_robot_points, int trailer_state[], vector<vector<vector<cv::Point3f>>>& saved_points, vector<vector<vector<cv::Point3f>>>& box_szie, float* intr_buffer, std::vector<cv::Point3f> bufferplane_vertex, std::vector<cv::Point3f> stackplane_vertex, BoxInfo& boxinfo, int& wherestack) {
	cout << "��ȡ���λ��" << endl;
	//��ȡ��������8������
	imgLib::ImageAlgorithmlib imglib;
	imgLib::PackageInfo Packinfo;
	Packinfo.size[0] = boxinfo.box_size3D[0];
	Packinfo.size[1] = boxinfo.box_size3D[1];
	Packinfo.size[2] = boxinfo.box_size3D[2];


	cout << "�������ֵΪ:" << Packinfo.size[0] << " " << Packinfo.size[1] << " " << Packinfo.size[2] << endl;
	//��������������򶥵�;
	cv::Point3f box_center;
	double translation_z;
	float angle;
	int threshold = 0;
	
	RPointCloudPtr cloud_buffer_temp(new RPointCloud);

	//int threshold = 0;
	//����F1
	//if (Fflag == 1) {
	//	Packinfo.size[0] = 0.200;
	//	Packinfo.size[1] = 0.150;
	//	Packinfo.size[2] = 0.100;
	//	threshold = 480;
	//}
	//else if (Fflag == 2) {
	//	//����F2
	//	Packinfo.size[0] = 0.300;
	//	Packinfo.size[1] = 0.200;
	//	Packinfo.size[2] = 0.150;
	//	threshold = 144;
	//}
	//else if (Fflag == 3) {
	//	//����F3
	//	Packinfo.size[0] = 0.300;
	//	Packinfo.size[1] = 0.250;
	//	Packinfo.size[2] = 0.200;
	//	threshold = 80;
	//}
	//else if (Fflag == 4) {
	//	//����F4
	//	Packinfo.size[0] = 0.400;
	//	Packinfo.size[1] = 0.300;
	//	Packinfo.size[2] = 0.200;
	//	threshold = 60;
	//}
	//else if (Fflag == 5) {
	//	//����F5
	//	Packinfo.size[0] = 0.400;
	//	Packinfo.size[1] = 0.300;
	//	Packinfo.size[2] = 0.300;
	//	threshold = 36;
	//}
	//else if (Fflag == 6) {
	//	//����F6
	//	Packinfo.size[0] = 0.700;
	//	Packinfo.size[1] = 0.400;
	//	Packinfo.size[2] = 0.320;
	//	threshold = 12;
	//}
	//else if (Fflag == 7) {
	//	//����F2
	//	Packinfo.size[0] = 1.000;
	//	Packinfo.size[1] = 0.800;
	//	Packinfo.size[2] = 0.750;
	//	threshold = 1;
	//}
	//else if (Fflag == 8) {
	//	//����F2
	//	Packinfo.size[0] = 0.150;
	//	Packinfo.size[1] = 0.150;
	//	Packinfo.size[2] = 0.010;
	//	threshold = 2;
	//}
	cout <<"����" << boxnum[0] << endl;
	int count_box = 0;
	while (true) {
		int code = imglib.trailerPointsDesign(cloud_buffer_temp, trailer_state, saved_points, box_szie, boxnum, Packinfo,threshold, box_center, angle, bufferplane_vertex);
		if (code == 0&& trailer_state[0]<= boxnum[0]) {
			cout << "���ʧ��" << endl;
			return 2;
		}
		if (code == 1) {
			count_box += 1;
			//����㷨
			wherestack = 1;
			cout << "���ɹ�" << endl;
		}
		if (count_box > threshold) {
			return 2;
		}
		std::vector<cv::Point2f> bufferroi;
		bufferroi.resize(4);
		vector<cv::Point2f> Vertex;
		imglib.rectVertex(Packinfo.size[0] * 0.5*0.001, Packinfo.size[1] * 0.5*0.001, 0, cv::Point2f(box_center.x, box_center.y), Vertex);
		Vertex.push_back(Vertex[0]);
		int rgb[3] = { 0,255,0 };
		if (count_box <= 12) {
			rgb[0] = 255;
			rgb[1] = 0;
			rgb[2] = 0;
		}
		else if (count_box > 12 && count_box <= 24) {
			rgb[0] = 255;
			rgb[1] = 255;
			rgb[2] = 0;
		}
		else if (count_box > 24 && count_box <= 36) {
			rgb[0] = 255;
			rgb[1] = 0;
			rgb[2] = 255;
		}
		else if (count_box > 36 && count_box <= 48) {
			rgb[0] = 255;
			rgb[1] = 125;
			rgb[2] = 255;
		}
		else if (count_box > 48 && count_box <= 60) {
			rgb[0] = 125;
			rgb[1] = 125;
			rgb[2] = 255;
		}

		
		imglib.drawBox(cloud_buffer_temp, Vertex, 0, Packinfo.size[2]*0.001, box_center.z, rgb);//cloud_filtered

		//bufferroi[0].x = bufferplane_vertex[0].x;//�����˿�ʼ����
		//bufferroi[1].x = bufferplane_vertex[1].x;
		//bufferroi[2].x = bufferplane_vertex[2].x;
		//bufferroi[3].x = bufferplane_vertex[3].x;

		//bufferroi[0].y = bufferplane_vertex[0].y;//�����˿�ʼ����
		//bufferroi[1].y = bufferplane_vertex[1].y;
		//bufferroi[2].y = bufferplane_vertex[2].y;
		//bufferroi[3].y = bufferplane_vertex[3].y;

		//cout << bufferplane_vertex[0].x << " " << bufferplane_vertex[0].y << endl;
		//cout << bufferplane_vertex[1].x << " " << bufferplane_vertex[1].y << endl;
		//cout << bufferplane_vertex[2].x << " " << bufferplane_vertex[2].y << endl;
		//cout << bufferplane_vertex[3].x << " " << bufferplane_vertex[3].y << endl;

		//imglib.drawLins(cloud_buffer, bufferroi, 3.19, rgb);
		//imglib.ptvisual.showPointCloud(cloud_buffer_temp, "origin", 30);
		//Sleep(200);
		//*cloud_bufferandbox = *cloud_bufferandbox + *cloud_buffer_temp;
		cout << "��һ���滮��λ��" << box_center.x << " " << box_center.y<<" " << box_center.z << endl;
		//������ӱ궨����
		
		boxinfo.box_center3D[0] = box_center.x;
		boxinfo.box_center3D[1] = box_center.y;
		boxinfo.box_center3D[2] = box_center.z + 290;
		boxinfo.angle3D[2] = 5.27;
		*cloud_buffer=*cloud_buffer_temp;
		cloud_robot_points->push_back(pcl::PointXYZRGB(boxinfo.box_center3D[0], boxinfo.box_center3D[1], boxinfo.box_center3D[2],255,0,0));
		//pcl::io::savePLYFile("cloud_robot_points.ply", *cloud_robot_points);
		return 0;
	
	}
	return 0;
}

//chai duo
int getStackTakeSingle(const RPointCloudPtr& cloud_robot_points,BoxInfo& boxinfo) {
	RPointCloudPtr cloud_buffer_temp(new RPointCloud);
	pcl::io::loadPLYFile("cloud_robotpoint.ply",*cloud_buffer_temp);
	//*cloud_buffer_temp = *cloud_robot_points;
	cout << "��������" << cloud_buffer_temp->size() << endl;
	if (cloud_buffer_temp->size() == 0) {
		return 2;
	}
	pcl::PointCloud<pcl::PointXYZRGB>::iterator index = cloud_buffer_temp->begin();
	boxinfo.box_center3D[0] = cloud_buffer_temp->points[cloud_buffer_temp->size()-1].x;
	boxinfo.box_center3D[1] = cloud_buffer_temp->points[cloud_buffer_temp->size()-1].y;
	boxinfo.box_center3D[2] = cloud_buffer_temp->points[cloud_buffer_temp->size()-1].z;
	cout << "ȡ���Ļ�����ץȡ��" << boxinfo.box_center3D[0] << " " << boxinfo.box_center3D[1] << " " << boxinfo.box_center3D[2]<<endl;
	cloud_buffer_temp->erase(index+ cloud_buffer_temp->size()-1);
	pcl::io::savePLYFile("cloud_robotpoint.ply",*cloud_buffer_temp);
	*cloud_robot_points =*cloud_buffer_temp;
	return 0;
}
int getStackTakeTest(std::vector<camsInfo> m_Cams, BoxInfo& boxinfo) {
	cv::Mat depth_stack, color_stack;
	float* intr_stack = m_Cams[0].intri_color.data;

	//����������
	RPointCloudPtr cloud_trans(new RPointCloud);
	RPointCloudPtr cloud_ori(new RPointCloud);
	tycam.getSpecifiedCameraData(m_Cams[0], depth_stack, color_stack);
	img.depth2PointCloud(intr_stack, depth_stack, color_stack, cloud_trans);

	/*Eigen::Vector3f rot_stack_test, pos_stack_test;
	rot_stack_test << 180, 0, 0;
	pos_stack_test << (0.286 - 0.738752), (-1.65 - 0.03672 + 0.165), (2.328 + 1 - 0.144667);
	Eigen::Matrix4d rt_mat_above = TransForms::ComposeEuler(pos_stack_test[0], pos_stack_test[1], pos_stack_test[2],rot_stack_test[0], rot_stack_test[1], rot_stack_test[2]);
	Eigen::Matrix3d r_mat_above = rt_mat_above.block<3, 3>(0, 0);
	RPointCloudPtr box_cloud_trans(new RPointCloud);
	pcl::transformPointCloud(*cloud_trans, *cloud_trans, rt_mat_above);
	pcl::io::savePLYFile("cloud_trans.ply", *cloud_trans);*/


	*cloud_ori = *cloud_trans;
	pcl::io::savePLYFile("cloud_ori.ply",*cloud_ori);
	passThrough_stackTake(cloud_trans, -0.63, 0.82, -0.69, 0.82, 0, 3.13);
	eazyShow(cloud_trans);
	
	RPointCloudPtr box_cloud(new RPointCloud);

	//�������
	std::vector<pcl::PointIndices> cluster_indices;
	int result=img.getBoxEuclideanClusterExtraction(cloud_trans, 200, 1000000, 0.02, cluster_indices);
	if (result == 0) {
		cout << "����Ϊ��" << endl;
		return 2;
	}
	else {
		cout <<"�������Ϊ��" << cluster_indices.size() << endl;
	}

	std::vector<cv::Point3f> box_cluster_size;
	std::vector<cv::Point3f> box_cluster_center;
	cout << "���Ӿ������� "<<box_cluster_center.size()<< endl;
	RPointCloudPtr boxall_cluster(new RPointCloud);
	RPointCloudPtr box_cluster(new RPointCloud);
	

	int rgb[3] = { 50,50,50 };
	int j = 0;

	RPointCloudPtr cloud_center(new RPointCloud);
	std::vector<RPointCloudPtr> box_rectline;
	for (std::vector<pcl::PointIndices>::const_iterator it=cluster_indices.begin(); it!=cluster_indices.end(); ++it) {	

		rgb[0] = j * 25;
		rgb[1] = (j+1) * 25;
		rgb[2] = (j+2) * 25;
		for (const auto& idx : it->indices) {
			box_cluster->push_back((*cloud_trans)[idx]);
			boxall_cluster->push_back(pcl::PointXYZRGB((*cloud_trans)[idx].x, (*cloud_trans)[idx].y, (*cloud_trans)[idx].z, rgb[0], rgb[1], rgb[2]));
		}
		
		//cout <<"�������������" << box_cluster->size() << endl;

		float depth_cluster=0;
		float min_z = std::numeric_limits<float>::max();
		float max_z = -std::numeric_limits<float>::max();
		std::vector<cv::Point2f> points_2d_cluster;

		for (const auto& point : box_cluster->points) {
			points_2d_cluster.emplace_back(point.x, point.y);  // ת��Ϊ��ά��
			min_z = std::min(min_z, point.z);
			max_z = std::max(max_z, point.z);
		}

		double clu_avgz = (min_z + max_z) / 2;
		// ��С��Ӿ���
		cv::RotatedRect box_clu = cv::minAreaRect(points_2d_cluster);
		if (box_clu.size.width < box_clu.size.height) {
			box_clu.angle -= 90;
			std::swap(box_clu.size.height, box_clu.size.width);
		}
		float clu_length = box_clu.size.width;
		float  clu_width = box_clu.size.height;
		//cout <<" clu_length:" << clu_length << endl;

		// ץȡ���ĵ�
		cv::Point2f box_center = box_clu.center;
		float box_height = abs(3.19 - depth_cluster - 0.005);  // ����һ��
		
		cv::Point2f rect_points[4];
		box_clu.points(rect_points);
		RPointCloudPtr cloud_Line(new RPointCloud);
		for (int iter = 0; iter < 4; iter++) {
			//cout << rect_points[iter].x << " " <<rect_points[iter].y << endl;
			cloud_Line->push_back(pcl::PointXYZRGB(rect_points[iter].x, rect_points[iter].y, clu_avgz,0,255,0));
		}
		
		cout <<"ֽ�����ĵ�"<< box_center.x<<" "<< box_center.y<<" "<< clu_avgz<< "ֽ��Ƕ�" << box_clu.angle << endl;

		box_rectline.push_back(cloud_Line);
		cloud_Line->clear();
		box_cluster_center.push_back(cv::Point3f(box_center.x, box_center.y, clu_avgz));
		box_cluster_size.push_back(cv::Point3f(clu_length, clu_width, box_height));
		box_cluster->clear();
		cloud_center->push_back(pcl::PointXYZRGB(box_center.x, box_center.y, clu_avgz,255,0,0));
		j++;
	}

	std::vector<int> flag(box_cluster_center.size());
	//��������ʼ��λ��
	double startx = 0.73, starty = -0.70;
	//����ÿ�����ĵ㵽����ľ���
	double min_distance = 9999999.0;
	int kflag = -1;
	std::vector<int> mflag(box_cluster_center.size());
	for (int i = 0; i<mflag.size(); i++) {
		mflag[i] = 0;
	}
	std::vector<cv::Point3f> grasp_center_sort;
	while (true) {
		min_distance = 9999999.0;
		for (int i = 0; i < box_cluster_center.size(); i++) {
			if (mflag[i] == 0) {
				double distance = sqrt(pow((box_cluster_center[i].x - startx), 2) + pow((box_cluster_center[i].y - starty), 2));
				if (distance < min_distance) {
					min_distance = distance;
					kflag = i;
				}
			}
		}
		mflag[kflag] = 1;
		grasp_center_sort.push_back(cv::Point3f(box_cluster_center[kflag].x, box_cluster_center[kflag].y, box_cluster_center[kflag].z));
		if (grasp_center_sort.size() == 9) {
			break;
		}
		startx = box_cluster_center[kflag].x;
		starty = box_cluster_center[kflag].y;
	}
	
	for (int i = 0; i < grasp_center_sort.size(); i++) {
		cout << "����ץȡ��ʼ������ĵ�" << grasp_center_sort[i].x << " " << grasp_center_sort[i].y << endl;
	}
	Eigen::Vector3d rot_stack, pos_stack;
	rot_stack << 180, 0, 0;
	pos_stack << (0.286-0.738752), (-1.65-0.03672+0.165), (2.328+1-0.144667);
	Eigen::Vector3d campos;
	campos[0] = grasp_center_sort[0].x;
	campos[1] = grasp_center_sort[0].y;
	campos[2] = grasp_center_sort[0].z;

	Eigen::Vector3d robot=img.cam2BasePos(campos, pos_stack, rot_stack);
	cout << "�����˲���" << robot[0]*1000 << " " << robot[1]*1000 <<" " << robot[2]*1000 << endl;

	ShowStackplaneandBox(cloud_ori, boxall_cluster, cloud_center, box_rectline);
	return 0;
}

//�ҵ�������̵�λ
int initstack(std::vector<camsInfo> m_Cams, const RPointCloudPtr& cloud_buff, const RPointCloudPtr& cloud_sta,
	std::vector<cv::Point3f>& bufferplane_vertex,std::vector<cv::Point3f>& stackplane_vertex) {
	
	cv::Mat depth_buffer, color_buffer, depth_stack, color_stack;
	float*  intr_buffer = m_Cams[0].intri_color.data;
	float*  intr_stack = m_Cams[1].intri_color.data;
	float*  intr_grap = m_Cams[2].intri_color.data;
	cout <<"intr_buffer: " << intr_buffer << endl;
	//����������
	RPointCloudPtr cloud_buffer2(new RPointCloud);
	tycam.getSpecifiedCameraData(m_Cams[0], depth_buffer, color_buffer);
	img.depth2PointCloud(intr_buffer, depth_buffer, color_buffer, cloud_buffer2);
	passThrough_pure(cloud_buffer2, -0.6, 0.635, -0.67, 0.685, 2.9, 3.2);
	//pcl::io::savePLYFileASCII("cloud_buffer2.ply",*cloud_buffer2);
	
	/*int rtncode0 = getBoundingBox(cloud_cluster, box_size3D, box_center3D, angle3D);;
	Eigen::Vector3f box_size3D, box_center3D, angle3D;
	if (rtn == 0) {
		return -1;
	}*/

	//��ȡ���̽ǵ���Ϣ
	RTN_IMG rtncode2;
	Eigen::Vector3f bufferplane_size3D;
	Eigen::Vector3f bufferplane_center3D;
	Eigen::Vector3f bufferplane_angle3D;
	std::vector<cv::Point3f> bufferplane_vertex_temp;
	rtncode2 = getBoxVertex(cloud_buffer2, bufferplane_size3D, bufferplane_center3D, bufferplane_angle3D, bufferplane_vertex);
	cout <<"�����̽Ƕ�" << bufferplane_angle3D[0] << " " << bufferplane_angle3D[1] << " " << bufferplane_angle3D[2] << endl;
	//cout << bufferplane_vertex_temp[0].x << " " << bufferplane_vertex_temp[0].y << " " << bufferplane_vertex_temp[0].z << endl;

	if (rtncode2 == 0) {
		/*bufferplane_vertex[0] = bufferplane_vertex_temp[0];
		bufferplane_vertex[1] = bufferplane_vertex_temp[1];
		bufferplane_vertex[2] = bufferplane_vertex_temp[2];
		bufferplane_vertex[3] = bufferplane_vertex_temp[3];*/
		*cloud_buff = *cloud_buffer2;
		cout << "��ȡ�������̶���ɹ�" << endl;
		return 0;
	}
	else {
		return -1;
		cout << "��ȡ�������̶���ʧ��" << endl;
	}
	

	//������л����ʱ��ע��	
	//���������
	//RPointCloudPtr cloud_stack(new RPointCloud);
	//tycam.getSpecifiedCameraData(m_Cams[1], depth_stack, color_stack);
	//img.depth2PointCloud(intr_stack, depth_stack, color_stack, cloud_stack);
	//*cloud_sta = *cloud_stack;
	////��ʼ��ȡ������̽ǵ���Ϣ
	//RTN_IMG rtncode1;
	//Eigen::Vector3f stackplane_size3D;
	//Eigen::Vector3f stackplane_center3D;
	//Eigen::Vector3f stackplane_angle3D;
	//std::vector<cv::Point3f> stackplane_vertex_temp;
	//cout << "cloud_stack " << cloud_stack->size() << endl;
	//rtncode1 = getBoxVertex(cloud_stack, stackplane_size3D, stackplane_center3D, stackplane_angle3D, stackplane_vertex);
	//if (rtncode1 == 0) {
	//	*cloud_sta = *cloud_stack;
	//	cout << "��ȡ������̶���ɹ�" << endl;
	//	return  0;
	//}
	//else {
	//	return -1;
	//	cout << "��ȡ������̶���ʧ��" << endl;
	//}	
}

int bufferTake(BoxInfo& boxinfo, int& wherestack) {
	cout << "�������λ" << endl;
	return 0;
}

int main(int argc, char* argv[]) {
		 
	RPointCloudPtr cloud_bufferandbox(new RPointCloud);
	string id_stack, id_buffer, id_grab;
	id_buffer = "207000143128";//������������
	id_stack = "207000145033";//�ұ���������
	id_grab = "207000130636";//ʰȡ�������
	std::vector<camsInfo> m_Cams;
	cv::Mat depth_buffer, color_buffer, depth_stack, color_stack;
	vector<char*> ty_cameraID = { (char*)id_buffer.c_str(),(char*)id_stack.c_str(),(char*)id_grab.c_str() };
	m_Cams.resize(ty_cameraID.size());
	if (tycam.CamMultiTuyangInit(ty_cameraID, m_Cams) == -1)
	{
		LOGD("ͼ�������ʼ������ ... ");
		return -2;
	}

	float* intr_buffer = m_Cams[0].intri_color.data;
	float* intr_stack = m_Cams[1].intri_color.data;
	float* intr_grap = m_Cams[2].intri_color.data;



	//��ʼ��������̺ͻ������̽ǵ�
	std::vector<cv::Point3f> bufferplane_vertex;
	std::vector<cv::Point3f> stackplane_vertex;
	RPointCloudPtr cloud_stack(new RPointCloud);
	RPointCloudPtr cloud_buffer(new RPointCloud);
	RPointCloudPtr cloud_robotpoint(new RPointCloud);

	BoxInfo boxinfo;
	//string filename="D:\\stack_cargobox\\ֽ�������ʶ��\\robotstackpoint.txt";
	//int mixstacknum = 72;
	/*int res=getMixStackPos(filename, mixstacknum, boxinfo);
	if (res) {
		cout << res << endl;
	}*/

	

	int kflag;
	int sumbox = 0,tempbox=0;

	//צ�ӳ�65cm ��18cm
	kflag=initstack(m_Cams, cloud_buffer, cloud_stack, bufferplane_vertex, stackplane_vertex);
	if (kflag == 0) {
		cout << "��ȡ������̻������ɹ�" << endl;
		cout << "���̽ǵ���������Ϊ��" << endl;
		for (auto x : bufferplane_vertex) {
			cout << x << endl;
		}
	}


	//������	//tcp ��������
	MyHvServer server;
	while (true) {
		if (server.iniServer(2048, "127.0.0.1", 1) == 1) {
			cout << "connect success" << endl;
			break;
		}
		else {
			cout << "connect fail" << endl;
		}
	}
	//TODO ������ͨ��
	MyHVClient hvclint;
	while (true) {
		if (hvclint.IniSocket(2025, "127.0.0.1")) {
			cout << "connect python server success" << endl;
			break;
		}
		else {
			cout << "connect python server fail" << endl;
		}
	}
	cout << "wait commend..." << endl;
	string filename1 = "D:\\DESKTOP\\ֽ���Ӿ�\\robotstackpoint.txt";
	string filename = "D:\\DESKTOP\\ֽ���Ӿ�\\stack_robotpoint.txt";
	string filename2 = "D:\\DESKTOP\\ֽ���Ӿ�\\maduo_record.txt";   // ��ϲ��˳��
	ofstream outfile("maduo_record.txt", ios::app);

	int mixstacknum = 0;
	while (true) {
		std::string command;
		if (server.RecvStr(command) > 0) {
			
			cout << "get command...." << command << endl;
			vector<string>temp_command;
			stringSplit(command, ',', temp_command);
			for (int i = 0; i < temp_command.size(); i++) {
				cout << temp_command[i] << " ";
			}
			//try {
				if (temp_command[0] == "getBoxPos") {
					Eigen::Vector3d pos;
					Eigen::Vector3d rot;
					double firstBoxHeight;
					int StarkingBias;
					BoxInfo boxinfo;
					int wherestack = -1;
					int floor=0, row=0, col=0;
					int res = getBoxPos(m_Cams, boxinfo, floor, row, col, wherestack);
					std::string rtnStr,pythonstr;
					boxnum[0] = floor;
					boxnum[1] = row;
					boxnum[2] = col;
					rtnStr += "pos";
					char rtn[1024];
					if (!res) {
						
						boxinfo.box_center3D[2] = boxinfo.box_center3D[2] + 5;
						sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
							res, boxinfo.box_center3D[0], boxinfo.box_center3D[1], boxinfo.box_center3D[2], boxinfo.angle3D[2],
							boxinfo.box_size3D[0], boxinfo.box_size3D[1], boxinfo.box_size3D[2], wherestack);
						rtnStr += rtn;
						cout << "send:" << rtnStr << endl;
						server.SendStr(rtnStr);
					}
					else {
						sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
							res, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, wherestack);
						rtnStr += rtn;
						cout << "send:" << rtnStr << endl;
						server.SendStr(rtnStr);
					}
				}
				else if (temp_command[0] == "getStackPos") {
						// TODO: �����յ�������λ��Ϣ���͸���λ
					try {
						std::string pythonstr;
						cout << "��С��" << saved_points.size() << endl;
						BoxInfo boxinfo;
						int wherestack = 1;
						// �������㷨
						boxinfo.box_size3D[0] = stof(temp_command[1]);
						boxinfo.box_size3D[1] = stof(temp_command[2]);
						boxinfo.box_size3D[2] = stof(temp_command[3]);

						// TODO: ���ߴ���Ϣ���͸�Python������㷨�������շ�������λ�Լ�whereStack
						// TODO ������ͨ��
						char pythonrtn[1024];
						pythonstr += "Stack";
						sprintf(pythonrtn, "%s,%0.3f,%0.3f,%0.3f", pythonstr, boxinfo.box_size3D[0], boxinfo.box_size3D[1], boxinfo.box_size3D[2]);

						cout << "����pythonͷ" << pythonrtn << endl;
						if (hvclint.SendChar(pythonrtn, strlen(pythonrtn))) {
							cout << "����python�˳ɹ�" << endl;
						}
						else {
							cout << "����python��ʧ��" << endl;
						}
						string pythoncommend;
						while (true) {
							if (hvclint.RecvStr(pythoncommend) > 0) {
								vector<string>pythoncommend_command;
								stringSplit(pythoncommend, ',', pythoncommend_command);
								boxinfo.box_center3D[0] = stof(pythoncommend_command[0]);
								boxinfo.box_center3D[1] = stof(pythoncommend_command[1]);
								boxinfo.box_center3D[2] = stof(pythoncommend_command[2]);
								wherestack = stof(pythoncommend_command[3]);
								break;
							}
						}
						// ��������λ
						cout << "����python���� " << boxinfo.box_center3D[0] << " " << boxinfo.box_center3D[1] << " " << boxinfo.box_center3D[2] << " " << wherestack << endl;
						int res = getMixStackPosTest(m_Cams, boxinfo, bufferplane_vertex);
						// END TODO

						//int res = getMixStackPos(filename1, mixstacknum, boxinfo);
						//int res = getStackPos(cloud_buffer, cloud_robotpoint, trailer_state, saved_points,box_size,intr_buffer, bufferplane_vertex, stackplane_vertex, boxinfo, wherestack);
						//pcl::io::savePLYFile("cloud_robotpoint.ply",*cloud_robotpoint);
						std::string rtnStr;
						char rtn[1024];
						char dianwei[1024];
						rtnStr += "pos";
						boxinfo.angle3D[2] = 5.27;
						

						if (res==0) {
							mixstacknum += 1;
							boxinfo.box_center3D[2] = boxinfo.box_center3D[2] + 5;
							sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
								res, boxinfo.box_center3D[0], boxinfo.box_center3D[1], boxinfo.box_center3D[2], boxinfo.angle3D[2],
								boxinfo.box_size3D[0], boxinfo.box_size3D[1], boxinfo.box_size3D[2], wherestack);
							rtnStr += rtn;
							cout << "send:" << rtnStr << endl;
							server.SendStr(rtnStr);
							sprintf(dianwei, "%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
								boxinfo.box_center3D[0], boxinfo.box_center3D[1], boxinfo.box_center3D[2], boxinfo.angle3D[2],
								boxinfo.box_size3D[0], boxinfo.box_size3D[1], boxinfo.box_size3D[2], wherestack);
							outfile << dianwei << std::endl;
						}
						else {
							sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
								res, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, wherestack);
							rtnStr += rtn;
							cout << "send:" << rtnStr << endl;
							server.SendStr(rtnStr);
						}
					}
					catch (const exception& e) {
						cout << "getStackPos" << e.what() << endl;
					}
						
				}
				else if (temp_command[0] == "bufferTake") {
					BoxInfo boxinfo;
					int wherestack = -1;
					int res = bufferTake(boxinfo, wherestack);
					std::string rtnStr;
					rtnStr += "pos";
					char rtn[1024];
					if (res) {
						sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
							res, boxinfo.box_center3D[0], boxinfo.box_center3D[1], boxinfo.box_center3D[2], boxinfo.angle3D[2],
							boxinfo.box_size3D[0], boxinfo.box_size3D[1], boxinfo.box_size3D[2], wherestack);
						rtnStr += rtn;
						cout << "send:" << rtnStr << endl;
						server.SendStr(rtnStr);
					}
					else {
						sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
							res, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, wherestack);
						rtnStr += rtn;
						cout << "send:" << rtnStr << endl;
						server.SendStr(rtnStr);
					}
				}
				else if (temp_command[0] == "stackTake") {
					BoxInfo boxinfo;
					int wherestack = -1;
					//int res = getStackTakeTest(m_Cams,boxinfo);
					//int res = getStackTakeSingle(cloud_robotpoint, boxinfo);
					
					int res = getMixTakePos_extrn(filename2, mixstacknum, boxinfo);
					std::string rtnStr;
					rtnStr += "pos";
					char rtn[1024];
					boxinfo.angle3D[2] = 5.27;
					/*boxinfo.box_size3D[0] = 400;
					boxinfo.box_size3D[1] = 300;
					boxinfo.box_size3D[2] = 300;*/
					if (res==0) {
						mixstacknum = mixstacknum + 1;
						sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
							res, boxinfo.box_center3D[0], boxinfo.box_center3D[1], boxinfo.box_center3D[2], boxinfo.angle3D[2],
							boxinfo.box_size3D[0], boxinfo.box_size3D[1], boxinfo.box_size3D[2], wherestack);
						rtnStr += rtn;
						cout << "send:" << rtnStr << endl;
						server.SendStr(rtnStr);
					}
					else {
						//mixstacknum = mixstacknum - 1;
						sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
							res, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, wherestack);
						rtnStr += rtn;
						cout << "send:" << rtnStr << endl;
						server.SendStr(rtnStr);
					}

}
				else {
					int wherestack = -1;
					std::string rtnStr;
					rtnStr += "pos";
					char rtn[1024];
					int res = 1;
					sprintf(rtn, ",%d,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%0.3f,%d",
						res, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, 0.000, wherestack);
					rtnStr += rtn;
					cout << "send:" << rtnStr << endl;
					server.SendStr(rtnStr);
				}
			//}
			//catch (const exception& e) {
			//	cout << "trycatch:" << e.what() << endl;
			//}
			
		}
		//*cloud_bufferandbox += *cloud_buffer;
		//eazyShow(cloud_bufferandbox);
		
		Sleep(10);
	}
	outfile.close();
	return 0;
}