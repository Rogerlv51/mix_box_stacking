#pragma once

#include "hv/TcpServer.h"
#include<iostream>
#include"hv/hloop.h"
#include<vector>
//#include<Logger.hpp>
using namespace std;
using namespace hv;

typedef struct {
	void* data;
	int size;
	bool isReadEnd;
}SrvMessage_t;

class MyHvServer : public TcpServer {
public:

	bool iniServer(int port, const char* addr = "127.0.0.1", int connect_num = 1);

	int RecvChar(char* msg);
	/**
	 * \brief �����ַ�����Ϣ.
	 * \param [str]msg
	 * \return -1:���ջ�����ʧ�ܣ�>0:�����ַ���С
	 */
	int RecvStr(std::string& msg);

	int SendStr(const string& str);

	int SendChar(const char* val, int size);

	void SetBlockMode(const bool block);

	int isConnected();
	//��ӡ����
	void printHex(char* buff, int buff_len);

private:
	std::vector<hio_t*>tcp_io;
	bool _block = false;
	int readChar(char* msg);
	int readStr(std::string& str);
	std::mutex calls_mutex;
	SrvMessage_t srv_msg;
};