#pragma once
#include <windows.h>
#include <iostream>
#include <cstring>
#include <string>
#pragma pack(push,1)
typedef struct MyData {
	int length;
	int width;
	int height;
	int whereStack;
	int flag;
}MyData;
#pragma pack(pop)

void sendMyData(const std::wstring& shm_name, MyData& data);

MyData readMyData(const std::wstring& shm_name);
