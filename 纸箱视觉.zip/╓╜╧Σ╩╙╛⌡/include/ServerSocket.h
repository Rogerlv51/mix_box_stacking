#pragma once

// https://semver.org
#define MAJOR_VERSION  1
#define MINOR_VERSION  0
#define PATCH_VERSION  1

#include <xstring>
#include <winsock2.h>
#pragma comment(lib, "WS2_32")

class CServerSocket
{
public:
	CServerSocket();
	virtual ~CServerSocket();

public:
	int Initial();
	int StartServer(u_short port);
	int SetBlockMode(int mode);
	int GetLastError();
	int IsSocketClosed();

	int WaitForClientConnection();
	int Send(const char* pDat, int len);
	int Receive(char* pDat, int max_len);
	int RecvStr(std::string& str);
	int SendStr(const std::string str);
	int CloseClientConnection();
	int CloseServer();

public:
	SOCKET server;
	SOCKADDR_IN addrClient;
	SOCKET clientSocket;
};

