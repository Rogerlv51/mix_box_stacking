#pragma once

#include "TYImageProc.h"
#include "common.hpp"
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/opencv.hpp>
using namespace std;


#define MAP_DEPTH_TO_COLOR  1 //���ͼ���ɫͼ���뷽ʽ�л�����,��1�����ͼ���뵽��ɫͼ����ϵ��0�򽫲�ɫͼ���뵽���ͼ����ϵ
#define SpeckleFilter 1
#define R_GAIN 100 //0-4095//100
#define B_GAIN 80	//80
#define G_GAIN 100	//100
#define ANALOG_GAIN 1//0-64
#define EXPOSURE_TIME 300 //0-1088	//300
#define LR_ANALOG_GAIN 1 //0-3LR_ANALOG_GAIN
//#define LR_GAIN 200 //0-255
//#define LR_EXPOSURE_TIME 900 //0-1088
#define DEPTH_IMAGE_SIZE TY_IMAGE_MODE_DEPTH16_1280x960
#define COLOR_IMAGE_SIZE TY_IMAGE_MODE_YUYV_1280x960
//#define DEPTH_IMAGE_SIZE TY_IMAGE_MODE_DEPTH16_640x480
//#define COLOR_IMAGE_SIZE TY_IMAGE_MODE_YUYV_640x480

//�¼��ص�
struct camsInfo {
	TY_DEV_HANDLE hDevice;
	TY_INTERFACE_HANDLE hIface;
	TY_ISP_HANDLE IspHandle;
	char* frameBuffer[2];
	TY_CAMERA_INTRINSIC intri_depth;
	TY_CAMERA_INTRINSIC intri_color;
	TY_CAMERA_CALIB_INFO depth_calib;
	TY_CAMERA_CALIB_INFO color_calib;
	TY_FRAME_DATA frame;
	float  scale_unit = 1.;
};

class TYCamera {
public:
	TY_ISP_HANDLE isp_handle = NULL;
	bool display_info = false;//�Ƿ���ʾ��ӡ��Ϣ
public:
	/* @brief init single camera*/
	int CamSingleTuyangInit(std::string mac, std::string ip, camsInfo& cams);
	/* @brief init multi camera*/
	int CamMultiTuyangInit(std::vector<char*>& id_list, std::vector<camsInfo>& cams);
	/* @brief */
	int getSpecifiedCameraData(camsInfo& cams, cv::Mat& depth, cv::Mat& color);
	/* @brief close camera*/
	void CamTuyangClose(const camsInfo& cb_data);
private:
	int cvpf2typf(int cvpf);
	/* @brief event callback*/
	static void eventCallback(TY_EVENT_INFO *event_info, void *userdata);
	/* @brief mat to TY_IMAGE_DATA*/
	void mat2TY_IMAGE_DATA(int comp, const cv::Mat& mat, TY_IMAGE_DATA& data);
	/* @brief refresh camera buffer*/
	void doRegister(const TY_CAMERA_CALIB_INFO& depth_calib, const TY_CAMERA_CALIB_INFO& color_calib, const cv::Mat& depth,
		const float f_scale_unit, const cv::Mat& color, cv::Mat& undistort_color, cv::Mat& out, bool map_depth_to_color);
	/* @brief refresh camera buffer*/
	void RefreshFrameBuffer(camsInfo& cb_data);
	/* @brief get frame camera data*/
	int FecthOneFrame(camsInfo& cb_data, cv::Mat& depth, cv::Mat& color);
};


//#pragma once
//
//#include "TYImageProc.h"
//#include "common.hpp"
//#include <opencv2/highgui/highgui.hpp>
//#include <opencv2/imgproc/imgproc.hpp>
//#include <opencv2/opencv.hpp>
//
//struct CamPara {
//	int r_gain = 100;
//	int b_gain = 100;
//	int g_gain = 100;
//	int analog_gain = 1;
//	int exposure_time = 300;
//	int lr_analog_gain = 0;
//	int lr_gain = 25;
//	int lr_exposure_time = 500;
//	bool fill_hole = false;    // �Ƿ�����书��
//	bool speckle_filter = false;// �Ƿ����ǵ�ȥ������
//	bool map_depth_to_color = true;
//	int depth_image_size = TY_IMAGE_MODE_DEPTH16_640x480;
//	int color_image_size = TY_IMAGE_MODE_YUYV_640x480;
//};
//
////�¼��ص�
//struct CamInfo {
//	char                    sn[32];
//	std::vector<char>       fb[2];
//	float  scale_unit = 1.;
//	TY_DEV_HANDLE           hDev;
//	TY_INTERFACE_HANDLE     hIface;
//	TY_ISP_HANDLE           IspHandle;
//	TY_CAMERA_INTRINSIC     intri_depth;
//	TY_CAMERA_INTRINSIC     intri_color;
//	TY_CAMERA_CALIB_INFO    depth_calib;
//	TY_CAMERA_CALIB_INFO    color_calib;
//	TY_FRAME_DATA           frame;
//	DepthRender             render;
//	CamInfo() : hDev(0) {}
//};
//
//class TYCamera {
//public:
//	TY_ISP_HANDLE isp_handle = NULL;
//	bool display_info = false;//�Ƿ���ʾ��ӡ��Ϣ
//public:
//	/* @brief init single camera*/
//	int CamSingleTuyangInit(const std::string& mac, const std::string& ip, const CamPara& camPara, CamInfo& camInfo);
//	/* @brief init multi camera*/
//	int CamMultiTuyangInit(const std::vector<CamPara>& camsPara, std::vector<char*>& id_list, std::vector<CamInfo>& cams);
//	/* @brief */
//	int getCameraData(const CamPara& para, CamInfo& cam, cv::Mat& depth, cv::Mat& color, int32_t timeout = -1);
//	/* @brief close camera*/
//	void TYCamClose(const CamInfo& cb_data);
//	/* @brief Multi close camera*/
//	void MultiTYCamsClose(const std::vector<CamInfo>& cams);
//private:
//	int cvpf2typf(int cvpf);
//	/* @brief event callback*/
//	static void eventCallback(TY_EVENT_INFO* event_info, void* userdata);
//	/* @brief mat to TY_IMAGE_DATA*/
//	void mat2TY_IMAGE_DATA(int comp, const cv::Mat& mat, TY_IMAGE_DATA& data);
//	/* @brief refresh camera buffer*/
//	void doRegister(const TY_CAMERA_CALIB_INFO& depth_calib, const TY_CAMERA_CALIB_INFO& color_calib, const cv::Mat& depth,
//		const float f_scale_unit, const cv::Mat& color, cv::Mat& undistort_color, cv::Mat& out, bool map_depth_to_color);
//	/* @brief refresh camera buffer*/
//	void RefreshFrameBuffer(const CamInfo& camInfo);
//	/* @brief get frame camera data*/
//	int FecthOneFrame(const CamPara& camPara, CamInfo& camInfo, cv::Mat& depth, cv::Mat& color);
//};