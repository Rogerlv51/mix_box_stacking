/*****************************************************************//**
 * \file   MyHVClient.h
 * \brief  基于libhv库实现的tcp客户端相关功能，具有重连，心跳，高并发的读写
 * \author Fanxi Luoqi
 * \date   April 2023
 *********************************************************************/

#pragma once

#include<stdio.h>
#include<string.h>
#include <mutex>
#include <iostream>
#include "hv/TcpClient.h"

#if defined(__linux__)
 // Linux系统
#include<unistd.h>
#elif defined(_WIN32)
 // Windows系统
#include<windows.h>
#endif

typedef struct {
	void* data;
	int size;
	bool isReadEnd;
} recvMessage_t;

using namespace hv;
class MyHVClient: public TcpClient
{
public:
	std::function<void()> setMyReadUnpack;
public:
	~MyHVClient();
	//
	void psleep(int time);
	//
	void msleep(int time);
	/**
	 * \brief 通过地址和端口，创建并连接TCP.
	 * \param [in]port 端口
	 * \param [in]addr ip地址
	 * \param [in/ms]reconn_min_delay 重连最小间隔时间
	 * \param [in/ms]reconn_max_delay 重连最大间隔时间
	 * \param [in/ms]read_delay 读取超时时间ms,超时断连，默认不开启
	 * \param [in/ms]write_delay 写入超时时间ms,超时断连，默认不开启
	 * \return 成功 true，失败 false
	 */
	bool IniSocket(const int &port,
		const char*addr,
		int reconn_min_delay = 1000,
		int reconn_max_delay = 10000,
		int read_delay = 0,
		int write_delay = 0
	);
	/**
	 * \brief 发送字节消息
	 * \param [char*]msg 
	 * \param size
	 * \return -1:发送或连接失败，>0:发送字符大小
	 */
	int SendChar(char* msg, size_t size);

	/**
	 * \brief 发送字符串消息.
	 * \param msg
	 * \return -1:发送或连接失败，>0:发送字符串大小
	 */
	int SendStr(const std::string &msg);
	/**
	 * \brief 接收数据字节消息.
	 * \param [char*]msg
	 * \return -1:接收或连接失败，>0:接受字符大小
	 */
	int RecvChar(char* msg);
	/**
	 * \brief 接收字符串消息.
	 * \param [str]msg
	 * \return -1:接收或连接失败，0:没有消息，>0:接受字符大小
	 */
	int RecvStr(std::string& msg, INT32 timeout = -1);

	int setDataUnpack(void *);
	/**
	 * \brief 设置阻塞模式.
	 * \param block：[true:阻塞，false:非阻塞]
	 */
	void SetBlockMode(const bool block);
	/**
	 * \brief 设置心跳.
	 * \param msg 发送心跳的数据
	 * \param size 心跳数据的大小
	 * \param heart_delay 心跳间隔时间
	 */
	void setHeartBeatData(char *msg, int size,int heart_delay = 1000);
	/**
	 * \brief 关闭连接.
	 * \return -1:用户没有连接，1:关闭成功
	 */
	int CloseSocket();
	//打印调试
	void printHex(char* buff, int buff_len);
private:
	bool _block = false;
	Buffer buf;
	recvMessage_t recv_msg;
	heartbeat_setting_t heartbeat_setting;
	std::mutex calls_mutex;
	void setReadCallback();
	int readChar(char *msg);
	int readStr(std::string& str);
};

