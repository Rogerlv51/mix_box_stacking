#pragma once
#include<mutex>
#include<thread>
#include<string>
#include<iostream>
#include<pcl/point_cloud.h>
#include<pcl/visualization/pcl_visualizer.h>
#include<Windows.h>
#include<vector>

class PointVis
{
public:
	bool print = false;
private:
	std::vector<bool> isStop;                                            // �ж��Ƿ���ֹ
	std::vector<bool> isUpdate;                                          // �жϵ��������Ƿ����
	std::vector<bool> update_flag;
	std::vector<int>waitkey;
	std::vector<int>window_lock;
	std::mutex mutexUpdate;                                 // ������
	std::mutex mutexSpine;
	std::vector<pcl::PointCloud<pcl::PointXYZRGB>::Ptr> pointcloud_ptr;     // �����������
	std::vector<std::thread> visualizerThreads;
	std::vector<std::string>windows_name;
	void Vis(const int &ID, const std::string &window_name);
	void iniWindows();                                      // ����ֹͣλ
	void UpdatePoints(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud, const int &ID, const int&wait_time = 10);           // ���µ���
public:
	PointVis();
	~PointVis();
	//BoxInfo boxInfo;
	void showPointCloud(pcl::PointCloud<pcl::PointXYZRGB>::Ptr &cloud, const std::string &window_name, const int&wait_time);
};