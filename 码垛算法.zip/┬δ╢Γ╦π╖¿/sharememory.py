import mmap
import struct
import time
import socket

# 定义与C++匹配的结构体格式
STRUCT_FORMAT = 'iiiii'
STRUCT_SIZE = struct.calcsize(STRUCT_FORMAT)


def readData(shm_name):
   # 打开两个共享内存区
  with mmap.mmap(-1, STRUCT_SIZE, tagname=shm_name) as send_memory:
    # 从 SharedData_Send 读取数据
    send_memory.seek(0)
    data = send_memory.read(STRUCT_SIZE)
    unpacked_data = list(struct.unpack(STRUCT_FORMAT, data))
    if(unpacked_data[4] == 1):
        unpacked_data[4] = 2
  # print(unpacked_data)
  return unpacked_data

def sendData(shm_name, tmp_data):
  with mmap.mmap(-1, STRUCT_SIZE, tagname=shm_name) as receive_memory:
    # 修改数据并写入 SharedData_Receive
    receive_memory.seek(0)
    receive_memory.write(struct.pack(STRUCT_FORMAT, *tmp_data))
    print("Updated data sent to C++: ", tmp_data)

if __name__ == '__main__':
  print()
  # shm_name = 'SharedData_Send'
  # shm_name2 = 'SharedData_Receive'
  # total = 0
  # while True:
  #   tmp_data = readData(shm_name)
  #   # time.sleep(4)
  #   if(tmp_data[0]!=0 and tmp_data[4] == 2):
  #       print(tmp_data[0])
  #       total += 1
  #       tmp_data[0] = total
  #       sendData(shm_name2, tmp_data)



  # host = '127.0.0.1'
  # port= 2025
  # with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
  #     # 绑定套接字到指定的地址和端口
  #     server_socket.bind((host, port))
  #     # 监听传入的连接
  #     server_socket.listen()
  #     print(f"Server listening on {host}:{port}")

  #     # 接受连接
  #     conn, addr = server_socket.accept()
  #     with conn:
  #         print(f"Connected by {addr}")
  #         while True:
  #             # 接收数据
  #             data = conn.recv(1024)
  #             if not data:
  #                 break
  #             # 将接收到的字节数据解码为字符串
  #             received_message = data.decode('utf-8')
  #             # 以逗号分割字符串并存储到列表中
  #             tmp_data = received_message.split(',')
  #             print("接收到的数据为: ", tmp_data)
    
