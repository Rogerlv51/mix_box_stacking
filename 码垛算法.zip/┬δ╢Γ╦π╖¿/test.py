# from pianyibanben import *
from maduo import *
from time import process_time
import random
import socket

def random_test():
    process_time()
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    item_size_set = []
    #1-1
    item = [[200, 150, 100, 144],[300, 200, 150, 48],[300, 250, 200, 32], [400, 300, 200, 24], [400, 300, 300, 12], [700, 400, 320, 2]]
    # 加载所有货物数据
    for i in range(len(item)):
        for j in range(item[i][3]):
            item_size_set.append((item[i][0],item[i][1],item[i][2]))
    collect1 = []
    collect2 = []
    random.shuffle(item_size_set)  # 随机打乱顺序
    for t in range(len(item_size_set)):
        result, _ = containerA.add_cargo_to_container_improved(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        # result = containerA.add_cargo_to_container2(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        if (result == False):
            
            collect1.append(containerA.calculate_usage())
            res, _= containerB.add_cargo_to_container_improvedB(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
            if (res == True):
                collect2.append(containerB.calculate_usage())
            else:
                print("当前箱子无法放入码垛区与缓冲区")
                collect2.append(containerB.calculate_usage())
        else:
            collect1.append(containerA.calculate_usage())

    print("程序运行时间是: {:9.9}s".format(process_time()))
    draw_reslut(containerA)
    # draw_reslut(containerB)
    plt.figure()
    plt.plot([i for i in range(len(item_size_set))],collect1)
    print('利用率', containerA.calculate_usage())
    plt.xlabel("箱子编号")
    plt.ylabel("累计利用率")
    plt.show()
    print("共计码垛箱子数量为：", len(containerA.settled_cargo))
    
    

def single_plot(setted_container:Container):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlim(0, 1200)
    ax.set_ylim(0, 1200)
    ax.set_zlim(0, 1000)
    for item in setted_container.settled_cargo:
        length, width, height = item.tuple
        ax.bar3d(item.get_x, item.get_y, item.get_z, length, width, height, alpha=1)
    plt.title(f'Episode 1 Container Stacks')
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    ax.set_zlabel('Height')
    plt.show()

def single_test():
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    collect1 = []
    collect2 = []
    total = 0
    while True:
        print('请输入箱子尺寸，长宽高，以空格分隔：（输入q结束）')
        temp = input()
        if temp == 'q':
            break
        else:
            x, y, z = map(int, temp.split())
            process_time()
            result, _ = containerA.add_cargo_to_container_improved(Cargo(x, y, z))
            # result = containerA.add_cargo_to_container2(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
            if (result == False):
                
                collect1.append(containerA.calculate_usage())
                res, _ = containerB.add_cargo_to_container_improved(Cargo(x, y, z))
                if (res == True):
                    print("无法装入托盘A中, 成功放入缓冲区")
                    collect2.append(containerB.calculate_usage())
                else:
                    print("无法放入缓冲区")
                    collect2.append(containerB.calculate_usage())
            else:
                collect1.append(containerA.calculate_usage())
            total += 1
            print("装箱运行时间是: {:9.9}s".format(process_time()))
            single_plot(containerA)
    plt.figure()
    plt.plot([i for i in range(total)],collect1)
    print('利用率', containerA.calculate_usage())
    plt.xlabel("箱子编号")
    plt.ylabel("累计利用率")
    plt.show()

def random_single_plot():
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    
    item_size_set = []
    #1-1
    item = [[200, 150, 100, 144],[300, 200, 150, 48],[300, 250, 200, 32], [400, 300, 200, 24], [400, 300, 300, 12], [700, 400, 320, 2]]
    # 加载所有货物数据
    for i in range(len(item)):
        for j in range(item[i][3]):
            item_size_set.append((item[i][0],item[i][1],item[i][2]))
    collect1 = []
    collect2 = []
    random.shuffle(item_size_set)  # 随机打乱顺序
    for t in range(len(item_size_set)):
        result, _  = containerA.add_cargo_to_container_improved(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        # result = containerA.add_cargo_to_container2(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        if (result == False):
            
            collect1.append(containerA.calculate_usage())
            res, _ = containerB.add_cargo_to_container_improvedB(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
            if (res == True):
                collect2.append(containerB.calculate_usage())
            else:
                print('编号' + str(t) + "无法放入缓冲区")
                collect2.append(containerB.calculate_usage())
        else:
            collect1.append(containerA.calculate_usage())
        single_plot(containerA)
    print("共计码垛箱子数量为：", len(containerA.settled_cargo))

if __name__ == "__main__":
    # single_test()
    random_test()
    # random_single_plot()
