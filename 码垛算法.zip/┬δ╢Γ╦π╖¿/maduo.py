from enum import Enum
import numpy as np
from matplotlib import pyplot as plt
from matplotlib.figure import Figure

class CargoPose(Enum):
    long_wide_height = 0 #x,y,z轴分别对应“物体初始”长宽高
    long_height_wide = 1
    wide_long_height = 2
    wide_height_long = 3
    height_long_wide = 4
    height_wide_long = 5

class Point:
    def __init__(self,x,y,z):
        self.x = x
        self.y = y
        self.z = z

    def __repr__(self) -> str:
        return f"({self.x},{self.y},{self.z})"

    def __eq__(self, __o: object):
        return self.x == __o.x and self.y == __o.y and self.z == __o.z

    @property
    def is_valid(self):
        return self.x >= 0 and self.y >= 0 and self.z >= 0

    @property
    def tuple(self):
        return (self.x, self.y, self.z)

class Cargo:
    def __init__(self,long,width,height):
        #原始长宽高
        self.long=long
        self.width=width
        self.height=height
        self.pose=0
        #改变摆放姿态后形成的新立方体长宽高
        self.load_long=long
        self.load_width=width
        self.load_height=height

    def change_pose(self,num):
        if(num==0):
            self.load_long =self.long
            self.load_width = self.width
            self.load_height = self.height
            self.pose = 0
        elif(num==1):
            self.load_long =self.long
            self.load_width = self.height
            self.load_height = self.width
            self.pose = 1
        elif(num==2):
            self.load_long =self.width
            self.load_width = self.long
            self.load_height = self.height
            self.pose = 2
        elif(num==3):
            self.load_long =self.width
            self.load_width = self.height
            self.load_height = self.long
            self.pose = 3
        elif(num == 4):
            self.load_long =self.height
            self.load_width = self.long
            self.load_height = self.width
            self.pose = 4
        elif(num==5):
            self.load_long =self.height
            self.load_width = self.width
            self.load_height = self.long
            self.pose = 5

    @property
    def volume(self):
        return self.long*self.width*self.height

    def __repr__(self) -> str:
        return f"起始点坐标为({self.x},{self.y},{self.z})"

    def set_locate_point(self,x,y,z):
        self.x=x
        self.y=y
        self.z=z

    def __str__(self):
        return "该货物被放在("+str(self.x)+","+str(self.y)+","+str(self.z)+"),摆放长宽高为("+str(self.load_long)+","+str(self.load_width)+","+str(self.load_height)+")"

    @property
    def get_x(self):
        return self.x

    @property
    def get_y(self):
        return self.y

    @property
    def get_z(self):
        return self.z

    @property
    def tuple(self):
        return (self.load_long, self.load_width, self.load_height)

    @property
    def get_locate_bottom_area(self):#求底面积
        return self.load_long*self.load_width

    @property
    def get_locate_front_area(self):#求主视图的面积
        return self.load_height*self.load_width

    @property
    def get_locate_left_area(self):#求左视图的面积
        return self.load_height*self.load_long

class Container:
    def __init__(self,long,width,height):
        self.long=long
        self.width=width
        self.height=height
        self.available=[Point(0,0,0)]
        self.settled_cargo=[]
        self.current_bottom_area=0#当前已占用的底面积
        self.current_max_height=0# 当前最高的高度
        self.alpha=0.2#调节因子

    def calculate_usage(self):
        volume=0
        length=len(self.settled_cargo)
        for i in range(length):
            volume=volume+self.settled_cargo[i].volume
        return volume/(self.long*self.width*self.height)

    def determine_top_view_overlaps(self,cargoA,cargoB):#从俯视图判断两个物体是否相撞（判断俯视图是否有重叠）
        tmpA_1=[cargoA.get_x,cargoA.get_y]
        tmpA_4=[cargoA.get_x+cargoA.load_long,cargoA.get_y+cargoA.load_width]
        tmpB_1=[cargoB.get_x,cargoB.get_y]
        tmpB_4=[cargoB.get_x+cargoB.load_long,cargoB.get_y+cargoB.load_width]
        if tmpA_1[0]>=tmpB_4[0] or tmpA_1[1]>=tmpB_4[1] or tmpB_1[0]>=tmpA_4[0] or tmpB_1[1]>=tmpA_4[1]:
            return 0
        else:
            return 1

    def  determine_main_view_overlaps(self,cargoA,cargoB):#从主视图判断两个物体是否相撞（判断主视图是否有重叠）
        tmpA_1=[cargoA.get_y,cargoA.get_z]
        tmpA_4=[cargoA.get_y+cargoA.load_width,cargoA.get_z+cargoA.load_height]
        tmpB_1=[cargoB.get_y,cargoB.get_z]
        tmpB_4=[cargoB.get_y+cargoB.load_width,cargoB.get_z+cargoB.load_height]
        if tmpA_1[0]>=tmpB_4[0] or tmpA_1[1]>=tmpB_4[1] or tmpB_1[0]>=tmpA_4[0] or tmpB_1[1]>=tmpA_4[1]:
            return 0
        else:
            return 1


    def determine_left_view_overlaps(self,cargoA,cargoB):
        tmpA_1 = [cargoA.get_x, cargoA.get_z]
        tmpA_4 = [cargoA.get_x + cargoA.load_long, cargoA.get_z + cargoA.load_height]
        tmpB_1 = [cargoB.get_x, cargoB.get_z]
        tmpB_4 = [cargoB.get_x + cargoB.load_long, cargoB.get_z + cargoB.load_height]
        if tmpA_1[0]>=tmpB_4[0] or tmpA_1[1]>=tmpB_4[1] or tmpB_1[0]>=tmpA_4[0] or tmpB_1[1]>=tmpA_4[1]:
            return 0
        else:
            return 1

    # 返回True表示有问题，返回False表示没问题
    def check_crash_and_suspended(self,cargo:Cargo):
        length=len(self.settled_cargo)
        if(length==0):
            return False,0
        result4=True
        for i in range(length):
            result1=self.determine_top_view_overlaps(cargo,self.settled_cargo[i])
            result2=self.determine_main_view_overlaps(cargo,self.settled_cargo[i])
            result3=self.determine_left_view_overlaps(cargo,self.settled_cargo[i])
            tmp=self.judge_box_suspended(self.settled_cargo[i],cargo)
            #print(tmp)
            if(tmp==False):
                result4=False
                result5=self.settled_cargo[i].get_locate_bottom_area
            if(result1+result2+result3>1):
                return True,0
        if(result4==False):
            return False,result5
        else:
            return True,0

    # 边界检查
    def determine_overflow(self,cargo):
        x1,y1,z1=cargo.get_x,cargo.get_y,cargo.get_z
        x4,y4,z4=x1+cargo.load_long,y1+cargo.load_width,z1
        x8,y8,z8=x1+cargo.load_long,y1+cargo.load_width,z1+cargo.load_height
        if(z8>self.height or x4>self.long or y4>self.width):
            #print("溢出")
            return True
        else:
            return False

    # 候选点坐标生成
    def solve_old_point_add_new_point(self,cargo,tmp_point):
        self.available.remove(tmp_point)
        x,y,z=tmp_point.tuple
        load_long=cargo.load_long
        load_width=cargo.load_width
        load_height=cargo.load_height
        # 人为规定只有3种摆放情况，当前物体的右、前、上方
        self.available.append(Point(x+load_long,y,z))
        self.available.append(Point(x,y+load_width,z))
        self.available.append(Point(x,y,z+load_height))

    # True表示有悬空，False表示没有悬空，检查cargoB是否有悬空
    def judge_box_suspended(self,cargoA,cargoB):#判断物体是否悬空放置，禁止物品出现任何悬空
        if(cargoB.get_z==0):
            return False
        
        tmpA_4 = [cargoA.get_x + cargoA.load_long, cargoA.get_y + cargoA.load_width]
        tmpB_4 = [cargoB.get_x + cargoB.load_long, cargoB.get_y + cargoB.load_width]
        # 如果B在A上
        if(cargoA.get_z+cargoA.load_height==cargoB.get_z):
                # 确保B的底部不超过A的表面范围
                if(cargoB.get_x>=cargoA.get_x and tmpB_4[0]<=tmpA_4[0] and cargoB.get_y>=cargoA.get_y and tmpB_4[1]<=tmpA_4[1]):
                    return False
                else:
                    return True
        else:
            return True

    def add_cargo_to_container_improved(self, cargo: Cargo):
        # Try placing on current layer first
        current_layer_height = self._get_current_layer_height()
        res, placed = self._try_place_in_layer(cargo, current_layer_height)
        
        if not res:
            # Try placing on a new layer
            current_layer_height += cargo.load_height
            res, placed = self._try_place_in_layer(cargo, current_layer_height)
        
        return res, placed
    
    def add_cargo_to_container_improvedB(self, cargo: Cargo):
        # Try placing on current layer first
        current_layer_height = self._get_current_layer_height()
        res, placed = self._try_place_in_layerB(cargo, current_layer_height)
        
        if not res:
            # Try placing on a new layer
            current_layer_height += cargo.load_height
            res, placed = self._try_place_in_layerB(cargo, current_layer_height)
        
        return res, placed

    def _get_current_layer_height(self):
        if not self.settled_cargo:
            return 0
        # TODO: 搜寻所有已放置的箱子的高度值，确定最大值即找到当前层的高度
        heights = [c.get_z+ c.load_height for c in self.settled_cargo]   # 取出现次数最多的z坐标最大值当作当前层高度
        return max(set(heights), key=heights.count)   # min(set(heights), key=heights.count) 如果按最小高度来定义层高会如何

    def _try_place_in_layer(self, cargo: Cargo, layer_height):
        best_position = None
        best_score = -float('inf')
        
        # 查找所有候选点中得分最高的位置码垛
        for point in self.available:
            # TODO:
            # if abs(point.z + cargo.load_height - layer_height) > 400:  # 为了保证平衡性，如果候选点与当前层高（层高是根据放置深度估计的）相差过大则跳过
            #     continue
            
            pose = 0
            cargo.set_locate_point(point.x, point.y, point.z)
            cargo.change_pose(pose)

            # TODO: 测试定位放置点正下方的箱子
            below_cargo = None
            total_height = 0
            for settled in self.settled_cargo:
                # total_height += settled.get_z + settled.load_height
                if (
                    settled.get_x <= point.x < settled.get_x + settled.load_long and
                    settled.get_y <= point.y < settled.get_y + settled.load_width and
                    settled.get_z + settled.load_height == point.z
                ):
                    below_cargo = settled
                    break
            # tmp_len = len(self.settled_cargo)
            # if (tmp_len != 0 and ((total_height/tmp_len + 400) < (cargo.z +cargo.load_height))):
            #     continue

            # TODO: 
            if not self._is_valid_placement(cargo, below_cargo):
                continue
                
            # Scoring based on:
            # 1. 箱子之间的支撑性
            # 2. 周围是否是同尺寸箱子
            # 3. 高度一致性
            score = self._calculate_placement_score(cargo)    # 运用加权的思想，确定放置的最佳位置
            
            if score > best_score:    # if score < best_score:
                best_score = score
                best_position = (point.x, point.y, point.z, pose)
        
        if best_position:
            t_or_f, point = self._place_cargo(cargo, *best_position)
            return t_or_f, point
        return False, None
    
    def _try_place_in_layerB(self, cargo: Cargo, layer_height):
        best_position = None
        best_score = -float('inf')
        
        # 查找所有候选点中得分最高的位置码垛
        for point in self.available:
            # TODO:
            # if abs(point.z + cargo.load_height - layer_height) > 200:  # 为了保证平衡性，如果候选点与当前层高（层高是根据放置深度估计的）相差过大则跳过
            #     continue
                
            pose = 0
            cargo.set_locate_point(point.x, point.y, point.z)
            cargo.change_pose(pose)

            # TODO: 测试定位放置点正下方的箱子
            below_cargo = None
            for settled in self.settled_cargo:
                if (
                    settled.get_x <= point.x < settled.get_x + settled.load_long and
                    settled.get_y <= point.y < settled.get_y + settled.load_width and
                    settled.get_z + settled.load_height == point.z
                ):
                    below_cargo = settled
                    break
            
            # TODO: 
            if not self._is_valid_placement(cargo, below_cargo):
                continue
                
            # Scoring based on:
            # 1. 箱子之间的支撑性
            # 2. 周围是否是同尺寸箱子
            # 3. 高度一致性
            score = self._calculate_placement_score(cargo)    # 运用加权的思想，确定放置的最佳位置
            
            if score > best_score:    # if score < best_score:
                best_score = score
                best_position = (point.x, point.y, point.z, pose)
        
        if best_position:
            t_or_f, point = self._place_cargoB(cargo, *best_position)
            return t_or_f, point
        return False, None

    def _place_cargo(self, cargo: Cargo, x: float, y: float, z: float, pose: int):
        """Place cargo at specified position with given pose"""
        cargo.set_locate_point(x, y, z)
        cargo.change_pose(pose)
        
        # 更新空间状态
        if z == 0:
            self.current_bottom_area += cargo.get_locate_bottom_area
        self.current_max_height = max(cargo.get_z + cargo.load_height, self.current_max_height)
        
        # Add to settled cargo list
        self.settled_cargo.append(cargo)
        
        # 更新下一个箱子到来时的可选点
        point = Point(x, y, z)
        self.solve_old_point_add_new_point(cargo, point) 
        
        # print(f"大小为 {cargo.tuple} 成功装入,放在 {point}") 原始左前下放置坐标
        # pos = int(x+cargo.long/2), int(y+cargo.width/2), int(z+cargo.height)
        pos = int(x), int(y), int(z+cargo.height)
        print(f"大小为 {cargo.tuple} 成功装入A托盘, 放在 {pos}") 
        return True, pos
       

    def _place_cargoB(self, cargo: Cargo, x: float, y: float, z: float, pose: int):
        """Place cargo at specified position with given pose"""
        cargo.set_locate_point(x, y, z)
        cargo.change_pose(pose)
        
        # 更新空间状态
        if z == 0:
            self.current_bottom_area += cargo.get_locate_bottom_area
        self.current_max_height = max(cargo.get_z + cargo.load_height, self.current_max_height)
        
        # Add to settled cargo list
        self.settled_cargo.append(cargo)
        
        # 更新下一个箱子到来时的可选点
        point = Point(x, y, z)
        self.solve_old_point_add_new_point(cargo, point) 
        
        # print(f"大小为 {cargo.tuple} 成功装入,放在 {point}") 原始左前下放置坐标
        # pos = int(x+cargo.long/2), int(y+cargo.width/2), int(z+cargo.height)
        pos = int(x), int(y), int(z+cargo.height)
        print(f"大小为 {cargo.tuple} 成功装入缓存区,放在 {pos}") 
        return True, pos

    def _is_valid_placement_origin(self, cargo: Cargo):
        # Check basic constraints
        if self.determine_overflow(cargo):
            return False
            
        crash, _ = self.check_crash_and_suspended(cargo)
        if crash:
            return False
        return True
    
    def _is_valid_placement(self, cargo: Cargo, below_cargo: Cargo):
        # Check basic constraints
        if self.determine_overflow(cargo):
            return False

        crash, _ = self.check_crash_and_suspended(cargo)
        if crash:
            return False

        # 检查大不压小原则
        if below_cargo and cargo.volume > below_cargo.volume:
            return False  # 违反大不压小原则，禁止放置

        return True


    def _calculate_placement_score(self, cargo: Cargo):
        score = 0
        
        # 当前放置位置高度与当前层的高度进行比较
        layer_height = self._get_current_layer_height()
        # height_diff = abs(cargo.get_z - layer_height)    # 差距越大，分数越低
        height_diff = abs(cargo.get_z + cargo.load_height - layer_height)   
        score -= height_diff * 5
        
        # 检查相互关系
        contact_score = self._calculate_contact_score(cargo)
        score += contact_score * 10     # score -= contact_score * 10
        
        # 同类型检查
        same_type_score = self._calculate_same_type_proximity(cargo)
        score += same_type_score * 5    # score -= same_type_score * 5
        
        return score
    def _calculate_contact_score(self, cargo: Cargo):
        """Calculate contact score based on how well cargo touches other boxes"""
        contact_score = 0
        
        # 如果底部有空间，优先放在底部最好的
        if cargo.get_z == 0:
            contact_score += 100  # Ground contact is best
        
        for settled in self.settled_cargo:
            # 两个相邻箱子尽量有接触，保证稳定性
            if self._has_side_contact(cargo, settled):
                contact_score += 20
                
            # 检查底部支撑
            # if settled.get_z + settled.load_height == cargo.get_z:   # 如果说当前箱子放在其他箱子的上面
            #     overlap = self._calculate_overlap_area(cargo, settled)   # 计算重叠面积
            #     if overlap < cargo.get_locate_bottom_area:
            #         contact_score += (overlap / cargo.get_locate_bottom_area) * 50
            #     else:
            #         contact_score +=0      
        return contact_score

    def _calculate_same_type_proximity(self, cargo: Cargo):
        """Score based on proximity to boxes of same dimensions"""
        proximity_score = 0
        cargo_dims = cargo.tuple
        
        for settled in self.settled_cargo:
            if settled.tuple == cargo_dims:  # Same dimensions
                # Calculate distance between centers
                dx = abs((cargo.get_x + cargo.load_long/2) - 
                        (settled.get_x + settled.load_long/2))
                dy = abs((cargo.get_y + cargo.load_width/2) - 
                        (settled.get_y + settled.load_width/2))
                dz = abs((cargo.get_z + cargo.load_height/2) - 
                        (settled.get_z + settled.load_height/2))
                
                distance = (dx**2 + dy**2 + dz**2)**0.5
                
                if distance < 500:  # Close proximity bonus
                    proximity_score += 50 * (1 - distance/500)
                    
                # Extra bonus for direct stacking
                if self._is_directly_stacked(cargo, settled):
                    proximity_score += 100
                    
        return proximity_score

    def _has_side_contact(self, cargo_a: Cargo, cargo_b: Cargo):
        """Check if two cargo boxes have side contact"""
        # Check x-axis contact
        x_contact = (abs(cargo_a.get_x - (cargo_b.get_x + cargo_b.load_long)) < 1 or 
                    abs(cargo_b.get_x - (cargo_a.get_x + cargo_a.load_long)) < 1)
                    
        # Check y-axis contact
        y_contact = (abs(cargo_a.get_y - (cargo_b.get_y + cargo_b.load_width)) < 1 or
                    abs(cargo_b.get_y - (cargo_a.get_y + cargo_a.load_width)) < 1)
                    
        # Check z overlap
        z_overlap = (min(cargo_a.get_z + cargo_a.load_height, 
                        cargo_b.get_z + cargo_b.load_height) - 
                    max(cargo_a.get_z, cargo_b.get_z)) > 0
                    
        return (x_contact or y_contact) and z_overlap

    def _is_directly_stacked(self, cargo_a: Cargo, cargo_b: Cargo):
        """Check if cargo_a is directly stacked on cargo_b"""
        return (abs(cargo_a.get_z - (cargo_b.get_z + cargo_b.load_height)) < 1 and
                self._calculate_overlap_area(cargo_a, cargo_b) > 0)

    def _calculate_overlap_area(self, cargo_a: Cargo, cargo_b: Cargo):
        # Calculate overlapping area between two cargo bottoms
        x_overlap = max(0, min(cargo_a.get_x + cargo_a.load_long, cargo_b.get_x + cargo_b.load_long) - 
                    max(cargo_a.get_x, cargo_b.get_x))
        y_overlap = max(0, min(cargo_a.get_y + cargo_a.load_width, cargo_b.get_y + cargo_b.load_width) - 
                    max(cargo_a.get_y, cargo_b.get_y))
        return x_overlap * y_overlap

    

plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.sans-serif'] = ['SimHei']
fig:Figure = plt.figure()
ax = fig.add_subplot(1, 1, 1, projection='3d')
ax.view_init(elev=5, azim=60)
plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)

def draw_reslut(setted_container:Container):
    plt.gca().set_box_aspect((
        setted_container.long,
        setted_container.width,
        setted_container.height
    ))
    _draw_container(setted_container)
    for cargo in setted_container.settled_cargo:
        _draw_cargo(cargo)
    plt.show()

def _draw_container(container:Container):
    _plot_linear_cube(
        0,0,0,
        container.long,
        container.width,
        container.height
    )

def _draw_cargo(cargo:Cargo):
    _plot_opaque_cube(
        cargo.x, cargo.y, cargo.z,
        cargo.load_long, cargo.load_width, cargo.load_height
    )

def _plot_opaque_cube(x=10, y=20, z=30, dx=40, dy=50, dz=60):
    xx = np.linspace(x, x+dx, 2)
    yy = np.linspace(y, y+dy, 2)
    zz = np.linspace(z, z+dz, 2)
    xx2, yy2 = np.meshgrid(xx, yy)
    ax.plot_surface(xx2, yy2, np.full_like(xx2, z))
    ax.plot_surface(xx2, yy2, np.full_like(xx2, z+dz))
    yy2, zz2 = np.meshgrid(yy, zz)
    ax.plot_surface(np.full_like(yy2, x), yy2, zz2)
    ax.plot_surface(np.full_like(yy2, x+dx), yy2, zz2)
    xx2, zz2= np.meshgrid(xx, zz)
    ax.plot_surface(xx2, np.full_like(yy2, y), zz2)
    ax.plot_surface(xx2, np.full_like(yy2, y+dy), zz2)

def _plot_linear_cube(x, y, z, dx, dy, dz, color='red'):
    # ax = Axes3D(fig)
    xx = [x, x, x+dx, x+dx, x]
    yy = [y, y+dy, y+dy, y, y]
    kwargs = {'alpha': 0, 'color': color}
    ax.plot3D(xx, yy, [z]*5, **kwargs)
    ax.plot3D(xx, yy, [z+dz]*5, **kwargs)
    ax.plot3D([x, x], [y, y], [z, z+dz], **kwargs)
    ax.plot3D([x, x], [y+dy, y+dy], [z, z+dz], **kwargs)
    ax.plot3D([x+dx, x+dx], [y+dy, y+dy], [z, z+dz], **kwargs)
    ax.plot3D([x+dx, x+dx], [y, y], [z, z+dz], **kwargs)
