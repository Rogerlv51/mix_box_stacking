# from pianyibanben import *
from maduo import *
from time import process_time
import random
import socket

def random_test():
    process_time()
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    item_size_set = []
    #1-1
    item = [[200, 150, 100, 144],[300, 200, 150, 48],[300, 250, 200, 32], [400, 300, 200, 24], [400, 300, 300, 12], [700, 400, 320, 2]]
    # 加载所有货物数据
    for i in range(len(item)):
        for j in range(item[i][3]):
            item_size_set.append((item[i][0],item[i][1],item[i][2]))
    collect1 = []
    collect2 = []
    random.shuffle(item_size_set)  # 随机打乱顺序
    for t in range(len(item_size_set)):
        result, _ = containerA.add_cargo_to_container_improved(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        # result = containerA.add_cargo_to_container2(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        if (result == False):
            
            collect1.append(containerA.calculate_usage())
            res, _= containerB.add_cargo_to_container_improvedB(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
            if (res == True):
                collect2.append(containerB.calculate_usage())
            else:
                print("当前箱子无法放入码垛区与缓冲区")
                collect2.append(containerB.calculate_usage())
        else:
            collect1.append(containerA.calculate_usage())

    print("程序运行时间是: {:9.9}s".format(process_time()))
    draw_reslut(containerA)
    # draw_reslut(containerB)
    plt.figure()
    plt.plot([i for i in range(len(item_size_set))],collect1)
    print('利用率', containerA.calculate_usage())
    plt.xlabel("箱子编号")
    plt.ylabel("累计利用率")
    plt.show()
    print("共计码垛箱子数量为：", len(containerA.settled_cargo))
    
    

def single_plot(setted_container:Container):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    ax.set_xlim(0, 1200)
    ax.set_ylim(0, 1200)
    ax.set_zlim(0, 1000)
    for item in setted_container.settled_cargo:
        length, width, height = item.tuple
        ax.bar3d(item.get_x, item.get_y, item.get_z, length, width, height, alpha=1)
    plt.title(f'Episode 1 Container Stacks')
    plt.xlabel('X-axis')
    plt.ylabel('Y-axis')
    ax.set_zlabel('Height')
    plt.show()

def single_test():
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    collect1 = []
    collect2 = []
    total = 0
    while True:
        print('请输入箱子尺寸，长宽高，以空格分隔：（输入q结束）')
        temp = input()
        if temp == 'q':
            break
        else:
            x, y, z = map(int, temp.split())
            process_time()
            result, _ = containerA.add_cargo_to_container_improved(Cargo(x, y, z))
            # result = containerA.add_cargo_to_container2(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
            if (result == False):
                
                collect1.append(containerA.calculate_usage())
                res, _ = containerB.add_cargo_to_container_improved(Cargo(x, y, z))
                if (res == True):
                    print("无法装入托盘A中, 成功放入缓冲区")
                    collect2.append(containerB.calculate_usage())
                else:
                    print("无法放入缓冲区")
                    collect2.append(containerB.calculate_usage())
            else:
                collect1.append(containerA.calculate_usage())
            total += 1
            print("装箱运行时间是: {:9.9}s".format(process_time()))
            single_plot(containerA)
    plt.figure()
    plt.plot([i for i in range(total)],collect1)
    print('利用率', containerA.calculate_usage())
    plt.xlabel("箱子编号")
    plt.ylabel("累计利用率")
    plt.show()

def random_single_plot():
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    
    item_size_set = []
    #1-1
    item = [[200, 150, 100, 144],[300, 200, 150, 48],[300, 250, 200, 32], [400, 300, 200, 24], [400, 300, 300, 12], [700, 400, 320, 2]]
    # 加载所有货物数据
    for i in range(len(item)):
        for j in range(item[i][3]):
            item_size_set.append((item[i][0],item[i][1],item[i][2]))
    collect1 = []
    collect2 = []
    random.shuffle(item_size_set)  # 随机打乱顺序
    for t in range(len(item_size_set)):
        result, _  = containerA.add_cargo_to_container_improved(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        # result = containerA.add_cargo_to_container2(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
        if (result == False):
            
            collect1.append(containerA.calculate_usage())
            res, _ = containerB.add_cargo_to_container_improvedB(Cargo(item_size_set[t][0],item_size_set[t][1],item_size_set[t][2]))
            if (res == True):
                collect2.append(containerB.calculate_usage())
            else:
                print('编号' + str(t) + "无法放入缓冲区")
                collect2.append(containerB.calculate_usage())
        else:
            collect1.append(containerA.calculate_usage())
        single_plot(containerA)
    print("共计码垛箱子数量为：", len(containerA.settled_cargo))

if __name__ == "__main__":
    # single_test()
    # random_test()
    # random_single_plot()
    host = '127.0.0.1'
    port= 2025
    containerA = Container(1200, 1200, 1000)
    containerB = Container(1200, 1200, 1000)
    collect1 = []
    collect2 = [] 
    num = 0
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        # 绑定套接字到指定的地址和端口
        server_socket.bind((host, port))
        # 监听传入的连接
        server_socket.listen()
        print(f"Server listening on {host}:{port}")

        # 接受连接
        conn, addr = server_socket.accept()
        with conn:
            print(f"Connected by {addr}")
            while True:
                # 接收数据
                data = conn.recv(1024)
                if not data:
                    break
                # 将接收到的字节数据解码为字符串
                received_message = data.decode('utf-8')
                # 以逗号分割字符串并存储到列表中
                tmp_data = received_message.split(',')
                print("接收到的数据为: ", tmp_data)
                if tmp_data[0] == 'Stack':
                    x, y, z = int(float(tmp_data[1])), int(float(tmp_data[2])), int(float(tmp_data[3]))
                    res, place_pos = containerA.add_cargo_to_container_improved(Cargo(x, y, z))
                    if (res == False):
                        # collect1.append(containerA.calculate_usage())
                        res_B, place_posB = containerB.add_cargo_to_container_improvedB(Cargo(x, y, z))
                        if (res_B == True):
                            collect2.append(containerB.calculate_usage())
                            whereStack = 2
                            items_list = [place_posB[0], place_posB[1], place_posB[2], whereStack, "maduo"]
                            items_list_str = [str(item) for item in items_list]
                            combined_message = ','.join(items_list_str)
                            print("发送码垛坐标：", combined_message)
                            conn.sendall(combined_message.encode('utf-8'))
                            print('空间利用率: {:.2%}'.format(containerA.calculate_usage()))
                        else:
                            print("当前箱子无法放入任何码垛区, 丢弃, 尝试下一个物料")
                            collect2.append(containerB.calculate_usage())
                            whereStack = -1
                            items_list = [0, 0, 0, whereStack, "maduo"]
                            items_list_str = [str(item) for item in items_list]
                            combined_message = ','.join(items_list_str)
                            conn.sendall(combined_message.encode('utf-8'))
                            print('空间利用率: {:.2%}'.format(containerA.calculate_usage()))
                    else:
                        whereStack = 1
                        collect1.append(containerA.calculate_usage())
                        items_list = [place_pos[0], place_pos[1], place_pos[2], whereStack, "maduo"]
                        items_list_str = [str(item) for item in items_list]
                        combined_message = ','.join(items_list_str)
                        print("发送码垛坐标：", combined_message)
                        conn.sendall(combined_message.encode('utf-8'))
                        print('空间利用率: {:.2%}'.format(containerA.calculate_usage()))
                        num+=1
                        print("当前码垛箱子数为：", num)